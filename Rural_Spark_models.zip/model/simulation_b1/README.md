> **First step:** unzip `results.zip` here (it creates the `results/` folder that `matlab/RUN_ME.m` and the figures read). It is zipped only to keep the repository upload small.

# Rural Spark: energy management controller simulation (Workstream B1)

This is a simulation of a 25-household Chenchu penta mini-grid in Amrabad mandal, Nagarkurnool, Telangana (16.37° N, 78.83° E). It answers one question with numbers: **does forecast-aware tiered dispatch keep essential loads on more reliably *and* deliver more productive energy than the controllers used at this scale today?**

**Split of work.** The battery pack model is in **MATLAB and Simulink** (`matlab/`): a block-level Simulink model (`RuralSpark_BatteryPack.slx`, built by `build_battery_simulink.m`) and the same equations as MATLAB functions (`bp_*.m`). The rest of the simulation (PV, loads, forecast, engine, controllers, metrics) is in **Python**. The Python engine can call the MATLAB pack directly through `matlab.engine`, or use a line-by-line Python twin of it. The twin is checked against the MATLAB code with golden vectors (see *MATLAB* below).

---

## Headline results (10 kWp / 20 kWh, spec loads; all numbers from `results/`)

Every row reports Tier 1 availability and Tier 3 energy together (spec section 1).

| Scenario | Reactive (incumbent) | Static thresholds | **Forecast-aware (ours)** | Oracle (ceiling) |
|---|---|---|---|---|
| **S3: 3 overcast days** (5-min step) | T1 **74.3%**, 6 blackouts, 9.9 kWh T1 lost | T1 100%, T3 36.8 kWh | **T1 100%, T3 35.7 kWh** | T1 100%, T3 36.5 kWh |
| **S4: full year** (15-min step) | T1 98.2%, 24 blackouts | T1 100%, T3 3,424 kWh, 8 honey batches spoiled | **T1 100%, T3 3,512 kWh, 0 spoiled** | T1 100%, T3 3,524 kWh |
| S9: battery at 80% (end of life) | T1 97.4% | T1 99.97% (2 blackouts) | **T1 100%**, 0 spoiled | T1 100% |
| S10: one string down (−25% PV) | T1 93.3%, 28 spoiled | T1 100%, **41 spoiled**, 1,956 h cold-chain excursion | **T1 100%, 0 spoiled, 656 h** | T1 100% |
| S8: +50% load growth | T1 86.1% | T1 98.45%, 110 spoiled | **T1 100%**, 0 spoiled | T1 100% |

- **Gap captured.** Over the year, our controller captures **88% of the Tier 3 gain available to a perfect-foresight controller** over static thresholds:  (3512 − 3424)/(3524 − 3424).
- **Spoiled batches.** Zero spoiled honey batches in every scenario and every seed: the batch gate refuses to start what it cannot finish.
- **Cold chain.** Cold-chain excursion over the year falls from 724 h (static) to 177 h, thanks to the cold store being budgeted as planned load and pre-cooled on PV surplus.
- **Advance notice.** 33% of curtailment events are announced in advance, with a mean of 4.4 h notice. Static and reactive give none.
- **Sizing.** Our controller holds Tier 1 at 100% **on every point of the sizing grid**, down to 8 kWp / 10 kWh. Static needs at least 20 kWh to do the same.
- **Robustness.** Over 5 independent load and forecast seeds, ours has Tier 1 at 100% and 0 spoiled batches in all five. Static loses up to 0.9 kWh of Tier 1 in one seed and spoils 7–12 batches a year.
- **Higher-fidelity pack.** Run with the MATLAB cell-level ECM pack instead of the energy model, the ranking is unchanged (ours: T1 100%, T3 3,521 kWh, 0 spoiled).

![S3 headline](results/figures/headline_S3.png)

### Results that cut against the pitch, reported as found

1. **S3 by itself does not make our case against static thresholds.** Static also keeps Tier 1 at 100% in the worst 3-day spell, and completes *more* Tier 3 batches (10 vs 7). Our controller instead gives Tier 2 priority (75.8% vs 73.0% served), as the waterfall requires. The case against static is the year, the faults and the ageing battery: S4, S9, S10 and S8.
2. **The 20% forecast derate is not what protects Tier 1.** In the stress test (+50% load, +20% optimistic bias), Tier 1 stays at 100% at every derate from 0 to 0.4. The ablation shows what does protect it:
   - Without the **day+1 look-ahead**, Tier 1 drops to 99.88%.
   - With the reserve multiplier at ×1.0, it drops to 99.92%.
   - With the bare spec text (no look-ahead, no derate, ×1.0), it drops to 99.69% (5.6 kWh lost).

   Each 0.1 of derate costs about 110–350 kWh/yr of Tier 3. **Recommendation:** keep the look-ahead and the ×1.25 reserve, lower the derate to 0.10, and confirm with field data.
3. **The battery does not last 11–12 years.**
   - At about 147 equivalent full cycles a year, the spec fade model puts 80% capacity at **year 8.9**. Calendar fade alone (1.5%/yr) would give 13.3 years.
   - The R1 design (40.96 kWh) cycles about 71 times a year and reaches **10.8 years**.
   - Per spec section 4, *the business model needs changing*: budget the replacement at year 9, or size the battery larger.
4. **About 40% of PV energy is dumped at 10 kWp** (5.9 MWh/yr). The array is at the Tier 3 knee, but the village cannot absorb midday surplus. Adding daytime productive load (another NTFP machine) is worth more than adding panels.
5. **Under heavy load growth (+50%), our Tier 3 roughly equals static's** (4,012 vs 4,034 kWh), but static gets there by dropping Tier 1 (98.45%) and spoiling 110 batches. The oracle reaches 4,428 kWh; most of the gap is the derate (see point 2).
6. **Tilt hardly matters.** Annual yield at 16° is within 0.05% of the 22° optimum. 10° gives 2.2% more in Jun–Sep, but service metrics differ by under 0.2%. 16° is kept as a compromise between yield and rain self-cleaning.

---

## Validation gates (spec section 10): all pass (`results/gates.json`)

| Gate | Result |
|---|---|
| 1 Energy balance every step, residual < 0.1% | max residual 2e-16 kWh; asserted inside the engine, and the run aborts on violation |
| 2 SoC within [0.20, 1.00] always | min 0.200, max 1.000; asserted in the battery model |
| 3 Annual yield within ±5% of PVGIS | model 1,487 vs PVGIS PVcalc 1,476 kWh/kWp (**+0.8%**) |
| 4 Reactive must fail in S3 | reactive T1 74.3%, 6 blackouts |
| 5 Oracle ≥ forecast-aware ≥ static (Tier 1), every scenario | no violations across S1–S11, S5, S6 and the stressed sweeps |
| 6 Test suite green | 14/14: battery conservation, limits and derate, golden-file twin, hysteresis (no chatter, dwell), energy balance, batch gate (no spoils), tier priority never inverted, Tier 1 never opened, gates 3–5, Simulink block formulation = bp_step |

---

## Method

| Module | What it does |
|---|---|
| `src/pv.py` | **PVWatts** chain (spec section 3): Michalsky solar position, Hay-Davies transposition, physical IAM, Faiman cell temperature, γ = −0.35%/°C, seasonal soiling 6% (dry) / 2% (Jun–Sep), 6% system loss, PVWatts inverter curve (η 0.96). Uses pvlib automatically when it is installed (`PVConfig(use_pvlib=True)`); pvlib could not be installed in the build environment, so the default path implements the same published equations in numpy. |
| `data/` | **PVGIS v5.2 TMY** (ERA5, 2005–2020, DEM horizon) for 16.37 N, 78.83 E, elevation 599 m, plus PVGIS PVcalc reference yields. Provenance and checksums are in `pvgis_tmy_meta.json`. Irradiance closure GHI = DNI·cosZ + DHI fits to 1 W/m² RMSE at the hour mark, which fixes the timestamp convention. |
| `matlab/bp_*.m` | **Battery pack model** (spec section 4), see below |
| `src/loads.py` | Bottom-up stochastic demand: 25 households, each appliance an on/off event at 1-minute resolution. Covers seasonal fans, TV ownership, ANM sub-centre (ILR + lighting + on-call), anganwadi/school with summer vacation, shops, a 750 W pump (2 × 1 h, schedulable), honey batches (1.5 kW × 3 h, **non-interruptible**), leaf-plate press (1.1 kW × 2 h, resumable), a 400 W cold store with a thermal model, and household absence. |
| `src/forecast.py` | Day-ahead forecast = truth × (1 + ε). ε ~ N(bias, σ) with σ by sky class from the daily clearness index (0.07 / 0.18 / 0.28). Hourly shape error is σ/2; the day+1 forecast uses σ × 1.25. Forecast outage days are supported. |
| `src/engine.py` | Single AC bus. Tier 1 is normally closed; the inverter trips on **LVD** if PV + battery limits cannot carry the load and reconnects at SoC 25%. Handles batch spoil/pause, cold-store thermodynamics and per-step energy balance. |
| `src/controllers/` | `reactive` (serve until empty), `static` (T3 cut/restore 0.55/0.68, T2 0.38/0.50, 15-min dwell), `forecast_aware` (ours), `oracle` (same waterfall, true PV and loads, no derate) |
| `src/metrics.py` | All 13 KPIs in spec section 8, including rainflow DoD, advance warning, and a monthly Gini of Tier 3 service ratio |

### Our controller (`forecast_aware.py`)

- **06:00 plan.** Usable battery + forecast PV × (1 − derate) − Tier 1 day − 1.25 × Tier 1 overnight reserve − day+1 shortfall. The result is allocated by waterfall: Tier 2 first, then Tier 3. Tier 3 batches are placed whole in the forecast surplus window, and the pump in the two best PV hours.
- **Hourly.** The same waterfall is rerun with measured SoC. Remaining forecast is scaled down when measured PV tracks below forecast.
- **Every step:**
  - Tier 2 budget latch, with SoC hysteresis back-stops and a 15-min dwell.
  - Batch gate: available energy over the batch must be ≥ 1.15 × batch energy.
  - Tier 3 is never on while Tier 2 is curtailed.
  - A running honey batch is cut only below the 0.38 emergency floor.
  - Cold store pre-cooled on PV surplus.

### Design decisions beyond the spec text (each can be switched off; ablation in `results/results.json`)

| Decision | Why |
|---|---|
| Day+1 look-ahead in the reserve | without it, Tier 1 fails under stress |
| Planned Tier 3 may run down to 0.38 (unplanned stays at the 0.55 band) | the plan already holds the Tier 1 reserve |
| Solar-direct relay close when PV exceeds total load | otherwise the surplus is dumped |
| Cold-store pre-cooling | reduces cold-chain excursion |
| Bookings: Tier 3 batches are booked by 06:00 | needed for scheduling; an SMS or app booking is assumed |

---

## Assumptions (ASSUMED = team assumption to be replaced with survey or datasheet data)

| Item | Value | Basis |
|---|---|---|
| Array / tilt / azimuth | 10 kWp, 16°, south | spec |
| γ, soiling, system loss | −0.0035/°C; 6% dry, 2% Jun–Sep; 6% | spec |
| Battery | 20 kWh LFP, η 0.97/0.97, SoC 0.20–1.00, 0.5C, 50% charge derate > 45 °C | spec |
| Fade | 1.5%/yr calendar + 5e-5 per EFC; EOL 80% | spec |
| Pack thermal | 7 kJ/K per kWh, UA 1 W/K per kWh, shed +2 K | ASSUMED |
| ECM cell | 100 Ah LFP, R0 0.8 mΩ, R1 0.4 mΩ, τ 60 s, generic OCV curve | ASSUMED, illustrative: replace with the selected cell's datasheet |
| Households / appliances / windows | per spec table | spec |
| TV ownership, shops | 40%, 3 shops | ASSUMED |
| Fan use by month | 0.10 (Dec–Jan) to 0.95 (May) | ASSUMED |
| Honey season / leaf-plate season | honey Mar–Jun p = 0.7/day per unit; leaf plates Oct–Feb 0.9, Mar–Jun 0.6, Jul–Sep 0.3 | ASSUMED: confirm with ITDA/GCC collection calendars |
| Cold store | 400 W, room τ 24 h, pull-down 2.5 °C/h, band 2–5 °C, excursion > 8 °C | ASSUMED |
| Household absence | baseline 10% for 4 weeks from 1 Apr; S11 30% for 6 weeks | ASSUMED |
| School vacation | 24 Apr – 11 Jun (anganwadi only, 120 W) | ASSUMED from the Telangana calendar |
| LVD reconnect | SoC 25% | ASSUMED |
| Forecast σ by sky class, bias, outage | per spec section 6 | spec |

Average demand is 24.5 kWh/day: Tier 1 5.2 (including pump), Tier 2 9.4, Tier 3 batches 5.8, cold store about 4. **This is the spec's appliance table, which is lighter than the R1 deck design (39.9 kWh/day on 18.36 kWp / 40.96 kWh).** The R1 point is included in the sizing sweep:
- forecast-aware: T1 100%, T3 3,611 kWh, 0 spoiled, life 10.8 years
- static: T1 100%, 2 spoiled

---

## Quick start in MATLAB

Open `matlab/RUN_ME.m` and press **Run**. It needs MATLAB R2019b or newer (developed for R2026a); section 6 also needs Simulink. It runs six sections:

1. Checks the MATLAB functions against the Python twin (golden vectors).
2. Replays the S3 battery requests through the MATLAB functions.
3. Runs the pack characterisation figures.
4. Draws the S3 headline figure.
5. Shows the results table and the battery replacement year.
6. **Builds, opens and verifies the Simulink battery model.** Expect `ALL 16 cases PASS`.

## Simulink battery pack model (`matlab/RuralSpark_BatteryPack.slx`)

**`RuralSpark_BatteryPack.slx` is included, already built and verified.** Open it and press Run (the InitFcn loads the data). `build_battery_simulink.m` rebuilds it from scratch. The model uses standard Simulink blocks only. There are no MATLAB Function blocks, so every equation of spec section 4 is visible on the diagram.

| Subsystem inside **LFP Battery Pack** | Blocks | Equation |
|---|---|---|
| Ageing | Digital Clock, Gains, Sum, Switch | capacity = cap0 − 1.5%/yr × age − 5e-5 × EFC (switch `bp.update_capacity`); E_eff = E_nom × capacity |
| Power limits | Sum, Saturation, Product, Gain, MinMax, Relational Operator, Switch | P_dis,max = min(0.5C, (SoC − 0.20)·E_eff·η_d/Δt); P_ch,max = min(0.5C or 0.25C if T_cell > 45 °C, (1 − SoC)·E_eff/(η_c·Δt)) |
| Power clamp | Saturation Dynamic, Abs, Relational Operator | P = clamp(P_req, −P_ch,max, +P_dis,max); flag when the request was limited |
| Efficiency and losses | Saturation (split by direction), Gains, Sum | discharge: ΔE = −P·Δt/η_d, loss = P·Δt(1/η_d − 1); charge: ΔE = −P·η_c·Δt, loss = −P·Δt(1 − η_c) |
| SoC integrator + SoC update | Discrete-Time Integrator (limits 0.20–1.00), Product, Sum, Saturation | SoC(k+1) = SoC(k) + ΔE/E_eff |
| Thermal model | Gains, Sums, Discrete-Time Integrator | T_∞ = T_amb + 2 K + loss/UA; T(k+1) = T(k) + (T_∞ − T(k))(1 − e^(−Δt·UA/C)) |
| EFC integrator | Gain, Discrete-Time Integrator | EFC += discharge kWh / E_nom |
| Electrical view | 1-D Lookup Table (OCV vs SoC), Gains, Product | indicative V_pack = 16 × OCV(SoC), I_pack = P/V_pack |

**Model setup:**
- **Inputs:** *From Workspace* blocks carry the battery power requests and outdoor temperature that the Python dispatch simulation sent to the pack (`results/replay/*.csv`), and the Python SoC for comparison.
- **Outputs:** Scopes for power (requested vs delivered), SoC (Simulink vs Python), cell vs outdoor temperature, the limited/derated flags, and V/I. *To Workspace* writes `soc_sl`, `P_sl`, `T_sl`, `loss_sl`, `efc_sl`, `cap_sl`, `V_sl`, `I_sl`.
- **Parameters:** all come from the struct `bp = bp_default_params('energy', E_nom)`. Simulink, `bp_step.m` and the Python twin therefore share one parameter set. The model's InitFcn (`rs_battery_data.m`) loads it.
- **Solver:** fixed-step discrete, Ts = 5 min (scenario weeks) or 15 min (full years).
- **Another case:** run `rs_case = 'S4_static';` and then press Run, or call `build_battery_simulink('S4_static')`.

**Verification** (`verify_battery_simulink.m`) runs the model on all 16 replay profiles:
- 12 profiles are the S1–S3 weeks for 4 controllers.
- 4 profiles are full S4 years at 36,384 steps each.
- On each one, SoC, power and cell temperature are compared with `bp_step.m` (tolerance 1e-9) and with the Python run (tolerance 1e-8). Results go to `results/matlab/simulink_verification.csv`, and diagram images to `results/matlab/simulink_*.png`.
- The same block formulation is evaluated in Python by `tests/test_simulink_equivalence.py`. It agrees with `bp_step` to ≤ 6e-14 on all 16 profiles.

## MATLAB battery pack model, function form (`matlab/`)

| File | Purpose |
|---|---|
| `bp_default_params.m` | Parameters; `'energy'` (spec section 4 equations) or `'ecm'` (16S4P cell-level equivalent circuit) |
| `bp_init.m`, `bp_limits.m`, `bp_step.m` | State, step limits, one time step (power ↔ current, SoC, R0 + RC, thermal, derate, EFC, fade) |
| `bp_ecm_terms.m` | Step-averaged RC terms, so terminal energy, stored energy (chemical + polarisation) and heat stay exactly consistent |
| `bp_life_projection.m` | Year at which capacity reaches 80% for a given EFC/yr |
| `bp_verify_against_python.m` | **Run this first.** Checks MATLAB against `tests/golden/*.csv` (864 steps per mode; covers 0.5C clipping, floor and ceiling, > 45 °C derate) to 1e-9 |
| `bp_replay.m` | Replays any simulation's per-step battery requests (`results/replay/*.csv`) in MATLAB and prints the SoC difference, showing the MATLAB model is the one behind the results |
| `bp_testbench.m` | Characterisation: discharge curves at 0.1/0.25/0.5C, round-trip efficiency, thermal derate, life curve |
| `build_battery_simulink.m`, `rs_battery_data.m`, `verify_battery_simulink.m` | Build, feed and verify the Simulink model (section above) |
| `RUN_ME.m` | Runs everything above in order |

```matlab
>> cd matlab
>> ok = bp_verify_against_python          % expect PASS for 'energy' and 'ecm'
>> T  = bp_replay('../results/replay/S3_forecast_aware.csv');
>> R  = bp_testbench();                    % figures -> results/matlab/
```

To run the **whole simulation with the MATLAB pack in the loop**, install the MATLAB Engine for Python (`cd <matlabroot>/extern/engines/python && python -m pip install .`) and build with `EngineConfig(battery_backend="matlab")`. It is slower (one engine call per step), so use it for scenario runs, not sweeps.

The testbench numbers come from the Python twin, because MATLAB was not available here. ECM round-trip efficiency at 25 °C (cells only, no PCS) is:
- 0.993 at 0.1C
- 0.983 at 0.25C
- 0.967 at 0.5C

The energy model uses the spec's fixed 0.94. The charge derate engages after 0.68 h of 0.5C charging at 40 °C outdoor.

**Version note.** Verified on 17 Oct 2026 in **MATLAB R2025a with Simulink**: `RuralSpark_BatteryPack.slx` built, ran and passed all 16 replay cases. SoC matched `bp_step.m` to within 6e-16 and the Python simulation to within 1.3e-10; power matched to within 6e-14 kW and cell temperature to within 1.5e-14 °C (`results/matlab/simulink_verification.csv`). The built `.slx` is included in `matlab/`, and its diagram images are in `results/matlab/simulink_*.png`. Needs R2019b or newer.

---

## How to reproduce

```bash
pip install numpy scipy pandas matplotlib pyyaml tabulate   # pvlib and pytest optional
python tests/make_golden.py         # golden vectors for the MATLAB cross-check
python src/experiments.py           # every scenario, sweep, ablation (about 7 min)
python src/figures.py               # figures and tables
python src/gates.py                 # validation gates + test suite
python tests/run_tests.py           # or: pytest tests/
python src/pv.py                    # PV validation vs PVGIS only
```

Scenario definitions are in `scenarios/*.yaml`. Step length: 5 min for the scenario weeks (S1–S3, S7), 15 min for annual runs and sweeps. Every result records its step (`dt_min`).

**Outputs:**
- `results/results.json` (everything)
- `results/results_table.csv` / `.md`
- `results/sizing_sweep.csv`
- `results/gates.json`
- `results/figures/*.png`
- `results/replay/*.csv` (battery requests per step: S1–S3 at 5 min, S4 full year at 15 min, 4 controllers each)
- `results/matlab_data/*.csv` (S3 logs for MATLAB plotting)
- `results/matlab/` (written by MATLAB: characterisation figures, Simulink diagrams, `simulink_verification.csv`)

---

## Limitations

- **Synthetic loads.** Demand is synthetic: every probability, window, ownership rate and seasonal calendar is a team assumption, not a household survey. Absolute Tier 2/3 kWh values will move once survey data exists; the controller *ranking* was stable across five independent load seeds.
- **Weather.** Weather is a single PVGIS **TMY**, not measured site data. A TMY understates extreme runs of bad days, and ERA5 smooths temperature peaks (TMY maximum 39.6 °C), so the 45 °C battery derate never triggered in the annual runs. S3 is the worst 3-day spell *in the TMY*, not the worst on record; the 2005–2020 hourly series contains a worse October window.
- **Interpolated irradiance.** Hourly irradiance is linearly interpolated to 5/15-min steps, so sub-hourly cloud transients are not represented.
- **Synthetic forecast.** The forecast is a statistical corruption of the truth, not an NWP product, and its σ values are from the spec, not validated against a real feed for this site.
- **Electrical model.** The bus is idealised: no inverter standby or efficiency map on the battery path, no cable losses, no reactive power, no motor inrush on the pump. The LVD reconnect rule is assumed.
- **Battery parameters.** Battery thermal and ECM parameters are generic LFP values; ageing uses the spec's linear fade law, not a validated cell ageing model.
- **Cold store.** The cold-store thermal model is a first-order box. Excursion hours indicate direction, not food-safety compliance.
- **No field validation.** None of this has been validated against a running system; there is no measured site data yet.
