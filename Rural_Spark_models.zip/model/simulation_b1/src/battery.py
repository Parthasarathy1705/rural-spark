"""Battery pack model - Python twin of the MATLAB model in ../matlab/bp_*.m

The MATLAB files are the reference implementation (the team's battery pack model).
This module mirrors them line for line so that the full simulation can run where
MATLAB is not installed.  `tests/golden/battery_golden_*.csv` are produced by this
twin and `matlab/bp_verify_against_python.m` checks MATLAB reproduces them to 1e-9.

Backends
--------
BatteryPack(p, backend="python")  -> this file
BatteryPack(p, backend="matlab")  -> calls bp_limits / bp_step in MATLAB through
                                     the MATLAB Engine API for Python (matlab.engine)
"""
from __future__ import annotations
import math
from copy import deepcopy
from pathlib import Path

import numpy as np

MATLAB_DIR = Path(__file__).resolve().parents[1] / "matlab"


# ------------------------------------------------------------------ parameters
def bp_default_params(mode: str = "energy", E_nom_kWh: float | None = None) -> dict:
    p = dict(mode=mode,
             E_nom_kWh=20.0, eta_c=0.97, eta_d=0.97, soc_min=0.20, soc_max=1.00, c_rate=0.5,
             T_derate_C=45.0, derate_charge=0.5,
             cal_fade_per_year=0.015, cyc_fade_per_efc=5e-5, eol_capacity=0.80,
             capacity_factor0=1.0, update_capacity=0,
             C_th_J_per_K_per_kWh=7000.0, UA_W_per_K_per_kWh=1.0, T_enclosure_offset_C=2.0,
             Ns=16, Np=4, Q_Ah=100.0, V_nom=3.2, V_min=2.50, V_max=3.65,
             R0_ohm=0.0008, R1_ohm=0.0004, tau1_s=60.0, R0_temp_coeff=0.01,
             ocv_soc=[0.00, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95, 1.00],
             ocv_V=[2.50, 3.10, 3.20, 3.25, 3.28, 3.29, 3.30, 3.31, 3.32, 3.33, 3.35, 3.40, 3.55])
    if mode == "ecm":
        p["E_nom_kWh"] = p["Ns"] * p["Np"] * p["Q_Ah"] * p["V_nom"] / 1000
    if E_nom_kWh is not None:
        if mode == "ecm":
            p["Np"] = E_nom_kWh * 1000 / (p["Ns"] * p["Q_Ah"] * p["V_nom"])
        p["E_nom_kWh"] = float(E_nom_kWh)
    return p


def bp_init(p: dict, soc0: float, T0_C: float = 25.0) -> dict:
    s = dict(soc=float(soc0), T_C=float(T0_C), v_rc=0.0, efc=0.0, throughput_dis_kWh=0.0,
             throughput_ch_kWh=0.0, loss_kWh=0.0, age_years=0.0, cap=float(p["capacity_factor0"]))
    if s["soc"] < p["soc_min"] - 1e-12 or s["soc"] > p["soc_max"] + 1e-12:
        raise ValueError(f"initial SoC {soc0:.4f} outside [{p['soc_min']:.2f}, {p['soc_max']:.2f}]")
    return s


def bp_ocv(p: dict, soc: float) -> float:
    soc = min(max(soc, 0.0), 1.0)
    return float(np.interp(soc, p["ocv_soc"], p["ocv_V"]))


def _ecm_terms(p, s, dt_h):
    """Step-averaged ECM terms for a constant cell current over the step.
    v_rc(t) relaxes exponentially towards R1*I, so the step-mean polarisation voltage is
    v_avg = R1*I + (v0 - R1*I)*f with f = tau/dt*(1 - exp(-dt/tau)).  Mean terminal voltage is
    then a - I*Reff with a = Voc - v0*f and Reff = R0 + R1*(1 - f)."""
    voc = bp_ocv(p, s["soc"])
    R0 = p["R0_ohm"] * (1 + p["R0_temp_coeff"] * max(25 - s["T_C"], 0))
    dt_s = dt_h * 3600
    e = math.exp(-dt_s / p["tau1_s"])
    f = p["tau1_s"] / dt_s * (1 - e)
    a = voc - s["v_rc"] * f
    Reff = R0 + p["R1_ohm"] * (1 - f)
    return voc, R0, e, f, a, Reff


def _ecm_current_limits(p, s, dt_h, derated):
    voc, R0, e, f, a, Reff = _ecm_terms(p, s, dt_h)
    Q = p["Q_Ah"] * s["cap"]
    I_rate = p["c_rate"] * p["Q_Ah"]
    I_dis_soc = max(s["soc"] - p["soc_min"], 0) * Q / dt_h
    I_ch_soc = max(p["soc_max"] - s["soc"], 0) * Q / dt_h
    I_dis_v = max((a - p["V_min"]) / Reff, 0)
    I_ch_v = max((p["V_max"] - a) / Reff, 0)
    I_ch_rate = I_rate * p["derate_charge"] if derated else I_rate
    return min(I_rate, I_dis_soc, I_dis_v), min(I_ch_rate, I_ch_soc, I_ch_v), a, Reff


def bp_limits(p: dict, s: dict, dt_h: float) -> dict:
    derated = s["T_C"] > p["T_derate_C"]
    E_eff = p["E_nom_kWh"] * s["cap"]
    if p["mode"] == "energy":
        P_rate = p["c_rate"] * p["E_nom_kWh"]
        P_dis_soc = max(s["soc"] - p["soc_min"], 0) * E_eff * p["eta_d"] / dt_h
        P_ch_soc = max(p["soc_max"] - s["soc"], 0) * E_eff / (p["eta_c"] * dt_h)
        P_ch_rate = P_rate * p["derate_charge"] if derated else P_rate
        dis, ch = max(min(P_rate, P_dis_soc), 0), max(min(P_ch_rate, P_ch_soc), 0)
    else:
        I_dis, I_ch, a, Reff = _ecm_current_limits(p, s, dt_h, derated)
        dis = max(p["Ns"] * p["Np"] * I_dis * (a - I_dis * Reff) / 1000, 0)
        ch = max(p["Ns"] * p["Np"] * I_ch * (a + I_ch * Reff) / 1000, 0)
    return dict(P_dis_max_kW=dis, P_ch_max_kW=ch, derated=float(derated))


def bp_step(p: dict, s: dict, P_req_kW: float, dt_h: float, T_amb_C: float):
    s = dict(s)
    lim = bp_limits(p, s, dt_h)
    P = min(max(P_req_kW, -lim["P_ch_max_kW"]), lim["P_dis_max_kW"])
    out = dict(limited=float(abs(P - P_req_kW) > 1e-9), derated=lim["derated"])
    E_eff = p["E_nom_kWh"] * s["cap"]
    if p["mode"] == "energy":
        if P >= 0:
            dE = -P * dt_h / p["eta_d"]
            loss = P * dt_h * (1 / p["eta_d"] - 1)
        else:
            dE = -P * p["eta_c"] * dt_h
            loss = -P * dt_h * (1 - p["eta_c"])
        s["soc"] = s["soc"] + dE / E_eff
        out["V_pack"] = math.nan
        out["I_pack"] = math.nan
    else:
        voc, R0, e, f, a, Reff = _ecm_terms(p, s, dt_h)
        cells = p["Ns"] * p["Np"]
        P_cell_W = P * 1000 / cells
        I = 0.0 if abs(P_cell_W) < 1e-12 else (a - math.sqrt(a * a - 4 * Reff * P_cell_W)) / (2 * Reff)
        v_term = a - I * Reff                                   # step-mean terminal voltage
        C1 = p["tau1_s"] / p["R1_ohm"]
        v0 = s["v_rc"]
        v1 = v0 * e + p["R1_ohm"] * (1 - e) * I
        dE_cap = 0.5 * C1 * (v1 * v1 - v0 * v0) * cells / 3.6e6  # polarisation energy, kWh
        dE = -cells * voc * I * dt_h / 1000 + dE_cap             # chemical + polarisation store
        loss = -dE - P * dt_h                                    # = heat in R0 and R1 (>= 0)
        Q = p["Q_Ah"] * s["cap"]
        s["soc"] = s["soc"] - I * dt_h / Q
        s["v_rc"] = v1
        out["V_pack"] = p["Ns"] * v_term
        out["I_pack"] = p["Np"] * I
    if s["soc"] < p["soc_min"] - 1e-9 or s["soc"] > p["soc_max"] + 1e-9:
        raise AssertionError(f"SoC invariant violated: {s['soc']:.6f}")
    s["soc"] = min(max(s["soc"], p["soc_min"]), p["soc_max"])
    C_th = p["C_th_J_per_K_per_kWh"] * p["E_nom_kWh"]
    UA = p["UA_W_per_K_per_kWh"] * p["E_nom_kWh"]
    Q_heat_W = loss / dt_h * 1000
    T_air = T_amb_C + p["T_enclosure_offset_C"]
    T_inf = T_air + Q_heat_W / UA
    s["T_C"] = T_inf + (s["T_C"] - T_inf) * math.exp(-dt_h * 3600 * UA / C_th)
    if P > 0:
        s["throughput_dis_kWh"] += P * dt_h
        s["efc"] += P * dt_h / p["E_nom_kWh"]
    else:
        s["throughput_ch_kWh"] -= P * dt_h
    s["loss_kWh"] += loss
    s["age_years"] += dt_h / 8760
    if p["update_capacity"]:
        s["cap"] = p["capacity_factor0"] - p["cal_fade_per_year"] * s["age_years"] - p["cyc_fade_per_efc"] * s["efc"]
    out.update(P_kW=P, dE_kWh=dE, loss_kWh=loss)
    return s, out


def bp_life_projection(p: dict, efc_per_year: float) -> dict:
    fade = p["cal_fade_per_year"] + p["cyc_fade_per_efc"] * efc_per_year
    return dict(efc_per_year=efc_per_year, fade_per_year=fade,
                replacement_year=(1 - p["eol_capacity"]) / fade,
                calendar_share=p["cal_fade_per_year"] / fade,
                efc_per_year_for_11y=max(((1 - p["eol_capacity"]) / 11 - p["cal_fade_per_year"]) / p["cyc_fade_per_efc"], 0),
                efc_per_year_for_12y=max(((1 - p["eol_capacity"]) / 12 - p["cal_fade_per_year"]) / p["cyc_fade_per_efc"], 0))


# ------------------------------------------------------------------ object wrapper
class BatteryPack:
    """Stateful wrapper used by the engine.  backend = 'python' | 'matlab'."""

    def __init__(self, p: dict, soc0: float, T0_C: float = 25.0, backend: str = "python"):
        self.p = deepcopy(p)
        self.backend = backend
        if backend == "matlab":
            import matlab.engine  # type: ignore
            self._eng = matlab.engine.start_matlab()
            self._eng.addpath(str(MATLAB_DIR), nargout=0)
            self._mp = self._eng.bp_default_params(p["mode"], float(p["E_nom_kWh"]), nargout=1)
            for k, v in p.items():  # push any overrides
                if k in ("ocv_soc", "ocv_V"):
                    self._mp[k] = matlab.double(list(v))
                elif k != "mode":
                    self._mp[k] = float(v)
            self._ms = self._eng.bp_init(self._mp, float(soc0), float(T0_C), nargout=1)
        else:
            self.s = bp_init(self.p, soc0, T0_C)

    # state accessors used by the engine
    @property
    def state(self) -> dict:
        if self.backend == "matlab":
            return {k: float(self._ms[k]) for k in self._ms.keys()}
        return self.s

    def limits(self, dt_h: float) -> dict:
        if self.backend == "matlab":
            lim = self._eng.bp_limits(self._mp, self._ms, float(dt_h), nargout=1)
            return {k: float(v) for k, v in lim.items()}
        return bp_limits(self.p, self.s, dt_h)

    def step(self, P_req_kW: float, dt_h: float, T_amb_C: float) -> dict:
        if self.backend == "matlab":
            self._ms, out = self._eng.bp_step(self._mp, self._ms, float(P_req_kW), float(dt_h), float(T_amb_C), nargout=2)
            return {k: float(v) for k, v in out.items()}
        self.s, out = bp_step(self.p, self.s, P_req_kW, dt_h, T_amb_C)
        return out

    def usable_energy_kwh(self) -> float:
        """Energy deliverable at the terminals above the SoC floor (energy-mode estimate)."""
        st = self.state
        return max(st["soc"] - self.p["soc_min"], 0) * self.p["E_nom_kWh"] * st["cap"] * self.p["eta_d"]

    def headroom_kwh(self) -> float:
        """Terminal energy that can still be absorbed before SoC_max."""
        st = self.state
        return max(self.p["soc_max"] - st["soc"], 0) * self.p["E_nom_kWh"] * st["cap"] / self.p["eta_c"]
