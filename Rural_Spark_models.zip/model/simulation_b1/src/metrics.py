"""All KPIs (spec section 8).  Every result reports Tier 1 availability AND Tier 3 energy
delivered together (spec section 1)."""
from __future__ import annotations
import numpy as np
from battery import bp_life_projection
from loads import month_of_day


def _runs(mask):
    """Lengths (in steps) and start indices of consecutive True runs."""
    m = np.concatenate([[0], mask.astype(int), [0]])
    d = np.diff(m)
    starts, ends = np.where(d == 1)[0], np.where(d == -1)[0]
    return ends - starts, starts


def _reversals(x):
    rev, d = [float(x[0])], 0
    for v in x[1:]:
        v = float(v)
        if d == 0:
            if v != rev[-1]:
                d = 1 if v > rev[-1] else -1
                rev.append(v)
        elif (v - rev[-1]) * d > 0:
            rev[-1] = v
        elif (v - rev[-1]) * d < 0:
            rev.append(v)
            d = -d
    return rev


def rainflow(x):
    """ASTM E1049 three-point rainflow. Returns list of (range, count)."""
    stack, cycles = [], []
    for p in _reversals(x):
        stack.append(p)
        while len(stack) >= 3:
            X, Y = abs(stack[-1] - stack[-2]), abs(stack[-2] - stack[-3])
            if X < Y:
                break
            if len(stack) == 3:
                cycles.append((Y, 0.5))
                stack.pop(0)
            else:
                cycles.append((Y, 1.0))
                last = stack.pop(); stack.pop(); stack.pop(); stack.append(last)
    for k in range(len(stack) - 1):
        cycles.append((abs(stack[k + 1] - stack[k]), 0.5))
    return cycles


def gini(v):
    v = np.sort(np.asarray(v, float))
    if len(v) == 0 or v.sum() == 0:
        return 0.0
    n = len(v)
    return float((2 * np.arange(1, n + 1) - n - 1).dot(v) / (n * v.sum()))


def compute(sim) -> dict:
    lg, a = sim.log, sim.report_from
    dt_h, spd = sim.dt_h, sim.spd
    rep = slice(a, sim.L)
    days = (sim.L - a) / spd
    lvd = lg["lvd"][rep] > 0.5
    E = lambda x: float(np.sum(x[rep]) * dt_h)  # noqa: E731

    # ---- service
    t1_avail = 1.0 - lvd.mean()
    runs, starts = _runs(lvd)
    rep_days = range(sim.warm, len(sim.seq_days))
    pump_short = float(sum(sim.pump_short_kwh[d] for d in rep_days))
    t1_dem = E(lg["t1"]) + float(sim.dem.pump_kw * sim.dem.pump_minutes_per_day / 60 * days)
    t1_unserved = float(np.sum(lg["t1"][rep] * lvd) * dt_h) + pump_short
    t2_unserved = E(lg["d2"] - lg["s2"])
    bt = [b for b in sim.batches if b.seq_day >= sim.warm]
    req_e = sum(b.energy_kwh for b in bt)
    done = [b for b in bt if b.status == "done"]
    spoiled = [b for b in bt if b.status == "spoiled"]
    expired = [b for b in bt if b.status in ("expired", "pending", "waiting", "paused")]
    done_e = sum(b.energy_kwh for b in done)
    wasted_e = sum(b.consumed_kwh for b in spoiled)
    t3_batch_e = E(lg["s3b"])
    cold_e = E(lg["s3c"])
    # ---- curtailment events and advance warning
    ann = {}
    for (minute, tier, sd, _txt) in sim.announce:
        ann.setdefault((sd, tier), minute)
    events = []
    for tier, key in (("T2", "r2"), ("T3", "r3")):
        r = lg[key][rep]
        opens = np.where((r[1:] < 0.5) & (r[:-1] > 0.5))[0] + 1 + a
        for i in opens:
            events.append((tier, i * sim.dt, i // spd))
    for i in starts:   # LVD trips hit T2 and T3 customers too, never announced
        events.append(("LVD", (i + a) * sim.dt, (i + a) // spd))
    for b in bt:
        if b.status in ("expired", "pending", "waiting", "paused"):
            events.append(("T3", b.deadline, b.seq_day))
    warn = []
    for tier, minute, sd in events:
        ta = ann.get((sd, tier))
        warn.append(max(minute - ta, 0) if (ta is not None and ta <= minute) else 0.0)
    warn = np.array(warn) if warn else np.array([])
    # ---- asset
    pb = lg["pb"][rep]
    efc_rep = float(np.sum(np.maximum(pb, 0)) * dt_h / sim.bp["E_nom_kWh"])
    efc_yr = efc_rep * 365 / days
    cyc = rainflow(lg["soc"][rep][:: max(1, 15 // sim.dt)])
    big = [(r, c) for r, c in cyc if r >= 0.05]
    mean_dod = float(sum(r * c for r, c in big) / sum(c for r, c in big)) if big else 0.0
    life = bp_life_projection(sim.bp, efc_yr)
    trans = float((np.abs(np.diff(lg["r2"][rep])).sum() + np.abs(np.diff(lg["r3"][rep])).sum()) / days)
    daily_tr = (np.abs(np.diff(lg["r2"][a:])) + np.abs(np.diff(lg["r3"][a:])))
    max_tr_day = float(np.max(np.add.reduceat(daily_tr, np.arange(0, len(daily_tr), spd)))) if len(daily_tr) else 0.0
    # ---- equity: monthly Gini of served ratio across batch customers
    gin = []
    months = {}
    for b in bt:
        m = month_of_day(sim.seq_days[b.seq_day])
        months.setdefault(m, {}).setdefault(b.b.customer, [0.0, 0.0])
        months[m][b.b.customer][0] += b.energy_kwh
        months[m][b.b.customer][1] += b.energy_kwh if b.status == "done" else 0.0
    for m, cust in months.items():
        ratios = [d / r for r, d in cust.values() if r > 0]
        if len(ratios) >= 2:
            gin.append(gini(ratios))
    cold_exc_h = sim.cold_excursion_steps * dt_h
    out = dict(
        days=days, dt_min=sim.dt,
        pv_kwh=E(lg["pv"]),
        t1_availability_pct=100 * t1_avail,
        t1_interruptions=int(len(runs)), t1_longest_interruption_min=float(runs.max() * sim.dt) if len(runs) else 0.0,
        t1_unserved_kwh=t1_unserved, t1_demand_kwh=t1_dem,
        t2_unserved_kwh=t2_unserved, t2_demand_kwh=E(lg["d2"]), t2_served_pct=100 * (1 - t2_unserved / max(E(lg["d2"]), 1e-9)),
        t3_requested_batch_kwh=req_e, t3_completed_batch_kwh=done_e, t3_wasted_kwh=wasted_e,
        t3_unserved_kwh=req_e - done_e,
        t3_delivered_kwh=t3_batch_e + cold_e,            # energy delivered to Tier 3 circuits
        t3_useful_kwh=done_e + cold_e,                   # excluding energy burnt in spoiled batches
        cold_store_kwh=cold_e, cold_excursion_h=cold_exc_h,
        lolp_t1=float(lvd.mean()), lolp_t2=float(np.mean((lg["d2"][rep] - lg["s2"][rep]) > 1e-6)),
        lolp_t3_batches=float(1 - len(done) / len(bt)) if bt else 0.0,
        batches_requested=len(bt), batches_completed=len(done), batches_spoiled=len(spoiled), batches_unserved=len(expired),
        curtailment_events=int(len(warn)), warning_mean_min=float(warn.mean()) if len(warn) else 0.0,
        warning_p10_min=float(np.percentile(warn, 10)) if len(warn) else 0.0,
        warned_events_pct=float(100 * np.mean(warn > 0)) if len(warn) else 0.0,
        efc_per_year=efc_yr, mean_dod=mean_dod, dumped_kwh=E(lg["dump"]),
        relay_transitions_per_day=trans, relay_transitions_max_day=max_tr_day,
        replacement_year=life["replacement_year"],
        gini_t3_monthly_mean=float(np.mean(gin)) if gin else 0.0, gini_t3_monthly_max=float(np.max(gin)) if gin else 0.0,
        battery_max_temp_c=float(lg["tcell"][rep].max()), charge_derate_h=float(lg["derated"][rep].sum() * dt_h),
        soc_min_seen=float(lg["soc"][rep].min()), soc_max_seen=float(lg["soc"][rep].max()),
        energy_balance_max_resid_kwh=float(np.abs(lg["resid"][rep]).max()),
        hh_present_days=float(np.mean([sim.dem.present[d] for d in sim.seq_days[sim.warm:]])),
    )
    return out
