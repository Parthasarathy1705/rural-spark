"""Validation gates (spec section 10) evaluated from results/results.json -> results/gates.json"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
R = json.load(open(ROOT / "results" / "results.json"))
G = {}
mx = 0.0
for sid, s in R["scenarios"].items():
    for c, m in s["results"].items():
        mx = max(mx, m["energy_balance_max_resid_kwh"])
G["1_energy_balance"] = {"pass": mx < 1e-6, "max_abs_residual_kwh": mx,
                         "note": "asserted inside the engine every step at 0.1% relative; run aborts on violation"}
lo = min(m["soc_min_seen"] for s in R["scenarios"].values() for m in s["results"].values())
hi = max(m["soc_max_seen"] for s in R["scenarios"].values() for m in s["results"].values())
G["2_soc_bounds"] = {"pass": lo >= 0.2 - 1e-9 and hi <= 1.0 + 1e-9, "min_soc": lo, "max_soc": hi}
v = R["pv_validation"]["tilts"]["16"]
G["3_annual_yield_vs_pvgis"] = {"pass": abs(v["diff_pct"]) <= 5, **v}
r3 = R["scenarios"]["S3"]["results"]["reactive"]
G["4_reactive_fails_S3"] = {"pass": r3["t1_availability_pct"] < 100, "reactive_t1_availability_pct": r3["t1_availability_pct"],
                            "reactive_t1_unserved_kwh": r3["t1_unserved_kwh"], "blackouts": r3["t1_interruptions"]}
viol = []


def check(label, res):
    o, f, s = (res[c]["t1_availability_pct"] for c in ("oracle", "forecast_aware", "static"))
    if not (o >= f - 1e-9 and f >= s - 1e-9):
        viol.append({"case": label, "oracle": o, "forecast_aware": f, "static": s})


for sid, s in R["scenarios"].items():
    check(sid, s["results"])
for g, d in R["S8"].items():
    check(f"S8 +{g}", d)
for key in ("S5", "S6", "S5_stressed", "S6_stressed"):
    for v_, d in R[key].items():
        check(f"{key}={v_}", d)
G["5_oracle_ge_fa_ge_static"] = {"pass": not viol, "violations": viol}
t = subprocess.run([sys.executable, str(ROOT / "tests" / "run_tests.py")], capture_output=True, text=True)
G["6_tests_green"] = {"pass": t.returncode == 0, "output": t.stdout.strip().splitlines()}
G["all_pass"] = all(g["pass"] for k, g in G.items() if isinstance(g, dict) and "pass" in g)
json.dump(G, open(ROOT / "results" / "gates.json", "w"), indent=1)
print(json.dumps({k: (v["pass"] if isinstance(v, dict) else v) for k, v in G.items()}, indent=1))
