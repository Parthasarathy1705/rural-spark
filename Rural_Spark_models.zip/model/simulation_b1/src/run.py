"""Scenario runner.

    python src/run.py scenario scenarios/S3_overcast.yaml
    python src/run.py all                 # every scenario, sweeps, gates -> results/
"""
from __future__ import annotations
import copy
import json
import sys
import time
from pathlib import Path

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import pv as pvm                                    # noqa: E402
from sitedata import build_site                         # noqa: E402
from loads import LoadConfig, generate              # noqa: E402
from forecast import ForecastConfig, Forecaster     # noqa: E402
from battery import bp_default_params               # noqa: E402
from engine import EngineConfig, Simulation         # noqa: E402
from controllers import REGISTRY                    # noqa: E402
import metrics                                      # noqa: E402

CONTROLLERS = ["reactive", "static", "forecast_aware", "oracle"]
DEFAULT = dict(
    dt_min=5,
    pv=dict(kwp=10.0, tilt=16.0, derate_strings=0.0),
    battery=dict(mode="energy", E_nom_kWh=20.0, capacity_factor0=1.0),
    loads=dict(),
    forecast=dict(bias=0.0, sigma_override=None, outage_days=[], seed=2),
    controller_params=dict(),
    window=dict(kind="annual"),
)

_DEM = {}


def deep_update(a, b):
    out = copy.deepcopy(a)
    for k, v in (b or {}).items():
        out[k] = deep_update(out.get(k, {}), v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def _demand(lcfg: dict, dt_min: int):
    key = (json.dumps(lcfg, sort_keys=True), dt_min)
    if key not in _DEM:
        _DEM[key] = generate(LoadConfig(**lcfg), dt_min)
    return _DEM[key]


def find_windows(site) -> dict:
    spd = 1440 // site.dt_min
    e = site.pv_kw.reshape(-1, spd).sum(1) * site.dt_min / 60
    ms = np.cumsum([0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31])
    roll3 = np.array([e[d:d + 3].sum() if d + 3 <= len(e) else np.inf for d in range(len(e))])
    worst3 = int(np.argmin(roll3))
    mar = range(ms[2], ms[3] - 6)
    s1 = max(mar, key=lambda d: e[d:d + 7].sum())
    jul = range(ms[6], ms[7] - 6)
    s2 = max(jul, key=lambda d: e[d:d + 7].std())
    return dict(S1=int(s1), S2=int(s2), S3_worst3=worst3, S3=int(worst3 - 2), daily_pv_kwh=e.round(2).tolist(),
                worst3_kwh=e[worst3:worst3 + 3].round(2).tolist())


def build(case: dict, controller: str, battery_backend="python"):
    c = deep_update(DEFAULT, case)
    dt = int(c["dt_min"])
    pcfg = pvm.PVConfig(**c["pv"])
    site = build_site(pcfg, dt)
    dem = _demand(c["loads"], dt)
    b = c["battery"]
    bp = bp_default_params(b.get("mode", "energy"), b.get("E_nom_kWh", 20.0))
    bp["capacity_factor0"] = b.get("capacity_factor0", 1.0)
    fcfg = ForecastConfig(bias=c["forecast"].get("bias", 0.0), sigma_override=c["forecast"].get("sigma_override"),
                          seed=c["forecast"].get("seed", 2), outage_days=tuple(c["forecast"].get("outage_days", [])),
                          perfect=False)
    fc = Forecaster(site.pv_kw, site.kt_daily, dt, site.pac_max, fcfg)
    w = c["window"]
    if w["kind"] == "annual":
        start, n, warm = 0, 365, 14
    else:
        start, n, warm = int(w["start_day"]), int(w["n_days"]), int(w.get("warmup_days", 7))
    ctrl = REGISTRY[controller](**c.get("controller_params", {})) if controller in ("forecast_aware", "oracle") \
        else REGISTRY[controller]()
    ecfg = EngineConfig(dt_min=dt, battery_backend=battery_backend)
    sim = Simulation(site, dem, bp, ctrl, fc, ecfg, start, n, warm)
    return sim, c


def run_case(case: dict, controllers=CONTROLLERS, keep_sims=False):
    res, sims = {}, {}
    for ctl in controllers:
        t0 = time.time()
        sim, c = build(case, ctl)
        sim.run()
        m = metrics.compute(sim)
        m["runtime_s"] = round(time.time() - t0, 1)
        res[ctl] = m
        if keep_sims:
            sims[ctl] = sim
    return (res, sims) if keep_sims else res


def load_yaml(path):
    return yaml.safe_load(Path(path).read_text())


if __name__ == "__main__":
    if sys.argv[1] == "scenario":
        case = load_yaml(sys.argv[2])
        print(json.dumps(run_case(case), indent=1))
