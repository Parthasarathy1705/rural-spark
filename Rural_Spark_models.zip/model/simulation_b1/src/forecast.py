"""Imperfect day-ahead forecast generator (spec section 6).

GHI_forecast = GHI_true * (1 + eps),  eps ~ N(bias, sigma(sky))

  sky class from the day's clearness index Kt = GHI_day / extraterrestrial-horizontal_day
     clear      Kt >= 0.60   sigma = 0.07
     partly     0.40-0.60    sigma = 0.18
     overcast   Kt <  0.40   sigma = 0.28
  eps is drawn once per day (forecast errors are dominated by the day's weather regime) plus
  an hourly within-day shape error with sigma/2.  The day+1 forecast (issued a day earlier)
  uses sigma x 1.25.

Because PV output is proportional to irradiance to first order, the error is applied to the
PV AC power (equivalent to scaling GHI, DNI and DHI together).  Forecasts are clipped to the
inverter rating.  `outage_days` makes the fetch fail; the controller must then fall back.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np

SIGMA_BY_SKY = {"clear": 0.07, "partly": 0.18, "overcast": 0.28}


@dataclass
class ForecastConfig:
    bias: float = 0.0
    sigma_override: float | None = None   # S5: constant sigma for every sky class
    seed: int = 2
    perfect: bool = False                 # oracle
    outage_days: tuple = ()               # S7: days (0-based day of year) with no forecast
    hourly_shape_error: bool = True
    day2_sigma_factor: float = 1.25


def sky_class(kt):
    return np.where(kt >= 0.60, "clear", np.where(kt >= 0.40, "partly", "overcast"))


class Forecaster:
    def __init__(self, pv_true: np.ndarray, kt_daily: np.ndarray, dt_min: int, pac_max: float, cfg: ForecastConfig):
        self.cfg, self.dt_min = cfg, dt_min
        self.spd = 1440 // dt_min
        self.days = len(pv_true) // self.spd
        self.true = pv_true.reshape(self.days, self.spd)
        self.kt = kt_daily
        self.sky = sky_class(kt_daily)
        rng = np.random.default_rng(cfg.seed)
        sig = np.array([SIGMA_BY_SKY[s] for s in self.sky]) if cfg.sigma_override is None \
            else np.full(self.days, cfg.sigma_override)
        self.sigma = sig
        eps0 = rng.normal(cfg.bias, sig)                                   # same-day (issued 06:00 / day-ahead)
        eps1 = rng.normal(cfg.bias, sig * cfg.day2_sigma_factor)           # issued one day earlier
        sph = 60 // dt_min
        if cfg.hourly_shape_error:
            h0 = rng.normal(0, np.repeat(sig[:, None] / 2, 24, axis=1))
            h1 = rng.normal(0, np.repeat(sig[:, None] * cfg.day2_sigma_factor / 2, 24, axis=1))
            shape0, shape1 = np.repeat(h0, sph, axis=1), np.repeat(h1, sph, axis=1)
        else:
            shape0 = shape1 = np.zeros_like(self.true)
        if cfg.perfect:
            self.fc0 = self.true.copy()
            self.fc1 = self.true.copy()
        else:
            self.fc0 = np.clip(self.true * (1 + eps0[:, None]) * (1 + shape0), 0, pac_max)
            self.fc1 = np.clip(self.true * (1 + eps1[:, None]) * (1 + shape1), 0, pac_max)
        self.eps0, self.eps1 = eps0, eps1
        self.outage = set(int(d) % self.days for d in cfg.outage_days)

    def available(self, day: int) -> bool:
        return (day % self.days) not in self.outage

    def today(self, day: int) -> np.ndarray | None:
        """Forecast profile for `day` as seen on the morning of `day` (kW per step)."""
        d = day % self.days
        return None if d in self.outage else self.fc0[d]

    def tomorrow(self, day: int) -> np.ndarray | None:
        """Forecast for day+1 as seen on the morning of `day`."""
        if (day % self.days) in self.outage:
            return None
        return self.fc1[(day + 1) % self.days]


def daily_kt(ghi_steps: np.ndarray, cosz_steps: np.ndarray, doy_steps: np.ndarray, dt_min: int) -> np.ndarray:
    spd = 1440 // dt_min
    e0 = 1361.0 * (1 + 0.033 * np.cos(2 * np.pi * doy_steps / 365.0))
    etrh = e0 * np.maximum(cosz_steps, 0)
    g = ghi_steps.reshape(-1, spd).sum(1)
    e = etrh.reshape(-1, spd).sum(1)
    return np.where(e > 0, g / np.maximum(e, 1e-9), 0)
