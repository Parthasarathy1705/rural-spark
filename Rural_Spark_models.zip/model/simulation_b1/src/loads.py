"""Bottom-up stochastic demand, by tier (spec section 5).

Every appliance in every household is drawn as on/off *events* at 1-minute resolution
(start time, duration) and then averaged onto the simulation step.  Twenty-five households
give natural diversity; nothing is smoothed by hand.

Outputs (one non-leap year, local time IST, step dt):
  T1_base  kW  lights, phones, ANM sub-centre ILR + lighting   (never interruptible)
  T2_base  kW  fans, TVs, anganwadi/school, shops
  pump job      750 W, 2 x 1 h per day, daylight-schedulable    (Tier 1, scheduled by controller)
  batches       Tier 3 batch requests (honey: non-interruptible; leaf-plate: resumable)
  cold store    400 W compressor, thermal model lives in the engine

All probabilities, windows, seasonal calendars and ownership rates below are ASSUMPTIONS
made by the team for a 25-household Chenchu penta; they are listed in the README
assumptions table and should be replaced by survey data when available.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np

MIN_PER_DAY = 1440
DAYS = 365
JAN1_WEEKDAY = 4          # 2021-01-01 was a Friday (Mon = 0)
MONTH_START = np.cumsum([0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31])


def month_of_day(d):
    return int(np.searchsorted(MONTH_START, d, side="right"))  # 1..12


@dataclass
class LoadConfig:
    households: int = 25
    seed: int = 1
    growth: float = 0.0                 # S8: +0.20, +0.50 scales every appliance's power
    include_ilr: bool = True            # spec table lists the ANM ice-lined refrigerator (60 W, T1)
    tv_ownership: float = 0.40          # ASSUMED
    shops: int = 3                      # ASSUMED
    absent_fraction: float = 0.10       # ASSUMED baseline: 10% of households away...
    absent_start_day: int = 90          # ...from 1 April
    absent_days: int = 28               # ...for 4 weeks (NTFP collection in the forest)
    # Tier 3 customers (productive users)
    honey_units: int = 2
    leafplate_units: int = 2
    cold_store: bool = True


# seasonal probabilities, index 0 = Jan  (ASSUMED calendars)
FAN_USE = [0.10, 0.20, 0.60, 0.90, 0.95, 0.80, 0.40, 0.35, 0.40, 0.35, 0.15, 0.10]
HONEY_REQ = [0.10, 0.10, 0.70, 0.70, 0.70, 0.70, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10]   # honey flush Mar-Jun
LEAF_REQ = [0.90, 0.90, 0.60, 0.60, 0.60, 0.60, 0.30, 0.30, 0.30, 0.90, 0.90, 0.90]    # leaf plates, dry season
SCHOOL_VACATION = (113, 162)            # ~24 Apr - 11 Jun (Telangana school summer vacation)


@dataclass
class Batch:
    bid: int
    customer: str
    day: int
    release_min: int        # minute of year when the request becomes runnable
    deadline_min: int       # must be finished by
    power_kw: float
    duration_min: int
    interruptible: bool

    @property
    def energy_kwh(self):
        return self.power_kw * self.duration_min / 60


@dataclass
class Demand:
    dt_min: int
    T1_base: np.ndarray
    T2_base: np.ndarray
    parts: dict
    batches: list
    present: np.ndarray                 # households present, per day
    cfg: LoadConfig
    pump_kw: float = 0.75
    pump_minutes_per_day: int = 120
    cold_kw: float = 0.40

    @property
    def n(self):
        return len(self.T1_base)


class _Canvas:
    """Accumulate rectangular power events on a 1-minute grid via a difference array."""

    def __init__(self):
        self.diff = np.zeros(DAYS * MIN_PER_DAY + 1)

    def add(self, start_min, end_min, kw):
        start_min = np.clip(np.asarray(start_min, int), 0, DAYS * MIN_PER_DAY)
        end_min = np.clip(np.asarray(end_min, int), 0, DAYS * MIN_PER_DAY)
        ok = end_min > start_min
        np.add.at(self.diff, start_min[ok], kw if np.isscalar(kw) else np.asarray(kw)[ok])
        np.add.at(self.diff, end_min[ok], -(kw if np.isscalar(kw) else np.asarray(kw)[ok]))

    def series(self):
        return np.cumsum(self.diff[:-1])


def _to_steps(x_min, dt_min):
    return x_min.reshape(-1, dt_min).mean(axis=1)


def generate(cfg: LoadConfig | None = None, dt_min: int = 5) -> Demand:
    cfg = cfg or LoadConfig()
    rng = np.random.default_rng(cfg.seed)
    g = 1.0 + cfg.growth
    H, D = cfg.households, DAYS
    day0 = np.arange(D) * MIN_PER_DAY
    month = np.array([month_of_day(d) for d in range(D)])
    weekday = (np.arange(D) + JAN1_WEEKDAY) % 7

    # household presence (seasonal absence)
    present = np.ones((H, D), bool)
    n_abs = int(round(cfg.absent_fraction * H))
    if n_abs > 0 and cfg.absent_days > 0:
        away = rng.choice(H, n_abs, replace=False)
        s = cfg.absent_start_day
        present[away, s:s + cfg.absent_days] = False

    cv = {k: _Canvas() for k in ("lights", "phones", "fans", "tv", "ilr", "subcentre", "school", "shops")}
    U = lambda a, b, size=None: rng.uniform(a, b, size)  # noqa: E731

    tv_owner = rng.random(H) < cfg.tv_ownership
    for h in range(H):
        pres = present[h]
        dd = day0[pres]
        nd = len(dd)
        mth = month[pres]
        # LED lights x3, 7 W: evening 18:30-22:30 window with jitter, morning 05:00-06:30 subset
        start = dd + np.clip(rng.normal(18 * 60 + 40, 15, nd), 18 * 60 + 15, 19 * 60 + 15)
        for _ in range(3):
            end = dd + U(20 * 60 + 30, 22 * 60 + 45, nd)
            on = rng.random(nd) < 0.95
            cv["lights"].add(start[on], end[on], 0.007 * g)
        morn = rng.random(nd) < 0.6
        ms = dd + U(5 * 60, 5 * 60 + 45, nd)
        cv["lights"].add(ms[morn], (ms + U(30, 60, nd))[morn], 0.007 * g)
        second = morn & (rng.random(nd) < 0.5)
        cv["lights"].add(ms[second], (ms + 45)[second], 0.007 * g)
        # phone charger 10 W, mostly evening
        charge = rng.random(nd) < 0.9
        evening = rng.random(nd) < 0.7
        st = dd + np.where(evening, U(18 * 60, 22 * 60, nd), U(8 * 60, 17 * 60, nd))
        cv["phones"].add(st[charge], (st + U(90, 180, nd))[charge], 0.010 * g)
        # BLDC fan 30 W, seasonal: 11:00-16:00 and 21:00-03:00
        use = rng.random(nd) < np.array(FAN_USE)[mth - 1]
        day_use = use & (rng.random(nd) < 0.6)
        cv["fans"].add((dd + U(11 * 60, 12.5 * 60, nd))[day_use], (dd + U(15 * 60, 16 * 60, nd))[day_use], 0.030 * g)
        night = use & (rng.random(nd) < 0.9)
        cv["fans"].add((dd + 21 * 60)[night], (dd + U(24.5 * 60, 27 * 60, nd))[night], 0.030 * g)
        # TV 60 W, 19:00-22:00, owners only
        if tv_owner[h]:
            watch = rng.random(nd) < 0.85
            cv["tv"].add((dd + U(19 * 60, 19.75 * 60, nd))[watch], (dd + U(21.25 * 60, 22 * 60, nd))[watch], 0.060 * g)

    # ANM sub-centre: ILR 60 W continuous (T1), lighting 40 W 18-22 + on-call nights
    if cfg.include_ilr:
        cv["ilr"].add(np.array([0]), np.array([D * MIN_PER_DAY]), 0.060 * g)
    cv["subcentre"].add(day0 + 18 * 60, day0 + 22 * 60, 0.040 * g)
    oncall = rng.random(D) < 0.2
    oc = day0 + U(22 * 60, 29 * 60, D)
    cv["subcentre"].add(oc[oncall], (oc + 60)[oncall], 0.040 * g)
    # anganwadi / school 300 W 09-16 weekdays (anganwadi only, 120 W, during school vacation)
    wk = weekday < 5
    vac = (np.arange(D) >= SCHOOL_VACATION[0]) & (np.arange(D) < SCHOOL_VACATION[1])
    kw = np.where(vac, 0.12, 0.30) * U(0.6, 1.0, D) * g
    cv["school"].add((day0 + 9 * 60)[wk], (day0 + 16 * 60)[wk], kw[wk])
    # shops 150 W each 08:00-20:00
    for _ in range(cfg.shops):
        openday = rng.random(D) < 0.95
        cv["shops"].add((day0 + U(7.5 * 60, 8.5 * 60, D))[openday], (day0 + U(19.5 * 60, 20.5 * 60, D))[openday], 0.150 * g)

    parts = {k: _to_steps(c.series(), dt_min) for k, c in cv.items()}
    T1 = parts["lights"] + parts["phones"] + parts["ilr"] + parts["subcentre"]
    T2 = parts["fans"] + parts["tv"] + parts["school"] + parts["shops"]

    # Tier 3 batch requests
    batches, bid = [], 0
    for d in range(D):
        m = month[d] - 1
        for u in range(cfg.honey_units):
            if rng.random() < HONEY_REQ[m]:
                rel = int(day0[d] + U(8 * 60, 10 * 60))
                batches.append(Batch(bid, f"honey_{chr(65 + u)}", d, rel, int(day0[d] + 20 * 60), 1.5 * g, 180, False)); bid += 1
        for u in range(cfg.leafplate_units):
            if rng.random() < LEAF_REQ[m]:
                rel = int(day0[d] + U(8 * 60, 11 * 60))
                batches.append(Batch(bid, f"leafplate_{chr(65 + u)}", d, rel, int(day0[d] + 19 * 60), 1.1 * g, 120, True)); bid += 1
    for b in batches:  # round to the step grid
        b.release_min = int(np.ceil(b.release_min / dt_min) * dt_min)
        b.deadline_min = int(b.deadline_min // dt_min * dt_min)
        b.duration_min = int(np.ceil(b.duration_min / dt_min) * dt_min)

    return Demand(dt_min=dt_min, T1_base=T1, T2_base=T2, parts=parts, batches=batches,
                  present=present.sum(axis=0), cfg=cfg, pump_kw=0.75 * g, cold_kw=0.40 * g)


def daily_summary(dem: Demand) -> dict:
    spd = MIN_PER_DAY // dem.dt_min
    h = dem.dt_min / 60
    out = {k: float(v.sum() * h / DAYS) for k, v in dem.parts.items()}
    out["T1_base"] = float(dem.T1_base.sum() * h / DAYS)
    out["pump"] = dem.pump_kw * dem.pump_minutes_per_day / 60
    out["T2_base"] = float(dem.T2_base.sum() * h / DAYS)
    out["T3_batches"] = float(sum(b.energy_kwh for b in dem.batches) / DAYS)
    out["peak_T1_T2_kw"] = float((dem.T1_base + dem.T2_base).max())
    return out


if __name__ == "__main__":
    import json
    dem = generate()
    print(json.dumps({k: round(v, 3) for k, v in daily_summary(dem).items()}, indent=1))
