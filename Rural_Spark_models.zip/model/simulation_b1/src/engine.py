"""Time-step simulation engine: energy balance, relays, batches, cold store, LVD.

Physical model of the bus (single AC bus, grid-forming inverter):
  * Tier 1 circuits are NORMALLY CLOSED and never opened by any controller.
  * If PV + the battery's discharge limit cannot cover the connected load, the inverter
    trips on low-voltage disconnect (LVD): every tier goes dark until SoC recovers to
    soc_min + `lvd_reconnect` (PV keeps charging the pack while the bus is down).
  * A non-interruptible batch (honey) that loses power is SPOILED; a resumable batch
    (leaf-plate press) is paused and can resume before its deadline.

Energy balance asserted every step (spec section 10, gate 1):
  generation = load_served + dumped + dE_battery + battery_losses
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np

from battery import BatteryPack
from loads import Demand, Batch

MIN_PER_DAY = 1440


@dataclass
class EngineConfig:
    dt_min: int = 5
    soc0: float = 0.60
    lvd_reconnect: float = 0.05          # reconnect at soc_min + 5 points
    cold_tau_h: float = 24.0             # ASSUMED cold-room loss time constant
    cold_pull_c_per_h: float = 2.5       # ASSUMED cooling rate with compressor on
    cold_limit_c: float = 8.0            # cold-chain excursion threshold
    cold_T0: float = 4.0
    balance_tol_rel: float = 1e-3        # 0.1% (spec)
    battery_backend: str = "python"


@dataclass
class BatchState:
    b: Batch
    release: int            # sequence minute
    deadline: int
    status: str = "pending" # pending -> waiting -> running/paused -> done | spoiled | expired
    remaining: int = 0
    consumed_kwh: float = 0.0
    planned_start: int | None = None
    started_at: int | None = None
    seq_day: int = 0

    @property
    def energy_kwh(self):
        return self.b.energy_kwh

    @property
    def remaining_kwh(self):
        return self.b.power_kw * self.remaining / 60


@dataclass
class Action:
    relay2: bool = True
    relay3: bool = True
    pump: bool = False
    start: list = field(default_factory=list)
    cold_band: tuple = (2.0, 5.0)


class Simulation:
    def __init__(self, site, demand: Demand, batt_params: dict, controller, forecaster, cfg: EngineConfig,
                 start_day: int, n_days: int, warmup_days: int):
        assert site.dt_min == demand.dt_min == cfg.dt_min
        self.site, self.dem, self.cfg, self.ctrl, self.fc = site, demand, cfg, controller, forecaster
        self.bp = batt_params
        self.dt = cfg.dt_min
        self.dt_h = self.dt / 60
        self.spd = MIN_PER_DAY // self.dt
        self.sph = 60 // self.dt
        self.year_days = len(site.pv_kw) // self.spd
        self.warm = warmup_days
        first = (start_day - warmup_days) % self.year_days
        self.seq_days = [(first + i) % self.year_days for i in range(warmup_days + n_days)]
        self.L = len(self.seq_days) * self.spd
        self.seq = np.concatenate([np.arange(d * self.spd, (d + 1) * self.spd) for d in self.seq_days])
        self.report_from = warmup_days * self.spd
        # batch instances on the sequence clock
        by_day = {}
        for b in demand.batches:
            by_day.setdefault(b.day, []).append(b)
        self.batches = []
        self.batches_by_seqday = {}
        for sd, yd in enumerate(self.seq_days):
            lst = []
            for b in by_day.get(yd, []):
                off = sd * MIN_PER_DAY - yd * MIN_PER_DAY
                st = BatchState(b, b.release_min + off, b.deadline_min + off, remaining=b.duration_min, seq_day=sd)
                lst.append(st)
                self.batches.append(st)
            self.batches_by_seqday[sd] = lst
        L = self.L
        z = lambda: np.zeros(L)  # noqa: E731
        self.log = dict(pv=z(), t1=z(), pump=z(), pump_sched=z(), d2=z(), s1=z(), s2=z(), s3b=z(), s3c=z(), soc=z(),
                        r2=z(), r3=z(), dump=z(), lvd=z(), pb=z(), tcell=z(), tbox=z(), resid=z(), derated=z(),
                        temp=z(), limited=z(), preq=z())
        self.pump_short_kwh = np.zeros(len(self.seq_days))
        self.cold_excursion_steps = 0
        self.announce = []          # (seq_minute, tier, seq_day, text)

    # ------------------------------------------------------------------ helpers
    def year_index(self, i):
        return int(self.seq[i])

    def minute(self, i):
        return i * self.dt

    def announce_event(self, i, tier, text=""):
        self.announce.append((i * self.dt, tier, i // self.spd, text))

    # ------------------------------------------------------------------ main loop
    def run(self):
        cfg, dt_h, spd = self.cfg, self.dt_h, self.spd
        batt = BatteryPack(self.bp, cfg.soc0, float(self.site.temp_c[self.seq[0]]), backend=cfg.battery_backend)
        self.batt = batt
        soc_min = self.bp["soc_min"]
        lvd = False
        pump_done = 0
        tbox, cold_on = cfg.cold_T0, False
        active = []
        self.ctrl.setup(self)
        dem, site, log = self.dem, self.site, self.log
        for i in range(self.L):
            yk = self.seq[i]
            sd, j = divmod(i, spd)
            now = i * self.dt
            if j == 0:
                pump_done = 0
                active = [b for b in active if b.status in ("waiting", "running", "paused")] + \
                         list(self.batches_by_seqday.get(sd, []))
            for b in active:
                if b.status == "pending" and b.release <= now:
                    b.status = "waiting"
            pv = float(site.pv_kw[yk]); Ta = float(site.temp_c[yk])
            st = batt.state
            if lvd and st["soc"] >= soc_min + cfg.lvd_reconnect - 1e-12:
                lvd = False
            self.obs = dict(i=i, sd=sd, j=j, now=now, yk=yk, pv=pv, Ta=Ta, soc=st["soc"], cap=st["cap"], lvd=lvd,
                            pump_done=pump_done, tbox=tbox, active=active)
            act: Action = self.ctrl.step(i, self.obs)
            for b in act.start:
                if b.status in ("waiting", "paused") and b.remaining > 0:
                    b.status = "running"
                    if b.started_at is None:
                        b.started_at = now
            # thermostat
            lo, hi = act.cold_band
            if dem.cfg.cold_store:
                if tbox > hi:
                    cold_on = True
                elif tbox < lo:
                    cold_on = False
            r2, r3 = bool(act.relay2), bool(act.relay3)
            t1 = float(dem.T1_base[yk])
            pump_on = bool(act.pump) and pump_done < dem.pump_minutes_per_day
            d_pump = dem.pump_kw if pump_on else 0.0
            d2_req = float(dem.T2_base[yk])
            d2 = d2_req if r2 else 0.0
            running = [b for b in active if b.status == "running"]
            d3b = sum(b.b.power_kw for b in running) if r3 else 0.0
            d3c = dem.cold_kw if (cold_on and r3 and dem.cfg.cold_store) else 0.0
            D = t1 + d_pump + d2 + d3b + d3c
            lim = batt.limits(dt_h)
            bus_up = not lvd
            if bus_up:
                net = pv - D
                if net < 0 and -net > lim["P_dis_max_kW"] + 1e-9:
                    bus_up = False
                    lvd = True
            p_req = -(pv - D) if bus_up else -pv
            if bus_up:
                out = batt.step(-(pv - D), dt_h, Ta)
                served = D
                dump = pv + out["P_kW"] - D
            else:
                out = batt.step(-pv, dt_h, Ta)
                served = 0.0
                dump = pv + out["P_kW"]
            # energy balance (kWh this step)
            gen = pv * dt_h
            resid = gen - (served * dt_h + dump * dt_h + out["dE_kWh"] + out["loss_kWh"])
            scale = max(gen, served * dt_h, 1e-6)
            if abs(resid) > cfg.balance_tol_rel * scale:
                raise AssertionError(f"energy balance residual {resid:.3g} kWh at step {i}")
            if dump < -1e-9:
                raise AssertionError(f"negative dump {dump} at step {i}")
            # consequences for loads
            if bus_up:
                if pump_on:
                    pump_done += self.dt
                for b in running:
                    if r3:
                        b.remaining -= self.dt
                        b.consumed_kwh += b.b.power_kw * dt_h
                        if b.remaining <= 0:
                            b.status = "done"
                    else:
                        self._interrupt(b)
            else:
                for b in running:
                    self._interrupt(b)
            comp = (d3c > 0) and bus_up
            tair = Ta + 2.0
            tbox += ((tair - tbox) / cfg.cold_tau_h - (cfg.cold_pull_c_per_h if comp else 0.0)) * dt_h
            if dem.cfg.cold_store and tbox > cfg.cold_limit_c and i >= self.report_from:
                self.cold_excursion_steps += 1
            # expiry at deadline
            for b in active:
                if b.status in ("pending", "waiting", "paused") and now + self.dt >= b.deadline:
                    b.status = "expired"
            if j == spd - 1:
                short = max(dem.pump_minutes_per_day - pump_done, 0)
                self.pump_short_kwh[sd] = dem.pump_kw * short / 60
            st = batt.state
            L = log
            L["pv"][i] = pv; L["t1"][i] = t1; L["pump"][i] = d_pump if bus_up else 0.0
            L["pump_sched"][i] = d_pump; L["d2"][i] = d2_req
            L["s1"][i] = (t1 + d_pump) if bus_up else 0.0
            L["s2"][i] = d2 if bus_up else 0.0
            L["s3b"][i] = d3b if bus_up else 0.0
            L["s3c"][i] = d3c if bus_up else 0.0
            L["soc"][i] = st["soc"]; L["r2"][i] = r2; L["r3"][i] = r3; L["dump"][i] = dump
            L["lvd"][i] = 0.0 if bus_up else 1.0; L["pb"][i] = out["P_kW"]; L["tcell"][i] = st["T_C"]
            L["tbox"][i] = tbox; L["resid"][i] = resid; L["derated"][i] = out["derated"]; L["temp"][i] = Ta
            L["limited"][i] = out["limited"]; L["preq"][i] = p_req
            self.ctrl.after_step(i, self.obs, dict(served2=(d2 if bus_up else 0.0), served3=(d3b + d3c) if bus_up else 0.0,
                                                   bus_up=bus_up, d2_req=d2_req, r2=r2))
        self.batt_final = batt.state
        return self

    def replay_table(self):
        """Per-step battery requests for matlab/bp_replay.m (whole sequence incl. warm-up)."""
        import numpy as np
        n = self.L
        t_h = np.arange(n) * self.dt_h
        return np.column_stack([t_h, self.log["preq"], np.full(n, self.dt_h), self.log["temp"], self.log["soc"],
                                np.full(n, self.bp["E_nom_kWh"]), np.full(n, self.bp["capacity_factor0"]),
                                np.full(n, self.cfg.soc0)])

    def _interrupt(self, b: BatchState):
        if b.b.interruptible:
            b.status = "paused"
        else:
            b.status = "spoiled"
