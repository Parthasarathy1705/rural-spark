"""Run every scenario, sweep and gate; write results/.

    python src/experiments.py            (about 5-10 minutes on a laptop)
"""
from __future__ import annotations
import copy
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import run                                        # noqa: E402
import pv as pvm                                  # noqa: E402
from sitedata import build_site                   # noqa: E402
from battery import bp_default_params, bp_life_projection  # noqa: E402

RES = ROOT / "results"
SC = ROOT / "scenarios"
CTRL = run.CONTROLLERS


def _num(v):
    if isinstance(v, (np.floating, np.integer)):
        return v.item()
    return v


def clean(d):
    if isinstance(d, dict):
        return {k: clean(v) for k, v in d.items()}
    if isinstance(d, list):
        return [clean(v) for v in d]
    return _num(d)


def resolve_window(case, windows):
    w = case.get("window", {"kind": "annual"})
    if w.get("kind") == "auto":
        start = windows[w["which"]]
        case = run.deep_update(case, {"window": {"kind": "window", "start_day": start}})
    return case


def set_key(case, dotted, value):
    a, b = dotted.split(".")
    return run.deep_update(case, {a: {b: value}})


def mean_over_seeds(case, seeds, controllers=CTRL):
    runs = [run.run_case(run.deep_update(case, {"forecast": {"seed": s}}), controllers) for s in seeds]
    out = {}
    for c in controllers:
        keys = runs[0][c].keys()
        out[c] = {k: float(np.mean([r[c][k] for r in runs])) for k in keys}
        out[c]["seed_min_t1_availability_pct"] = float(min(r[c]["t1_availability_pct"] for r in runs))
        out[c]["seed_max_t1_unserved_kwh"] = float(max(r[c]["t1_unserved_kwh"] for r in runs))
    return out


def main():
    t0 = time.time()
    RES.mkdir(exist_ok=True)
    (RES / "replay").mkdir(exist_ok=True)
    R = {"meta": {}}
    site5 = build_site(pvm.PVConfig(), 5)
    windows = run.find_windows(site5)
    R["windows"] = {k: v for k, v in windows.items() if k != "daily_pv_kwh"}
    R["pv_validation"] = pvm.validation_report()

    # ---- S1, S2, S3, S4, S9, S10, S11 (single cases)
    singles = ["S1_clear_march", "S2_monsoon_july", "S3_overcast", "S4_annual", "S9_battery_eol", "S10_string_down",
               "S11_absence"]
    R["scenarios"] = {}
    for name in singles:
        case = resolve_window(run.load_yaml(SC / f"{name}.yaml"), windows)
        res, sims = run.run_case(case, keep_sims=True)
        R["scenarios"][case["id"]] = {"title": case["title"], "dt_min": case["dt_min"], "results": res}
        if case["id"] in ("S3", "S1", "S2"):
            for c, sim in sims.items():
                np.savetxt(RES / "replay" / f"{case['id']}_{c}.csv", sim.replay_table(), delimiter=",", fmt="%.10g",
                           header="t_h,P_req_kW,dt_h,T_amb_C,soc_python,E_nom_kWh,capacity_factor0,soc0", comments="")
            if case["id"] == "S3":
                import pickle
                keep = {c: dict(log={k: v for k, v in s.log.items()}, report_from=s.report_from, spd=s.spd, dt=s.dt,
                                seq_days=s.seq_days, warm=s.warm, announce=s.announce,
                                fc0=[s.fc.fc0[d] for d in s.seq_days], true=[s.fc.true[d] for d in s.seq_days],
                                batches=[(b.b.customer, b.seq_day, b.status, b.release, b.started_at, b.deadline,
                                          b.b.power_kw, b.b.duration_min) for b in s.batches])
                        for c, s in sims.items()}
                pickle.dump(keep, open(RES / "S3_logs.pkl", "wb"))
        print(f"{case['id']} done {time.time() - t0:.0f}s", flush=True)

    # ---- S4 robustness over load + forecast seeds
    rob = {}
    for seed in (1, 2, 3, 4, 5):
        r = run.run_case({"dt_min": 15, "loads": {"seed": seed}, "forecast": {"seed": seed + 10}})
        rob[seed] = r
    R["S4_seed_robustness"] = {c: {k: [rob[s][c][k] for s in rob] for k in ("t1_availability_pct", "t1_unserved_kwh",
                                   "t2_served_pct", "t3_useful_kwh", "batches_spoiled", "cold_excursion_h")} for c in CTRL}
    print(f"robustness done {time.time() - t0:.0f}s", flush=True)

    # ---- S4 with the ECM (cell-level) battery pack
    r = run.run_case({"dt_min": 15, "battery": {"mode": "ecm", "E_nom_kWh": 20.0}})
    R["S4_ecm_battery"] = r

    # ---- S5 sigma sweep
    y = run.load_yaml(SC / "S5_sigma_sweep.yaml")
    base = {k: v for k, v in y.items() if k not in ("sweep", "seeds")}
    R["S5"] = {}
    for v in y["sweep"]["values"]:
        R["S5"][str(v)] = mean_over_seeds(set_key(base, y["sweep"]["key"], v), y["seeds"], ["static", "forecast_aware", "oracle"])
    print(f"S5 done {time.time() - t0:.0f}s", flush=True)

    # ---- S6 bias sweep + derate search
    y = run.load_yaml(SC / "S6_bias_sweep.yaml")
    base = {k: v for k, v in y.items() if k not in ("sweep", "seeds", "derate_search")}
    R["S6"] = {}
    for v in y["sweep"]["values"]:
        R["S6"][str(v)] = mean_over_seeds(set_key(base, y["sweep"]["key"], v), y["seeds"], ["static", "forecast_aware", "oracle"])
    ds = y["derate_search"]
    R["S6_derate_search"] = []
    ref = R["S6"]["0.0"]["forecast_aware"]
    needed = None
    for dr in ds["derates"]:
        c = set_key(base, "forecast.bias", ds["bias"])
        c = run.deep_update(c, {"controller_params": {"derate": dr}})
        m = mean_over_seeds(c, y["seeds"], ["forecast_aware"])["forecast_aware"]
        ok = m["seed_max_t1_unserved_kwh"] <= ref["seed_max_t1_unserved_kwh"] + 1e-6
        R["S6_derate_search"].append({"derate": dr, "t1_unserved_kwh_max_over_seeds": m["seed_max_t1_unserved_kwh"],
                                      "t1_availability_pct": m["t1_availability_pct"], "t3_useful_kwh": m["t3_useful_kwh"],
                                      "t2_served_pct": m["t2_served_pct"], "tier1_intact": ok})
        if ok and needed is None:
            needed = dr
    R["S6_derate_needed_at_plus20pct_bias"] = needed
    print(f"S6 done {time.time() - t0:.0f}s", flush=True)

    # ---- S5/S6 again under stress (+50% load): at baseline load the system has so much margin
    #      that forecast quality barely matters; the stressed runs are the real robustness test
    stress = {"dt_min": 15, "window": {"kind": "annual"}, "loads": {"growth": 0.5}}
    R["S5_stressed"] = {str(v): mean_over_seeds(set_key(stress, "forecast.sigma_override", v), [2, 3, 4],
                                                ["static", "forecast_aware", "oracle"]) for v in (0.0, 0.1, 0.2, 0.3)}
    R["S6_stressed"] = {str(v): mean_over_seeds(set_key(stress, "forecast.bias", v), [2, 3, 4],
                                                ["static", "forecast_aware", "oracle"]) for v in (0.0, 0.1, 0.2)}
    R["derate_curve_stressed_bias20"] = []
    for dr in (0.0, 0.1, 0.2, 0.3, 0.4):
        c = run.deep_update(set_key(stress, "forecast.bias", 0.2), {"controller_params": {"derate": dr}})
        m = mean_over_seeds(c, [2, 3, 4], ["forecast_aware"])["forecast_aware"]
        R["derate_curve_stressed_bias20"].append({"derate": dr, **{k: m[k] for k in (
            "t1_availability_pct", "seed_max_t1_unserved_kwh", "t2_served_pct", "t3_useful_kwh", "cold_excursion_h")}})
    R["ablation_stressed_bias20"] = {}
    for name, cp in {"full_design": {}, "no_lookahead": {"lookahead": False}, "no_derate": {"derate": 0.0},
                     "reserve_x1.0": {"reserve_multiplier": 1.0},
                     "spec_text_only (x1.0, no derate, no lookahead)": {"reserve_multiplier": 1.0, "derate": 0.0, "lookahead": False},
                     "no_solar_direct": {"solar_direct": False}, "no_precool": {"precool": False}}.items():
        c = run.deep_update(set_key(stress, "forecast.bias", 0.2), {"controller_params": cp})
        m = mean_over_seeds(c, [2, 3, 4], ["forecast_aware"])["forecast_aware"]
        R["ablation_stressed_bias20"][name] = {k: m[k] for k in ("t1_availability_pct", "seed_max_t1_unserved_kwh",
                                               "t2_served_pct", "t3_useful_kwh", "cold_excursion_h", "batches_spoiled")}
    print(f"stressed sweeps done {time.time() - t0:.0f}s", flush=True)

    # ---- S7 forecast outage during the overcast spell
    y = run.load_yaml(SC / "S7_forecast_outage.yaml")
    case = resolve_window({k: v for k, v in y.items() if k not in ("outage", "variants")}, windows)
    od = [windows[y["outage"]["which"]] + k for k in range(y["outage"]["days"])]
    R["S7"] = {"outage_days": od, "with_forecast": run.run_case(case, ["forecast_aware"])["forecast_aware"]}
    for name, params in y["variants"].items():
        c = run.deep_update(case, {"forecast": {"outage_days": od}, "controller_params": params})
        R["S7"][name] = run.run_case(c, ["forecast_aware"])["forecast_aware"]
    R["S7"]["static_controller"] = R["scenarios"]["S3"]["results"]["static"]
    print(f"S7 done {time.time() - t0:.0f}s", flush=True)

    # ---- S8 load growth
    y = run.load_yaml(SC / "S8_load_growth.yaml")
    base = {k: v for k, v in y.items() if k not in ("sweep",)}
    R["S8"] = {str(v): run.run_case(set_key(base, "loads.growth", v)) for v in y["sweep"]["values"]}
    print(f"S8 done {time.time() - t0:.0f}s", flush=True)

    # ---- tilt sweep (energy + service)
    R["tilt"] = {}
    for t in (10.0, 16.0, 22.0):
        r = run.run_case({"dt_min": 15, "pv": {"tilt": t}}, ["forecast_aware"])["forecast_aware"]
        st = build_site(pvm.PVConfig(tilt=t), 15)
        e = st.pv_kw.reshape(-1, 96).sum(1) * 0.25
        mon = pd.Series(e, index=pd.date_range("2021-01-01", periods=365)).groupby(lambda d: d.month).sum()
        R["tilt"][str(t)] = {"annual_kwh": float(e.sum()), "jun_sep_kwh": float(mon.loc[6:9].sum()),
                             "worst_month_kwh": float(mon.min()), "t1_availability_pct": r["t1_availability_pct"],
                             "t3_useful_kwh": r["t3_useful_kwh"], "t2_served_pct": r["t2_served_pct"]}
    print(f"tilt done {time.time() - t0:.0f}s", flush=True)

    # ---- sizing sweep
    y = run.load_yaml(SC / "sizing_sweep.yaml")
    rows = []
    pts = [(a, b, "") for a in y["array_kwp"] for b in y["battery_kwh"]] + \
          [(p["kwp"], p["kwh"], p["label"]) for p in y["extra_points"]]
    for a, b, lab in pts:
        r = run.run_case({"dt_min": 15, "pv": {"kwp": float(a)}, "battery": {"E_nom_kWh": float(b)}}, y["controllers"])
        for c in y["controllers"]:
            m = r[c]
            rows.append(dict(array_kwp=a, battery_kwh=b, label=lab, controller=c, **{k: m[k] for k in (
                "t1_availability_pct", "t1_unserved_kwh", "t1_interruptions", "t2_served_pct", "t3_useful_kwh",
                "t3_completed_batch_kwh", "batches_spoiled", "cold_excursion_h", "dumped_kwh", "pv_kwh", "efc_per_year",
                "replacement_year")}))
    sz = pd.DataFrame(rows)
    sz.to_csv(RES / "sizing_sweep.csv", index=False)
    R["sizing"] = rows
    print(f"sizing done {time.time() - t0:.0f}s", flush=True)

    # ---- battery life
    bp = bp_default_params()
    R["battery_life"] = {c: bp_life_projection(bp, R["scenarios"]["S4"]["results"][c]["efc_per_year"]) for c in CTRL}
    R["meta"]["runtime_s"] = round(time.time() - t0, 1)
    json.dump(clean(R), open(RES / "results.json", "w"), indent=1)
    print("all done", R["meta"]["runtime_s"])


if __name__ == "__main__":
    main()
