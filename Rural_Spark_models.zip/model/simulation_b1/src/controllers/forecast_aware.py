"""Forecast-aware tiered dispatch (OURS) - spec section 7.

Three layers:
  1. Daily plan at 06:00: waterfall allocation of (battery above floor + PESSIMISTIC forecast
     generation - Tier 1 night reserve) to Tier 1 -> Tier 2 -> Tier 3, then Tier 3 batches are
     placed, whole, inside the forecast generation peak.
  2. Hourly correction: the same waterfall recomputed with measured SoC and with the remaining
     forecast scaled by (measured PV so far / forecast so far) when generation is tracking low.
  3. Real-time enforcement every step: Tier 2 budget latch, SoC hysteresis back-stops with a
     15-minute minimum dwell, and the batch integrity gate (never start what you cannot finish).

Design decisions beyond the spec text (all switchable, listed in README):
  * day+1 look-ahead: if tomorrow's derated forecast cannot cover tomorrow's Tier 1 needs, the
    shortfall is added to tonight's reserve (`lookahead`).
  * planned Tier 3 (an approved, gated batch) may run down to the Tier 2 cut band (0.38) instead
    of the static 0.55 band, because the plan has already reserved Tier 1 energy; unplanned Tier 3
    use (the cold store at night) keeps the 0.55/0.68 band.  A running honey batch is never cut
    unless SoC falls below that 0.38 emergency floor.
  * solar-direct: when measured PV exceeds the whole connected load, Tier 2/3 relays may close
    even below their bands (the surplus would otherwise be dumped or only partly stored).
  * the cold store is pre-cooled on PV surplus (thermostat band 0.5-2.5 C instead of 2-5 C).
"""
from __future__ import annotations
from collections import deque
import numpy as np

from engine import Action
from .base import Controller
from .static import Static


class _Band:
    def __init__(self, cut, restore):
        self.cut, self.restore, self.closed = cut, restore, True

    def update(self, soc):
        if self.closed and soc < self.cut:
            self.closed = False
        elif not self.closed and soc > self.restore:
            self.closed = True
        return self.closed


class _Relay:
    def __init__(self, dwell_steps):
        self.state, self.last, self.dwell = True, -10 ** 9, dwell_steps

    def set(self, i, want, force=False):
        if want != self.state and (force or i - self.last >= self.dwell):
            self.state, self.last = want, i
        return self.state


class ForecastAware(Controller):
    name = "forecast_aware"

    def __init__(self, derate=0.20, reserve_multiplier=1.25, gate=1.15, t3_band=(0.55, 0.68), t2_band=(0.38, 0.50),
                 dwell_min=15, plan_hour=6, lookahead=True, fallback="persistence", foresight=False,
                 precool=True, solar_direct=True, planned_t3_floor=None):
        self.derate, self.mult, self.gate = derate, reserve_multiplier, gate
        self.t3_band, self.t2_band, self.dwell_min = t3_band, t2_band, dwell_min
        self.plan_hour, self.lookahead, self.fallback = plan_hour, lookahead, fallback
        self.foresight, self.precool, self.solar_direct = foresight, precool, solar_direct
        self.planned_floor = t2_band[0] if planned_t3_floor is None else planned_t3_floor

    # ------------------------------------------------------------------ setup
    def setup(self, sim):
        super().setup(sim)
        bp = sim.bp
        self.eta_c, self.eta_d, self.Enom, self.soc_min = bp["eta_c"], bp["eta_d"], bp["E_nom_kWh"], bp["soc_min"]
        self.dt_h = sim.dt_h
        self.plan_j = self.plan_hour * self.sph
        self.band2, self.band3 = _Band(*self.t2_band), _Band(*self.t3_band)
        dw = max(int(round(self.dwell_min / sim.dt)), 1)
        self.rel2, self.rel3 = _Relay(dw), _Relay(dw)
        spd = self.spd
        self.h_t1, self.h_cold = deque(maxlen=7), deque(maxlen=7)
        self.h_t2 = {True: deque(maxlen=4), False: deque(maxlen=4)}   # keyed by is_weekday
        self.cur_t1, self.cur_t2, self.cur_cold, self.cur_pv = (np.zeros(spd) for _ in range(4))
        self.prev_pv = None
        self.fc0 = self.fc1 = np.zeros(spd)
        self.ratio = 1.0
        self.budget2, self.budget3, self.latched2 = np.inf, 0.0, False
        self.pump_slots = set()
        self.mode = "forecast"
        self.static = Static(self.t3_band, self.t2_band, self.dwell_min)
        self.static.setup(sim)
        self.announced = set()
        self.planned_once = False
        self.last = {}

    # ------------------------------------------------------------------ predictions
    def _is_weekday(self, year_day):
        return ((year_day + 4) % 7) < 5

    def _profiles(self, yd):
        dem, spd = self.sim.dem, self.spd
        nd = (yd + 1) % self.sim.year_days
        if self.foresight:
            sl = lambda a, d: a[d * spd:(d + 1) * spd]  # noqa: E731
            p1, p1n = sl(dem.T1_base, yd), sl(dem.T1_base, nd)
            p2, p2n = sl(dem.T2_base, yd), sl(dem.T2_base, nd)
        else:
            boot1 = dem.T1_base[yd * spd:(yd + 1) * spd]
            boot2 = dem.T2_base[yd * spd:(yd + 1) * spd]
            p1 = np.mean(self.h_t1, axis=0) if self.h_t1 else boot1
            p1n = p1
            h2 = self.h_t2[self._is_weekday(yd)] or self.h_t2[not self._is_weekday(yd)]
            p2 = np.mean(h2, axis=0) if h2 else boot2
            h2n = self.h_t2[self._is_weekday(nd)] or self.h_t2[not self._is_weekday(nd)]
            p2n = np.mean(h2n, axis=0) if h2n else boot2
        pc = np.mean(self.h_cold, axis=0) if self.h_cold else np.full(spd, 0.16)
        return p1, p1n, p2, p2n, pc

    def _E(self, p_today, p_tom, j0, j1):
        """kWh of a per-step profile between step-of-day j0 and j1 (j1 may run into tomorrow)."""
        spd = self.spd
        if j1 <= j0:
            return 0.0
        e = p_today[j0:min(j1, spd)].sum()
        if j1 > spd:
            e += p_tom[:j1 - spd].sum()
        return float(e) * self.dt_h

    def _forecasts(self, obs):
        yd = obs["yk"] // self.spd
        if self.foresight:
            pv = self.sim.site.pv_kw
            nd = (yd + 1) % self.sim.year_days
            return pv[yd * self.spd:(yd + 1) * self.spd], pv[nd * self.spd:(nd + 1) * self.spd], "forecast"
        f0, f1 = self.sim.fc.today(yd), self.sim.fc.tomorrow(yd)
        if f0 is not None:
            return f0, f1, "forecast"
        if self.fallback == "static":
            return None, None, "static"
        prev = self.prev_pv if self.prev_pv is not None else np.zeros(self.spd)
        return prev, prev, "persistence"

    # ------------------------------------------------------------------ the waterfall
    def _waterfall(self, obs, j):
        sim, spd, dt_h = self.sim, self.spd, self.dt_h
        yd = obs["yk"] // spd
        p1, p1n, p2, p2n, pc = self._profiles(yd)
        Ecap = self.Enom * obs["cap"]
        E_batt = max(obs["soc"] - self.soc_min, 0) * Ecap * self.eta_d
        keep = (1 - self.derate)
        gen_rem = float(self.fc0[j:].sum()) * dt_h * self.ratio * keep
        j18, j08n = 18 * self.sph, spd + 8 * self.sph
        pump_rem = max(sim.dem.pump_minutes_per_day - obs["pump_done"], 0) / 60 * sim.dem.pump_kw
        E_t1_day = self._E(p1, p1n, j, max(j, j18)) + pump_rem
        E_t1_night = self._E(p1, p1n, max(j, j18), j08n)
        reserve = self.mult * E_t1_night
        extra = 0.0
        if self.lookahead and self.fc1 is not None:
            gen_tom = float(self.fc1.sum()) * dt_h * keep
            need_tom = self._E(p1n, p1n, 8 * self.sph, j18) + sim.dem.pump_kw * sim.dem.pump_minutes_per_day / 60 \
                + self.mult * self._E(p1n, p1n, j18, j08n) / (self.eta_c * self.eta_d)
            extra = max(0.0, need_tom - gen_tom)
        pool = E_batt + gen_rem - E_t1_day - reserve - extra
        E_t2 = self._E(p2, p2n, j, spd + self.plan_j)
        live = [b for b in obs["active"] if b.status in ("pending", "waiting", "paused", "running")]
        E_batches = sum(b.remaining_kwh for b in live)
        E_cold = self._E(pc, pc, j, spd + self.plan_j)
        E_t3 = E_batches + E_cold
        b2 = min(max(pool, 0.0), E_t2)
        b3 = min(max(pool - b2, 0.0), E_t3)
        self.last = dict(E_batt=E_batt, gen_rem=gen_rem, E_t1_day=E_t1_day, reserve=reserve, extra=extra, pool=pool,
                         E_t2=E_t2, E_t3=E_t3, b2=b2, b3=b3, E_cold=E_cold, p1=p1, p2=p2, pc=pc)
        return b2, b3, E_t2, E_t3, E_cold

    # ------------------------------------------------------------------ planning
    def _plan(self, i, obs, full):
        j, sd = obs["j"], obs["sd"]
        if full:
            self.fc0, self.fc1, self.mode = self._forecasts(obs)
            self.ratio = 1.0
            self.latched2 = False
            if self.mode != "static":
                self._choose_pump_slots()
        if self.mode == "static":
            return
        if not full and not self.foresight:
            fc_so_far = float(self.fc0[self.plan_j:j].sum()) * self.dt_h
            meas = float(self.cur_pv[self.plan_j:j].sum()) * self.dt_h
            if j > self.plan_j and fc_so_far > 0.5:
                self.ratio = float(np.clip(meas / fc_so_far, 0.3, 1.0))
        b2, b3, E_t2, E_t3, E_cold = self._waterfall(obs, j)
        if not self.latched2:
            self.budget2 = b2
        self.budget3 = b3
        if b2 < E_t2 - 0.05:
            self._announce(i, sd, "T2", f"T2 short {E_t2 - b2:.1f} kWh")
        if b3 < E_t3 - 0.05:
            self._announce(i, sd, "T3", f"T3 short {E_t3 - b3:.1f} kWh")
        self._schedule_batches(obs, j, b3 - min(E_cold, b3))

    def _choose_pump_slots(self):
        sph = self.sph
        hours = list(range(9, 16))
        e = {h: float(self.fc0[h * sph:(h + 1) * sph].sum()) for h in hours}
        best = sorted(hours, key=lambda h: -e[h])[:2]
        self.pump_slots = {h for h in best}

    def _schedule_batches(self, obs, j, budget):
        spd, dt, sph = self.spd, self.dt, self.sph
        L = self.last
        surplus = self.fc0 * self.ratio * (1 - self.derate) - L["p1"] - L["p2"]
        surplus = surplus.copy()
        for h in self.pump_slots:
            surplus[h * sph:(h + 1) * sph] -= self.sim.dem.pump_kw
        day_start = obs["sd"] * 1440
        for b in obs["active"]:
            if b.status == "running":
                a = j
                n = b.remaining // dt
                surplus[a:a + n] -= b.b.power_kw
                budget -= b.remaining_kwh
        q = max(15 // dt, 1)
        cands = sorted([b for b in obs["active"] if b.status in ("pending", "waiting", "paused")],
                       key=lambda b: b.release)
        for b in cands:
            e = b.remaining_kwh
            n = b.remaining // dt
            lo = max(j, (b.release - day_start) // dt)
            hi = (b.deadline - day_start) // dt - n
            if e > budget + 1e-9 or hi < lo:
                b.planned_start = None
                continue
            starts = list(range(lo, hi + 1, q))
            score = [surplus[s:s + n].sum() for s in starts]
            s = starts[int(np.argmax(score))]
            b.planned_start = day_start + s * dt
            surplus[s:s + n] -= b.b.power_kw
            budget -= e

    def _announce(self, i, sd, tier, text):
        # a day's curtailment notices are issued from the 06:00 plan onward (no credit for
        # "warnings" generated by overnight corrections of the previous plan period)
        if i % self.spd < self.plan_j:
            return
        if (sd, tier) not in self.announced:
            self.announced.add((sd, tier))
            self.sim.announce_event(i, tier, text)

    # ------------------------------------------------------------------ every step
    def step(self, i, obs):
        j, sd = obs["j"], obs["sd"]
        if j == self.plan_j or not self.planned_once:
            self._plan(i, obs, full=True)
            self.planned_once = True
        elif j % self.sph == 0:
            self._plan(i, obs, full=False)
        if self.mode == "static":
            return self.static.step(i, obs)
        soc, pv = obs["soc"], obs["pv"]
        yk = obs["yk"]
        dem = self.sim.dem
        est_load = dem.T1_base[yk] + dem.T2_base[yk]
        running = [b for b in obs["active"] if b.status == "running"]
        est_load += sum(b.b.power_kw for b in running)
        solar_direct = self.solar_direct and pv >= est_load + 0.1
        # ---- Tier 2
        band2 = self.band2.update(soc)
        if self.latched2 and solar_direct and soc >= self.t2_band[1]:
            self.latched2 = False
            self.budget2 = max(self.budget2, 0.0)
        honey_running = any(not b.b.interruptible for b in running)
        if not self.latched2 and self.budget2 <= 0 and not honey_running:
            self.latched2 = True
            self._announce(i, sd, "T2", "T2 budget exhausted")
        r2 = self.rel2.set(i, band2 and not self.latched2)
        # ---- Tier 3: which batches would start now?
        L = self.last
        want_start = []
        due = [b for b in obs["active"] if b.status in ("waiting", "paused") and b.planned_start is not None
               and b.planned_start <= obs["now"]]
        if due:
            Ecap = self.Enom * obs["cap"]
            E_batt = max(soc - self.soc_min, 0) * Ecap * self.eta_d
            j18, j08n = 18 * self.sph, self.spd + 8 * self.sph
            reserve = self.mult * self._E(L["p1"], L["p1"], max(j, j18), j08n) + L.get("extra", 0.0)
            budget = self.budget3
            for b in due:
                n = b.remaining // self.dt
                e = b.remaining_kwh
                e_pv = float(self.fc0[j:j + n].sum()) * self.dt_h * self.ratio * (1 - self.derate)
                e_ld = float((L["p1"][j:j + n] + L["p2"][j:j + n]).sum()) * self.dt_h
                avail = E_batt - reserve + e_pv - e_ld
                if avail >= self.gate * e and budget >= e - 1e-9 and soc >= self.planned_floor:
                    want_start.append(b)
                    budget -= e
                    E_batt -= max(e - e_pv, 0)
                else:
                    b.planned_start = obs["now"] + 15
                    if b.planned_start + b.remaining > b.deadline:
                        b.planned_start = None
                    self._announce(i, sd, "T3", "batch deferred by gate")
        band3 = self.band3.update(soc)
        cold_planned = self.sim.dem.cfg.cold_store and obs["tbox"] > 2.0 and self.budget3 > 0
        planned_active = bool(running or want_start or cold_planned)
        want3 = band3 or (planned_active and soc >= self.planned_floor) or (solar_direct and soc >= self.planned_floor)
        if not r2:
            # tier priority is never inverted: no Tier 3 while Tier 2 is curtailed.  Opening the
            # lower tier is always allowed immediately (dwell applies only to discretionary moves).
            r3 = self.rel3.set(i, False, force=True)
        else:
            r3 = self.rel3.set(i, want3)
        start = want_start if r3 else []
        # ---- pump
        h = j / self.sph
        pump = int(h) in self.pump_slots and 9 <= h < 16
        if h >= 16 and obs["pump_done"] < dem.pump_minutes_per_day and soc > self.soc_min + 0.1:
            pump = True
        # ---- cold store
        band = (0.5, 2.5) if (self.precool and solar_direct and soc > 0.6) else (2.0, 5.0)
        return Action(relay2=r2, relay3=r3, pump=pump, start=start, cold_band=band)

    def after_step(self, i, obs, info):
        j = obs["j"]
        yk = obs["yk"]
        dem = self.sim.dem
        self.budget2 -= info["served2"] * self.dt_h
        self.budget3 -= info["served3"] * self.dt_h
        if self.mode == "static":
            self.static.after_step(i, obs, info)
        self.cur_t1[j] = dem.T1_base[yk]
        L = self.last
        if info["r2"] and info["bus_up"]:
            self.cur_t2[j] = info["served2"]
        else:
            self.cur_t2[j] = L["p2"][j] if "p2" in L else dem.T2_base[yk]
        self.cur_cold[j] = self.sim.log["s3c"][i]
        self.cur_pv[j] = obs["pv"]
        if j == self.spd - 1:
            yd = yk // self.spd
            self.h_t1.append(self.cur_t1.copy())
            self.h_t2[self._is_weekday(yd)].append(self.cur_t2.copy())
            self.h_cold.append(self.cur_cold.copy())
            self.prev_pv = self.cur_pv.copy()
