"""Incumbent: serve every load; when the battery hits its floor everything drops (LVD).
Batches start the moment they are released; the pump runs on a fixed timer."""
from engine import Action
from .base import Controller


class Reactive(Controller):
    name = "reactive"

    def step(self, i, obs):
        start = [b for b in obs["active"] if b.status == "waiting"]
        return Action(relay2=True, relay3=True, pump=self.fixed_pump(obs), start=start, cold_band=(2.0, 5.0))
