"""Controller interface.

A controller sees only what a real site controller could see: the clock, measured PV and
SoC now, its own logs of past demand, batch bookings, and the forecast feed.  It returns
relay commands (Tier 2, Tier 3), the pump command, which batches to start, and the cold-store
thermostat band.  Tier 1 relays do not exist in the interface: they are normally closed.
"""
from __future__ import annotations
from engine import Action


class Controller:
    name = "base"

    def setup(self, sim):
        self.sim = sim
        self.dt = sim.dt
        self.spd = sim.spd
        self.sph = sim.sph

    def step(self, i, obs) -> Action:  # pragma: no cover
        raise NotImplementedError

    def after_step(self, i, obs, info):
        pass

    # shared helpers ------------------------------------------------------------
    def fixed_pump(self, obs):
        """Incumbent pump timer: 07:00-08:00 and 16:00-17:00."""
        h = obs["j"] / self.sph
        return (7 <= h < 8) or (16 <= h < 17)


class Hysteresis:
    """SoC hysteresis relay with minimum dwell time."""

    def __init__(self, cut, restore, dwell_min, dt_min):
        self.cut, self.restore = cut, restore
        self.dwell_steps = max(int(round(dwell_min / dt_min)), 1)
        self.closed = True
        self.last_change = -10 ** 9

    def update(self, i, soc, force_open=False, force_closed=False):
        want = self.closed
        if self.closed and soc < self.cut:
            want = False
        elif not self.closed and soc > self.restore:
            want = True
        if force_open:
            want = False
        if force_closed:
            want = True
        if want != self.closed and i - self.last_change >= self.dwell_steps:
            self.closed = want
            self.last_change = i
        return self.closed

    def can_change(self, i):
        return i - self.last_change >= self.dwell_steps
