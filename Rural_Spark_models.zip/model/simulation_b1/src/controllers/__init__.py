from .reactive import Reactive
from .static import Static
from .forecast_aware import ForecastAware
from .oracle import Oracle

REGISTRY = {"reactive": Reactive, "static": Static, "forecast_aware": ForecastAware, "oracle": Oracle}
