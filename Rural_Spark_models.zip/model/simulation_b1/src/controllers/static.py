"""Incumbent+ (best current practice at this scale): fixed SoC thresholds with hysteresis
and a 15-minute minimum dwell, no forecast, no scheduling.  Batches start at release when
the Tier 3 relay is closed; a Tier 3 cut mid-batch spoils a honey batch."""
from engine import Action
from .base import Controller, Hysteresis


class Static(Controller):
    name = "static"

    def __init__(self, t3=(0.55, 0.68), t2=(0.38, 0.50), dwell_min=15):
        self.t3b, self.t2b, self.dwell = t3, t2, dwell_min

    def setup(self, sim):
        super().setup(sim)
        self.h3 = Hysteresis(*self.t3b, self.dwell, sim.dt)
        self.h2 = Hysteresis(*self.t2b, self.dwell, sim.dt)

    def step(self, i, obs):
        soc = obs["soc"]
        r3 = self.h3.update(i, soc)
        r2 = self.h2.update(i, soc)
        start = [b for b in obs["active"] if b.status in ("waiting", "paused")] if r3 else []
        return Action(relay2=r2, relay3=r3, pump=self.fixed_pump(obs), start=start, cold_band=(2.0, 5.0))
