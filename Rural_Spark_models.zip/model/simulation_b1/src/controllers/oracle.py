"""Oracle: the same waterfall, perfect foresight (true PV, true Tier 1/2 demand), no derate.
It is the theoretical ceiling that makes the comparison bounded: 'we capture X% of the gain
available to a perfect-foresight controller'."""
from .forecast_aware import ForecastAware


class Oracle(ForecastAware):
    name = "oracle"

    def __init__(self, **kw):
        kw = {**kw, "derate": 0.0, "foresight": True}
        super().__init__(**kw)
