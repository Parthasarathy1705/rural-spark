"""Figures and tables from results/  (python src/figures.py)."""
from __future__ import annotations
import json
import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
RES = ROOT / "results"
FIG = RES / "figures"
FIG.mkdir(parents=True, exist_ok=True)

INK, INK2, MUTED, GRID, SURF = "#0b0b0b", "#52514e", "#8a8984", "#e6e5e1", "#fcfcfb"
COL = {"forecast_aware": "#2a78d6", "static": "#eb6834", "reactive": "#1baf7a", "oracle": "#8a8984"}
LBL = {"forecast_aware": "Forecast-aware (ours)", "static": "Static thresholds", "reactive": "Reactive (incumbent)",
       "oracle": "Oracle (perfect foresight)"}
CRIT = "#e34948"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": GRID, "axes.labelcolor": INK2,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8, "axes.axisbelow": True,
                     "figure.dpi": 150, "savefig.facecolor": "white", "legend.frameon": False,
                     "axes.titlesize": 11, "axes.titleweight": "bold", "axes.titlecolor": INK})


def headline(R):
    S = pickle.load(open(RES / "S3_logs.pkl", "rb"))
    fa = S["forecast_aware"]
    a, spd, dt = fa["report_from"], fa["spd"], fa["dt"]
    n = len(fa["log"]["pv"]) - a
    x = np.arange(n) * dt / 1440
    w = R["windows"]
    day0 = fa["seq_days"][fa["warm"]]
    worst = w["S3_worst3"] - day0
    fc = np.concatenate(fa["fc0"])[a:]
    fig, ax = plt.subplots(4, 1, figsize=(11, 10.5), sharex=True, gridspec_kw={"height_ratios": [1.1, 1.4, 1.2, 1.0]})
    for k in ax:
        k.axvspan(worst, worst + 3, color="#f1f0ec", zorder=0, lw=0)
    # (a) generation
    ax[0].plot(x, fa["log"]["pv"][a:], color=INK, lw=1.4, label="Actual PV (AC)")
    ax[0].plot(x, fc, color=COL["forecast_aware"], lw=1.4, ls=(0, (4, 2)), label="Day-ahead forecast used by our controller")
    ax[0].set_ylabel("kW")
    ax[0].set_title("(a) Generation: forecast vs actual", loc="left")
    ax[0].legend(loc="upper right", ncol=2, fontsize=9)
    ax[0].text(worst + 1.5, -0.9, "3 worst consecutive days in the TMY", ha="center", fontsize=9, color=INK2)
    ax[0].set_ylim(-1.3, None)
    # (b) SoC
    for c in ("reactive", "static", "forecast_aware"):
        ax[1].plot(x, 100 * S[c]["log"]["soc"][a:], color=COL[c], lw=2, label=LBL[c])
    ax[1].plot(x, 100 * S["oracle"]["log"]["soc"][a:], color=COL["oracle"], lw=1.2, ls=(0, (2, 2)), label=LBL["oracle"])
    ax[1].axhline(20, color=INK2, lw=0.8, ls=":")
    ax[1].text(x[-1], 21.5, "SoC floor 20%", ha="right", fontsize=8.5, color=INK2)
    ax[1].set_ylabel("Battery SoC, %"); ax[1].set_ylim(0, 105)
    ax[1].set_title("(b) State of charge", loc="left")
    ax[1].legend(loc="upper center", ncol=4, fontsize=8.5, bbox_to_anchor=(0.5, 1.0))
    # (c) tier status bands
    rows, labels = [], []
    for c in ("reactive", "static", "forecast_aware"):
        L = S[c]["log"]
        up = L["lvd"][a:] < 0.5
        t1 = np.where(up, 1, 3)
        t2 = np.where(up & (L["r2"][a:] > 0.5), 1, np.where(up, 2, 3))
        t3 = np.where(up & (L["r3"][a:] > 0.5), 1, np.where(up, 2, 3))
        for t, nm in ((t3, "T3"), (t2, "T2"), (t1, "T1")):
            rows.append(t); labels.append(f"{LBL[c].split(' (')[0]}  {nm}")
    img = np.array(rows)
    cmap = ListedColormap(["#cfe3f6", "#d9d8d3", CRIT])
    ax[2].imshow(img - 1, aspect="auto", cmap=cmap, vmin=0, vmax=2, interpolation="nearest",
                 extent=[0, x[-1] + dt / 1440, len(rows), 0])
    ax[2].set_yticks(np.arange(len(rows)) + 0.5); ax[2].set_yticklabels(labels, fontsize=8.5)
    for yy in (3, 6):
        ax[2].axhline(yy, color="white", lw=3)
    ax[2].grid(False)
    ax[2].set_title("(c) Tier status: blue = energised, grey = shed by controller, red = blackout (inverter LVD)", loc="left")
    # (d) cumulative unserved Tier 1
    for c in ("reactive", "static", "forecast_aware", "oracle"):
        L = S[c]["log"]
        uns = np.cumsum(L["t1"][a:] * (L["lvd"][a:] > 0.5)) * dt / 60
        ax[3].plot(x, uns, color=COL[c], lw=2 if c != "oracle" else 1.2, ls="-" if c != "oracle" else (0, (2, 2)), label=LBL[c])
    ax[3].set_ylabel("kWh"); ax[3].set_title("(d) Cumulative unserved Tier 1 energy (lights, phones, health sub-centre)", loc="left")
    start = pd.Timestamp("2021-01-01") + pd.Timedelta(days=int(day0))
    ax[3].set_xlabel(f"Day of the 7-day window (starts {start:%d %b} of the TMY year; 5-min step)")
    ax[3].legend(loc="upper left", fontsize=8.5)
    r = R["scenarios"]["S3"]["results"]
    L = S["reactive"]["log"]
    base_uns = float(np.sum(L["t1"][a:] * (L["lvd"][a:] > 0.5)) * dt / 60)
    pump = r["reactive"]["t1_unserved_kwh"] - base_uns
    ax[3].text(x[-1], base_uns * 0.93, f"reactive: {base_uns:.1f} kWh of lights/phones/health centre lost in "
               f"{r['reactive']['t1_interruptions']} blackouts\n(+{pump:.1f} kWh of drinking-water pumping not delivered)",
               va="top", ha="right", fontsize=9, color=INK)
    fig.suptitle("S3 - three consecutive overcast days: who keeps the health sub-centre and lights on?", x=0.01, ha="left",
                 fontsize=13, fontweight="bold", color=INK)
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    fig.savefig(FIG / "headline_S3.png"); plt.close(fig)


def table(R):
    rows = []
    sc = R["scenarios"]
    order = ["S1", "S2", "S3", "S4", "S9", "S10", "S11"]
    for sid in order:
        for c in ("reactive", "static", "forecast_aware", "oracle"):
            m = sc[sid]["results"][c]
            rows.append(dict(scenario=sid, title=sc[sid]["title"], step_min=sc[sid]["dt_min"], controller=c,
                             tier1_availability_pct=round(m["t1_availability_pct"], 2),
                             tier3_useful_kwh=round(m["t3_useful_kwh"], 1),
                             tier1_unserved_kwh=round(m["t1_unserved_kwh"], 2), tier1_interruptions=m["t1_interruptions"],
                             longest_t1_interruption_min=m["t1_longest_interruption_min"],
                             tier2_served_pct=round(m["t2_served_pct"], 2), batches_done=m["batches_completed"],
                             batches_requested=m["batches_requested"], batches_spoiled=m["batches_spoiled"],
                             cold_chain_excursion_h=round(m["cold_excursion_h"], 1),
                             warned_events_pct=round(m["warned_events_pct"], 1),
                             warning_mean_min=round(m["warning_mean_min"]), warning_p10_min=round(m["warning_p10_min"]),
                             relay_transitions_per_day=round(m["relay_transitions_per_day"], 2),
                             relay_transitions_max_day=m["relay_transitions_max_day"],
                             efc_per_year=round(m["efc_per_year"]), mean_dod=round(m["mean_dod"], 2),
                             dumped_kwh=round(m["dumped_kwh"]), replacement_year=round(m["replacement_year"], 1),
                             gini_t3_monthly=round(m["gini_t3_monthly_mean"], 3)))
    for g, d in R["S8"].items():
        for c, m in d.items():
            rows.append(dict(scenario=f"S8 +{int(float(g) * 100)}%", title=f"Load growth +{int(float(g) * 100)}%", step_min=15,
                             controller=c, tier1_availability_pct=round(m["t1_availability_pct"], 2),
                             tier3_useful_kwh=round(m["t3_useful_kwh"], 1), tier1_unserved_kwh=round(m["t1_unserved_kwh"], 2),
                             tier1_interruptions=m["t1_interruptions"], longest_t1_interruption_min=m["t1_longest_interruption_min"],
                             tier2_served_pct=round(m["t2_served_pct"], 2), batches_done=m["batches_completed"],
                             batches_requested=m["batches_requested"], batches_spoiled=m["batches_spoiled"],
                             cold_chain_excursion_h=round(m["cold_excursion_h"], 1), warned_events_pct=round(m["warned_events_pct"], 1),
                             warning_mean_min=round(m["warning_mean_min"]), warning_p10_min=round(m["warning_p10_min"]),
                             relay_transitions_per_day=round(m["relay_transitions_per_day"], 2),
                             relay_transitions_max_day=m["relay_transitions_max_day"], efc_per_year=round(m["efc_per_year"]),
                             mean_dod=round(m["mean_dod"], 2), dumped_kwh=round(m["dumped_kwh"]),
                             replacement_year=round(m["replacement_year"], 1), gini_t3_monthly=round(m["gini_t3_monthly_mean"], 3)))
    df = pd.DataFrame(rows)
    df.to_csv(RES / "results_table.csv", index=False)
    # compact markdown: Tier 1 and Tier 3 side by side, always together
    piv = []
    for sid in df.scenario.unique():
        d = df[df.scenario == sid].set_index("controller")
        line = {"Scenario": f"{sid} {d.title.iloc[0]}"}
        for c in ("reactive", "static", "forecast_aware", "oracle"):
            line[f"{c} T1 %"] = d.loc[c, "tier1_availability_pct"]
            line[f"{c} T3 kWh"] = d.loc[c, "tier3_useful_kwh"]
        piv.append(line)
    md = pd.DataFrame(piv)
    (RES / "results_table.md").write_text(md.to_markdown(index=False))
    return df


def sizing(R):
    d = pd.read_csv(RES / "sizing_sweep.csv")
    g = d[d.label.isna()]
    fig, ax = plt.subplots(2, 2, figsize=(11, 8))
    for j, c in enumerate(("static", "forecast_aware")):
        x = g[g.controller == c]
        for i, (col, ttl, fmt, cm) in enumerate((("t1_availability_pct", "Tier 1 availability, %", "{:.2f}", "Blues"),
                                                  ("t3_useful_kwh", "Tier 3 useful energy, kWh/yr", "{:,.0f}", "Blues"))):
            pv = x.pivot(index="array_kwp", columns="battery_kwh", values=col)
            a = ax[i, j]
            vmin = 97 if i == 0 else g[col].min()
            vmax = 100 if i == 0 else g[col].max()
            a.imshow(pv.values, cmap=cm, vmin=vmin, vmax=vmax, origin="lower", aspect="auto")
            a.set_xticks(range(len(pv.columns))); a.set_xticklabels([f"{v:g}" for v in pv.columns])
            a.set_yticks(range(len(pv.index))); a.set_yticklabels([f"{v:g}" for v in pv.index])
            a.grid(False)
            for yi in range(pv.shape[0]):
                for xi in range(pv.shape[1]):
                    v = pv.values[yi, xi]
                    norm = (v - vmin) / (vmax - vmin + 1e-9)
                    a.text(xi, yi, fmt.format(v), ha="center", va="center", fontsize=8.5, color="white" if norm > 0.6 else INK)
            xi, yi = list(pv.columns).index(20), list(pv.index).index(10)
            a.add_patch(plt.Rectangle((xi - 0.5, yi - 0.5), 1, 1, fill=False, ec=INK, lw=2))
            a.set_title(f"{LBL[c]}\n{ttl}", loc="left", fontsize=10)
            a.set_xlabel("Battery, kWh"); a.set_ylabel("Array, kWp")
    fig.suptitle("Sizing sweep (full TMY year, 15-min step). Boxed: the 10 kWp / 20 kWh design", x=0.01, ha="left",
                 fontsize=12, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(FIG / "sizing_heatmaps.png"); plt.close(fig)
    # knee curves (FA): marginal Tier 3 per added kWh / kWp
    x = g[g.controller == "forecast_aware"]
    fig, a = plt.subplots(1, 2, figsize=(11, 3.6))
    for kwp, ls in zip((8, 10, 12, 14), ("-", "-", "-", "-")):
        s = x[x.array_kwp == kwp].sort_values("battery_kwh")
        a[0].plot(s.battery_kwh, s.t3_useful_kwh, marker="o", lw=2, color="#2a78d6", alpha=0.35 + 0.65 * (kwp - 8) / 6, label=f"{kwp} kWp")
        a[0].text(s.battery_kwh.iloc[-1] + 0.4, s.t3_useful_kwh.iloc[-1], f"{kwp} kWp", va="center", fontsize=8.5, color=INK2)
    a[0].axvline(20, color=INK2, ls=":", lw=1)
    a[0].set_xlabel("Battery, kWh"); a[0].set_ylabel("Tier 3 useful kWh/yr"); a[0].set_title("Tier 3 vs battery (ours)", loc="left")
    for kwh in (10, 15, 20, 25, 30):
        s = x[x.battery_kwh == kwh].sort_values("array_kwp")
        a[1].plot(s.array_kwp, s.dumped_kwh / s.pv_kwh * 100, marker="o", lw=2, color="#eb6834", alpha=0.35 + 0.65 * (kwh - 10) / 20)
        a[1].text(s.array_kwp.iloc[-1] + 0.1, (s.dumped_kwh / s.pv_kwh * 100).iloc[-1], f"{kwh} kWh", va="center", fontsize=8.5, color=INK2)
    a[1].axvline(10, color=INK2, ls=":", lw=1)
    a[1].set_xlabel("Array, kWp"); a[1].set_ylabel("PV energy dumped, %"); a[1].set_title("Unused PV vs array size (ours)", loc="left")
    fig.tight_layout(); fig.savefig(FIG / "sizing_knee.png"); plt.close(fig)


def sensitivity(R):
    fig, a = plt.subplots(1, 3, figsize=(13, 3.8))
    for key, ax, xl in (("S5_stressed", a[0], "Forecast error sigma (all sky classes)"),
                        ("S6_stressed", a[1], "Forecast bias (+ = optimistic)")):
        xs = [float(k) for k in R[key]]
        for c in ("static", "forecast_aware", "oracle"):
            ys = [R[key][k][c]["t3_useful_kwh"] for k in R[key]]
            ax.plot(xs, ys, marker="o", lw=2, color=COL[c], ls="-" if c != "oracle" else (0, (2, 2)), label=LBL[c])
        for k in R[key]:
            t1 = R[key][k]["forecast_aware"]["t1_availability_pct"]
            ax.annotate(f"T1 {t1:.1f}%", (float(k), R[key][k]["forecast_aware"]["t3_useful_kwh"]), textcoords="offset points",
                        xytext=(0, -14), ha="center", fontsize=8, color=INK2)
        st1 = R[key][list(R[key])[0]]["static"]["t1_availability_pct"]
        ax.set_xlabel(xl); ax.set_ylabel("Tier 3 useful kWh/yr")
        ax.set_title(f"{key.split('_')[0]} at +50% load (static T1 {st1:.2f}%)", loc="left", fontsize=10)
    a[0].legend(fontsize=8, loc="lower left")
    d = pd.DataFrame(R["derate_curve_stressed_bias20"])
    a[2].plot(d.derate, d.t3_useful_kwh, marker="o", lw=2, color=COL["forecast_aware"])
    for _, r in d.iterrows():
        a[2].annotate(f"T1 {r.t1_availability_pct:.2f}%", (r.derate, r.t3_useful_kwh), textcoords="offset points",
                      xytext=(0, 8), ha="center", fontsize=8, color=INK2)
    a[2].set_xlabel("Planning derate on forecast"); a[2].set_ylabel("Tier 3 useful kWh/yr")
    a[2].set_title("Derate at +20% optimistic bias, +50% load", loc="left", fontsize=10); a[2].margins(y=0.15)
    fig.tight_layout(); fig.savefig(FIG / "forecast_sensitivity.png"); plt.close(fig)


def battery_bench():
    """Python twin of matlab/bp_testbench.m (same procedure, same numbers)."""
    from battery import bp_default_params, bp_init, bp_step, bp_life_projection
    dt = 1 / 60
    pe, pn = bp_default_params("ecm", 20.0), bp_default_params("energy", 20.0)
    out = {"crates": [0.1, 0.25, 0.5], "rte_ecm": [], "rte_energy": []}
    fig, ax = plt.subplots(1, 3, figsize=(13, 3.6))
    for cr, alpha in zip(out["crates"], (0.45, 0.7, 1.0)):
        P = cr * pe["E_nom_kWh"]
        s = bp_init(pe, 1.0, 25); eo = 0; V = []; soc = []
        while True:
            s, o = bp_step(pe, s, P, dt, 25); eo += o["P_kW"] * dt; V.append(o["V_pack"]); soc.append(s["soc"])
            if o["P_kW"] < 1e-6: break
        ei = 0
        while True:
            s, o = bp_step(pe, s, -P, dt, 25); ei -= o["P_kW"] * dt
            if -o["P_kW"] < 1e-6: break
        out["rte_ecm"].append(eo / ei)
        ax[0].plot(1 - np.array(soc[:-1]), V[:-1], lw=2, color="#2a78d6", alpha=alpha, label=f"{cr:g}C")
        s = bp_init(pn, 1.0, 25); a_ = b_ = 0
        while True:
            s, o = bp_step(pn, s, P, dt, 25); a_ += o["P_kW"] * dt
            if o["P_kW"] < 1e-6: break
        while True:
            s, o = bp_step(pn, s, -P, dt, 25); b_ -= o["P_kW"] * dt
            if -o["P_kW"] < 1e-6: break
        out["rte_energy"].append(a_ / b_)
    ax[0].set_xlabel("Depth of discharge"); ax[0].set_ylabel("Pack voltage, V (step mean)")
    ax[0].set_title("ECM pack 16S4P: constant-power discharge", loc="left", fontsize=10); ax[0].legend(fontsize=8)
    p = bp_default_params("energy", 20.0)
    s = bp_init(p, 0.20, 40); T, Pc = [], []
    for k in range(6 * 60):
        s, o = bp_step(p, s, -p["c_rate"] * p["E_nom_kWh"], dt, 40); T.append(s["T_C"]); Pc.append(-o["P_kW"])
    t = np.arange(1, 361) / 60
    ax[1].plot(t, T, color="#eb6834", lw=2, label="Cell temperature, °C")
    ax[1].plot(t, Pc, color="#2a78d6", lw=2, label="Accepted charge, kW")
    ax[1].axhline(45, color=INK2, ls=":", lw=1); ax[1].text(6, 45.6, "45 °C derate", ha="right", fontsize=8, color=INK2)
    ax[1].set_xlabel("Hours of 0.5C charge at 40 °C outdoor"); ax[1].legend(fontsize=8, loc="center right")
    ax[1].set_title("Thermal charge derate", loc="left", fontsize=10)
    on = next((tt for tt, TT in zip(t, T) if TT > 45), None)
    out["derate_onset_h"] = on
    efc = np.arange(0, 401, 10)
    yr = [bp_life_projection(p, e)["replacement_year"] for e in efc]
    ax[2].plot(efc, yr, color=INK, lw=2)
    ax[2].axhspan(11, 12, color="#f1f0ec", lw=0); ax[2].text(390, 11.5, "spec target 11-12 yr", ha="right", va="center", fontsize=8, color=INK2)
    R = json.load(open(RES / "results.json"))
    for c in ("reactive", "static", "forecast_aware"):
        e = R["scenarios"]["S4"]["results"][c]["efc_per_year"]
        ax[2].plot([e], [bp_life_projection(p, e)["replacement_year"]], "o", ms=8, color=COL[c], label=LBL[c])
    ax[2].set_xlabel("Equivalent full cycles per year"); ax[2].set_ylabel("Year capacity hits 80%")
    ax[2].set_title("Battery replacement year (spec fade model)", loc="left", fontsize=10); ax[2].legend(fontsize=7.5, loc="upper right")
    fig.tight_layout(); fig.savefig(FIG / "battery_pack_characterisation.png"); plt.close(fig)
    json.dump(out, open(RES / "battery_bench.json", "w"), indent=1)
    return out


def pv_fig(R):
    import pv as pvm
    from sitedata import build_site
    meta = json.load(open(ROOT / "data" / "pvgis_tmy_meta.json"))
    ref = meta["pvcalc_reference"]["16"]["E_m"]
    fig, a = plt.subplots(figsize=(10, 3.4))
    w = 0.26
    for k, (t, al) in enumerate(((10.0, 0.45), (16.0, 1.0), (22.0, 0.7))):
        s = build_site(pvm.PVConfig(tilt=t, kwp=1.0), 15)
        e = pd.Series(s.pv_kw.reshape(-1, 96).sum(1) * 0.25, index=pd.date_range("2021-01-01", periods=365)).groupby(lambda d: d.month).sum()
        a.bar(np.arange(12) + (k - 1) * w, e.values, width=w - 0.03, color="#2a78d6", alpha=al, label=f"Model, {t:g}° tilt (TMY)")
    a.plot(np.arange(12), ref, "o", color=INK, ms=6, label="PVGIS PVcalc 16°, 2005-2020 mean")
    a.set_xticks(range(12)); a.set_xticklabels(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"])
    a.set_ylabel("kWh per kWp per month"); a.grid(axis="x", visible=False)
    v = R["pv_validation"]["tilts"]["16"]
    a.set_title(f"PV model vs PVGIS: annual {v['model_kwh_per_kwp']:.0f} vs {v['pvgis_pvcalc_kwh_per_kwp']:.0f} kWh/kWp "
                f"({v['diff_pct']:+.1f}%, gate ±5%)", loc="left")
    a.legend(fontsize=8, ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.12))
    fig.tight_layout(); fig.savefig(FIG / "pv_validation_tilt.png"); plt.close(fig)


if __name__ == "__main__":
    R = json.load(open(RES / "results.json"))
    headline(R); table(R); sizing(R); sensitivity(R); battery_bench(); pv_fig(R)
    print("figures written")
