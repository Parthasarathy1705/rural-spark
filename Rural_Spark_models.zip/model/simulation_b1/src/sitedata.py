"""Site time series on the simulation step grid (IST, one non-leap year)."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pv as pvm
from forecast import daily_kt


@dataclass
class Site:
    dt_min: int
    pv_kw: np.ndarray          # AC power available, kW (step mean)
    temp_c: np.ndarray         # outdoor air temperature
    ghi: np.ndarray
    kt_daily: np.ndarray
    pac_max: float
    pv_cfg: pvm.PVConfig
    time_offset_h: float


_CACHE = {}


def build_site(pv_cfg: pvm.PVConfig, dt_min: int) -> Site:
    key = (tuple(sorted(pv_cfg.__dict__.items())), dt_min)
    if key in _CACHE:
        return _CACHE[key]
    df = pvm.load_tmy()
    off = pvm.fit_time_offset(df)["best_offset_h"]
    hourly = pvm.simulate_pv(df, pv_cfg, off)
    pv = pvm.to_local_steps(hourly, dt_min, "p_ac_kw")
    temp = pvm.to_local_steps(hourly, dt_min, "temp_air")
    ghi = pvm.to_local_steps(hourly, dt_min, "ghi")
    n = len(pv)
    t_ist_mid = (np.arange(n) + 0.5) * dt_min / 60.0
    zen, _, doy = pvm.solar_position(t_ist_mid - pvm.IST_OFFSET_H)
    kt = daily_kt(ghi, np.cos(np.radians(zen)), doy, dt_min)
    pac_max = pv_cfg.kwp / pv_cfg.dc_ac_ratio
    s = Site(dt_min, pv, temp, ghi, kt, pac_max, pv_cfg, off)
    _CACHE[key] = s
    return s
