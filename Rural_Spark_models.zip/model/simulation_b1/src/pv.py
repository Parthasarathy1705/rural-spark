"""PV model: irradiance -> DC -> AC, PVWatts formulation.

If pvlib is installed it is used for solar position, transposition, IAM and cell
temperature (`use_pvlib=True`).  pvlib could not be installed in the build
environment, so the default path is a numpy implementation of the *same published
equations* pvlib uses:

  solar position   Michalsky (1988) / Astronomical Almanac low-precision algorithm
                   (about 0.01 deg, 1950-2050)
  transposition    Hay-Davies (pvlib.irradiance.haydavies) + isotropic ground reflection
  IAM              physical Fresnel/absorption model (pvlib.iam.physical, n=1.526,
                   K=4, L=0.002); diffuse IAM at Brandemuehl-Beckman equivalent angles
  cell temp        Faiman (pvlib.temperature.faiman, u0=25, u1=6.84)
  DC               spec section 3: P = Pdc0 * G/1000 * (1 + gamma*(Tc-25)) * (1-Lsoil) * (1-Lsys)
  AC               PVWatts inverter curve (pvlib.inverter.pvwatts, eta_nom 0.96)

Units: W/m2, degC, m/s, kW.  Time: the PVGIS TMY rows are UTC hours.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, field
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
LAT, LON = 16.37, 78.83
IST_OFFSET_H = 5.5


@dataclass
class PVConfig:
    kwp: float = 10.0
    tilt: float = 16.0
    azimuth: float = 180.0          # degrees from north, 180 = south
    gamma: float = -0.0035          # /degC, mono-PERC
    soil_dry: float = 0.06
    soil_monsoon: float = 0.02
    monsoon_months: tuple = (6, 7, 8, 9)
    l_sys: float = 0.06             # wiring 2 + mismatch 2 + MPPT 2
    albedo: float = 0.20
    inv_eta_nom: float = 0.96
    dc_ac_ratio: float = 1.0        # inverter AC rating = kWp / ratio
    derate_strings: float = 0.0     # S10: fraction of generation lost (one string down = 0.25)
    use_pvlib: bool = False


def load_tmy(path: Path | None = None) -> pd.DataFrame:
    df = pd.read_csv(path or DATA / "pvgis_tmy_16.37_78.83.csv")
    # TMY hour index -> nominal UTC timestamp in a fixed non-leap year (2021)
    df["utc"] = pd.Timestamp("2021-01-01 00:00") + pd.to_timedelta(df.time_utc_index, unit="h")
    return df


# ---------------------------------------------------------------- solar geometry
def solar_position(utc_hours_since_2021: np.ndarray, lat=LAT, lon=LON):
    """Apparent solar zenith & azimuth (deg). Input: hours since 2021-01-01 00:00 UTC."""
    jd = 2459215.5 + utc_hours_since_2021 / 24.0          # JD of 2021-01-01 00:00 UTC = 2459215.5
    n = jd - 2451545.0
    L = np.mod(280.460 + 0.9856474 * n, 360.0)
    g = np.radians(np.mod(357.528 + 0.9856003 * n, 360.0))
    lam = np.radians(L + 1.915 * np.sin(g) + 0.020 * np.sin(2 * g))
    eps = np.radians(23.439 - 0.0000004 * n)
    ra = np.arctan2(np.cos(eps) * np.sin(lam), np.cos(lam))
    dec = np.arcsin(np.sin(eps) * np.sin(lam))
    hour_utc = np.mod(utc_hours_since_2021, 24.0)
    gmst = np.mod(6.697375 + 0.0657098242 * n + hour_utc, 24.0)
    lmst = np.mod(gmst + lon / 15.0, 24.0)
    ha = np.radians(lmst * 15.0) - ra
    ha = np.arctan2(np.sin(ha), np.cos(ha))
    phi = np.radians(lat)
    sin_el = np.sin(dec) * np.sin(phi) + np.cos(dec) * np.cos(phi) * np.cos(ha)
    el = np.degrees(np.arcsin(np.clip(sin_el, -1, 1)))
    # Bennett-type refraction (only above -0.575 deg)
    with np.errstate(divide="ignore", invalid="ignore"):
        r = np.where(el > -0.575, 0.0167 / np.tan(np.radians(el + 7.31 / (el + 4.4))), 0.0)
    el_app = el + r
    az = np.degrees(np.arctan2(-np.sin(ha), np.tan(dec) * np.cos(phi) - np.sin(phi) * np.cos(ha)))
    az = np.mod(az, 360.0)
    doy = np.floor(utc_hours_since_2021 / 24.0) + 1
    return 90.0 - el_app, az, doy


def dni_extra(doy):
    return 1361.0 * (1 + 0.033 * np.cos(2 * np.pi * doy / 365.0))


def _iam_physical(theta_deg, n=1.526, K=4.0, L=0.002):
    th = np.radians(np.clip(theta_deg, 1e-6, 89.999))
    thr = np.arcsin(np.sin(th) / n)
    rs = (np.sin(thr - th) / np.sin(thr + th)) ** 2
    rp = (np.tan(thr - th) / np.tan(thr + th)) ** 2
    tau = np.exp(-K * L / np.cos(thr)) * (1 - 0.5 * (rs + rp))
    tau0 = np.exp(-K * L) * (1 - ((n - 1) / (n + 1)) ** 2)
    out = tau / tau0
    return np.where(np.asarray(theta_deg) >= 90, 0.0, out)


def poa_components(df: pd.DataFrame, cfg: PVConfig, time_offset_h: float):
    t = df.time_utc_index.to_numpy(float) + time_offset_h
    zen, az, doy = solar_position(t)
    beta, gam = np.radians(cfg.tilt), np.radians(cfg.azimuth)
    zr, ar = np.radians(zen), np.radians(az)
    cos_aoi = np.cos(zr) * np.cos(beta) + np.sin(zr) * np.sin(beta) * np.cos(ar - gam)
    aoi = np.degrees(np.arccos(np.clip(cos_aoi, -1, 1)))
    ghi, dni, dhi = (df[c].to_numpy(float) for c in ("ghi_wm2", "dni_wm2", "dhi_wm2"))
    sun_up = zen < 90
    poa_b = np.where(sun_up, dni * np.maximum(cos_aoi, 0), 0.0)
    AI = np.where(sun_up, dni / dni_extra(doy), 0.0)
    Rb = np.maximum(cos_aoi, 0) / np.maximum(np.cos(zr), 0.01745)
    poa_sky = dhi * (AI * Rb + (1 - AI) * 0.5 * (1 + np.cos(beta)))
    poa_gnd = ghi * cfg.albedo * 0.5 * (1 - np.cos(beta))
    poa = poa_b + poa_sky + poa_gnd
    th_sky = 59.7 - 0.1388 * cfg.tilt + 0.001497 * cfg.tilt ** 2
    th_gnd = 90.0 - 0.5788 * cfg.tilt + 0.002693 * cfg.tilt ** 2
    poa_eff = (poa_b * _iam_physical(aoi) + poa_sky * _iam_physical(th_sky) + poa_gnd * _iam_physical(th_gnd))
    return dict(zen=zen, az=az, aoi=aoi, poa=poa, poa_eff=poa_eff, poa_b=poa_b, poa_sky=poa_sky, poa_gnd=poa_gnd)


def fit_time_offset(df: pd.DataFrame) -> dict:
    """PVGIS gives GHI, DNI, DHI separately.  The timestamp convention is recovered from the data
    by finding the offset that best satisfies closure GHI = DNI*cos(Z) + DHI."""
    out = {}
    m = df.dni_wm2.to_numpy() > 50
    for off in np.arange(-0.5, 1.01, 0.25):
        zen, _, _ = solar_position(df.time_utc_index.to_numpy(float) + off)
        pred = df.dni_wm2.to_numpy() * np.maximum(np.cos(np.radians(zen)), 0) + df.dhi_wm2.to_numpy()
        out[float(off)] = float(np.sqrt(np.mean((pred[m] - df.ghi_wm2.to_numpy()[m]) ** 2)))
    best = min(out, key=out.get)
    return {"rmse_by_offset_wm2": out, "best_offset_h": best}


def faiman(poa_global, temp_air, wind, u0=25.0, u1=6.84):
    return temp_air + poa_global / (u0 + u1 * wind)


def pvwatts_ac(p_dc_kw, pdc0_inv_kw, eta_nom=0.96, eta_ref=0.9637):
    pac0 = eta_nom * pdc0_inv_kw
    z = np.where(p_dc_kw > 0, p_dc_kw / pdc0_inv_kw, 1.0)
    eta = eta_nom / eta_ref * (-0.0162 * z - 0.0059 / z + 0.9858)
    pac = np.where(p_dc_kw > 0, eta * p_dc_kw, 0.0)
    return np.clip(pac, 0, pac0)


def simulate_pv(df: pd.DataFrame, cfg: PVConfig, time_offset_h: float | None = None) -> pd.DataFrame:
    if time_offset_h is None:
        time_offset_h = fit_time_offset(df)["best_offset_h"]
    if cfg.use_pvlib:
        return _simulate_pvlib(df, cfg, time_offset_h)
    c = poa_components(df, cfg, time_offset_h)
    tcell = faiman(c["poa"], df.temp_air_c.to_numpy(float), df.wind_speed_ms.to_numpy(float))
    month = (df.utc + pd.to_timedelta(time_offset_h + IST_OFFSET_H, unit="h")).dt.month.to_numpy()
    l_soil = np.where(np.isin(month, cfg.monsoon_months), cfg.soil_monsoon, cfg.soil_dry)
    p_dc = cfg.kwp * (c["poa_eff"] / 1000.0) * (1 + cfg.gamma * (tcell - 25)) * (1 - l_soil) * (1 - cfg.l_sys)
    p_dc = np.maximum(p_dc, 0) * (1 - cfg.derate_strings)
    pdc0_inv = cfg.kwp / cfg.dc_ac_ratio / cfg.inv_eta_nom
    p_ac = pvwatts_ac(p_dc, pdc0_inv, cfg.inv_eta_nom)
    out = pd.DataFrame({"t_utc_h": df.time_utc_index.to_numpy(float) + time_offset_h,
                        "ghi": df.ghi_wm2, "poa": c["poa"], "poa_eff": c["poa_eff"], "tcell": tcell,
                        "temp_air": df.temp_air_c, "p_dc_kw": p_dc, "p_ac_kw": p_ac, "zenith": c["zen"]})
    return out


def _simulate_pvlib(df, cfg, off):  # pragma: no cover - pvlib not available in build env
    import pvlib
    times = pd.DatetimeIndex(df.utc + pd.to_timedelta(off, unit="h")).tz_localize("UTC")
    sp = pvlib.solarposition.get_solarposition(times, LAT, LON)
    poa = pvlib.irradiance.get_total_irradiance(cfg.tilt, cfg.azimuth, sp.apparent_zenith, sp.azimuth,
                                                df.dni_wm2.values, df.ghi_wm2.values, df.dhi_wm2.values,
                                                dni_extra=pvlib.irradiance.get_extra_radiation(times),
                                                model="haydavies", albedo=cfg.albedo)
    aoi = pvlib.irradiance.aoi(cfg.tilt, cfg.azimuth, sp.apparent_zenith, sp.azimuth)
    iam_b = pvlib.iam.physical(aoi)
    sky, gnd = pvlib.iam.marion_diffuse("physical", cfg.tilt).values()
    poa_eff = poa.poa_direct * iam_b + poa.poa_sky_diffuse * sky + poa.poa_ground_diffuse * gnd
    tcell = pvlib.temperature.faiman(poa.poa_global, df.temp_air_c.values, df.wind_speed_ms.values)
    month = times.tz_convert("Asia/Kolkata").month
    l_soil = np.where(np.isin(month, cfg.monsoon_months), cfg.soil_monsoon, cfg.soil_dry)
    p_dc = pvlib.pvsystem.pvwatts_dc(poa_eff, tcell, cfg.kwp * 1000, cfg.gamma) / 1000 * (1 - l_soil) * (1 - cfg.l_sys)
    p_dc = np.maximum(np.asarray(p_dc), 0) * (1 - cfg.derate_strings)
    pdc0_inv = cfg.kwp / cfg.dc_ac_ratio / cfg.inv_eta_nom
    p_ac = pvlib.inverter.pvwatts(p_dc, pdc0_inv, cfg.inv_eta_nom)
    return pd.DataFrame({"t_utc_h": df.time_utc_index.to_numpy(float) + off, "ghi": df.ghi_wm2, "poa": np.asarray(poa.poa_global),
                         "poa_eff": np.asarray(poa_eff), "tcell": np.asarray(tcell), "temp_air": df.temp_air_c,
                         "p_dc_kw": p_dc, "p_ac_kw": np.clip(np.asarray(p_ac), 0, None), "zenith": np.asarray(sp.apparent_zenith)})


def to_local_steps(hourly: pd.DataFrame, dt_min: int, column="p_ac_kw") -> np.ndarray:
    """Resample an hourly UTC series to a local-time (IST) step grid covering one full year,
    00:00 IST 1 Jan .. end of 31 Dec, by linear interpolation on the circular TMY year."""
    n = int(365 * 24 * 60 / dt_min)
    t_ist_mid = (np.arange(n) + 0.5) * dt_min / 60.0                 # hours since 2021-01-01 00:00 IST
    t_utc = (t_ist_mid - IST_OFFSET_H) % 8760.0
    x = hourly.t_utc_h.to_numpy()
    y = hourly[column].to_numpy()
    xp = np.concatenate([x - 8760, x, x + 8760])
    yp = np.concatenate([y, y, y])
    return np.interp(t_utc, xp, yp)


def validation_report(cfg: PVConfig | None = None) -> dict:
    cfg = cfg or PVConfig(kwp=1.0)
    meta = json.loads((DATA / "pvgis_tmy_meta.json").read_text())
    df = load_tmy()
    fit = fit_time_offset(df)
    rep = {"time_offset_fit": fit, "tilts": {}}
    for tilt in (10, 16, 22):
        c = PVConfig(**{**cfg.__dict__, "kwp": 1.0, "tilt": float(tilt)})
        h = simulate_pv(df, c, fit["best_offset_h"])
        ey = float(h.p_ac_kw.sum())
        ref = meta["pvcalc_reference"][str(tilt)]["E_y"]
        rep["tilts"][tilt] = {"model_kwh_per_kwp": round(ey, 1), "pvgis_pvcalc_kwh_per_kwp": ref,
                              "diff_pct": round(100 * (ey / ref - 1), 2),
                              "poa_kwh_m2": round(float(h.poa.sum()) / 1000, 1),
                              "mean_tcell_daylight": round(float(h.tcell[h.poa > 50].mean()), 1)}
    d16 = rep["tilts"][16]["diff_pct"]
    rep["gate_yield_within_5pct"] = abs(d16) <= 5.0
    best = max(rep["tilts"], key=lambda k: rep["tilts"][k]["model_kwh_per_kwp"])
    rep["best_tilt_by_annual_yield"] = best
    return rep


if __name__ == "__main__":
    print(json.dumps(validation_report(), indent=1))
