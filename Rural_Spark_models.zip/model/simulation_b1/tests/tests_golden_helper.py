"""Re-run the golden profile with the current Python twin (used by test_core)."""
import make_golden
import numpy as np
import sys
from pathlib import Path


def run(mode):
    # make_golden.run writes the file; here we only want the array, so call the internals
    from battery import bp_default_params, bp_init, bp_step, bp_limits
    p = bp_default_params(mode)
    p["update_capacity"] = 1
    s = bp_init(p, 0.6, 30.0)
    k, P, dt, T = make_golden.profile()
    rows = []
    for i in range(len(k)):
        lim = bp_limits(p, s, dt[i])
        s, out = bp_step(p, s, P[i], dt[i], T[i])
        rows.append([k[i], P[i], dt[i], T[i], out["P_kW"], out["dE_kWh"], out["loss_kWh"], out["limited"],
                     out["derated"], s["soc"], s["T_C"], s["v_rc"], s["efc"], s["cap"], out["V_pack"], out["I_pack"],
                     lim["P_dis_max_kW"], lim["P_ch_max_kW"]])
    return np.array(rows, float)
