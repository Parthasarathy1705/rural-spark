"""Minimal test runner for environments without pytest:  python tests/run_tests.py"""
import inspect
import sys
import time
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / "src"))
import test_core  # noqa: E402
import test_simulink_equivalence  # noqa: E402

fails = 0
funcs = inspect.getmembers(test_core, inspect.isfunction) + inspect.getmembers(test_simulink_equivalence, inspect.isfunction)
for name, fn in funcs:
    if not name.startswith("test_"):
        continue
    t = time.time()
    try:
        fn()
        print(f"PASS  {name}  ({time.time() - t:.1f}s)")
    except Exception:
        fails += 1
        print(f"FAIL  {name}")
        traceback.print_exc()
print(f"\n{'ALL GREEN' if fails == 0 else str(fails) + ' FAILED'}")
sys.exit(1 if fails else 0)
