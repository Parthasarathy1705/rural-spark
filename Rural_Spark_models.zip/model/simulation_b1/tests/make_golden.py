"""Generate golden vectors for the MATLAB <-> Python battery cross-check.

The profile deliberately exercises every branch: requests above the 0.5C ceiling, the SoC
floor and ceiling, hot ambient that pushes the cell above 45 degC (charge derate), and idle
steps.  Run:  python tests/make_golden.py
"""
import sys
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from battery import bp_default_params, bp_init, bp_step, bp_limits  # noqa: E402

OUT = Path(__file__).resolve().parent / "golden"
COLS = ["k", "P_req_kW", "dt_h", "T_amb_C", "P_kW", "dE_kWh", "loss_kWh", "limited", "derated",
        "soc", "T_C", "v_rc", "efc", "cap", "V_pack", "I_pack", "P_dis_max_kW", "P_ch_max_kW"]


def profile(n=864, seed=7):
    rng = np.random.default_rng(seed)
    k = np.arange(n)
    dt = np.full(n, 5 / 60)
    dt[400:500] = 15 / 60                                  # mixed step lengths
    P = 6 * np.sin(2 * np.pi * k / 144) + rng.normal(0, 2, n)
    P[100:130] = 14.0                                      # above 0.5C -> clipped, drives SoC to floor
    P[200:300] = -12.0                                     # hard charge -> ceiling
    P[600:640] = 0.0                                       # idle
    T = 30 + 12 * np.sin(2 * np.pi * (k - 36) / 288)       # 18..42 degC outdoor
    T[300:420] = 47.0                                      # heat wave -> cell > 45 -> charge derate
    P[330:420] = -9.0
    return k, P, dt, T


def run(mode):
    p = bp_default_params(mode)
    p["update_capacity"] = 1
    s = bp_init(p, 0.6, 30.0)
    k, P, dt, T = profile()
    rows = []
    for i in range(len(k)):
        lim = bp_limits(p, s, dt[i])
        s, out = bp_step(p, s, P[i], dt[i], T[i])
        rows.append([k[i], P[i], dt[i], T[i], out["P_kW"], out["dE_kWh"], out["loss_kWh"], out["limited"],
                     out["derated"], s["soc"], s["T_C"], s["v_rc"], s["efc"], s["cap"],
                     out["V_pack"], out["I_pack"], lim["P_dis_max_kW"], lim["P_ch_max_kW"]])
    a = np.array(rows, float)
    OUT.mkdir(exist_ok=True)
    np.savetxt(OUT / f"battery_golden_{mode}.csv", a, delimiter=",", header=",".join(COLS), comments="", fmt="%.17g")
    return a


if __name__ == "__main__":
    for m in ("energy", "ecm"):
        a = run(m)
        print(m, "rows", len(a), "limited", int(a[:, 7].sum()), "derated", int(a[:, 8].sum()),
              "soc min/max", a[:, 9].min().round(4), a[:, 9].max().round(4), "Tmax", a[:, 10].max().round(1))
