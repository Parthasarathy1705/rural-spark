"""The Simulink model (matlab/build_battery_simulink.m) re-states bp_step's energy mode as blocks:
separate discharge/charge gains, Saturation Dynamic clamp, forward-Euler integrators fed with
increment/Ts, and the thermal update written as T + (T_inf - T)(1 - e).  This test evaluates
exactly that block formulation and checks it equals bp_step on every replay profile."""
import glob
import math
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from battery import bp_default_params, bp_init, bp_step  # noqa: E402


def block_formulation(M):
    dt_h = M[0, 2]; Ts = dt_h * 3600
    bp = bp_default_params("energy", M[0, 5]); bp["capacity_factor0"] = M[0, 6]
    soc, T, efc = M[0, 7], M[0, 3], 0.0
    a = 1 - math.exp(-dt_h * 3600 * bp["UA_W_per_K_per_kWh"] / bp["C_th_J_per_K_per_kWh"])
    out = []
    for k, r in enumerate(M):
        Preq, Ta = r[1], r[3]
        age = k * Ts / (3600 * 8760)
        cap = (bp["capacity_factor0"] - bp["cal_fade_per_year"] * age - bp["cyc_fade_per_efc"] * efc) \
            if bp["update_capacity"] else bp["capacity_factor0"]
        Eeff = bp["E_nom_kWh"] * cap
        Prate = bp["c_rate"] * bp["E_nom_kWh"]
        pdis = max(min(Prate, max(soc - bp["soc_min"], 0) * Eeff * (bp["eta_d"] / dt_h)), 0)
        pchr = Prate * bp["derate_charge"] if T > bp["T_derate_C"] else Prate
        pch = max(min(pchr, max(bp["soc_max"] - soc, 0) * Eeff * (1 / (bp["eta_c"] * dt_h))), 0)
        P = min(max(Preq, -pch), pdis)
        Pd, Pc = max(P, 0), min(P, 0)
        dE = Pd * (-dt_h / bp["eta_d"]) + Pc * (-bp["eta_c"] * dt_h)
        loss = Pd * (dt_h * (1 / bp["eta_d"] - 1)) + Pc * (-dt_h * (1 - bp["eta_c"]))
        dsoc = dE / Eeff
        Tinf = Ta + bp["T_enclosure_offset_C"] + loss * (1000 / dt_h) / (bp["UA_W_per_K_per_kWh"] * bp["E_nom_kWh"])
        out.append((P, min(max(soc + dsoc, bp["soc_min"]), bp["soc_max"]), T + (Tinf - T) * a))
        soc = min(max(soc + Ts * (dsoc / Ts), bp["soc_min"]), bp["soc_max"])
        T = T + Ts * ((Tinf - T) * a / Ts)
        efc = efc + Ts * (Pd * (dt_h / bp["E_nom_kWh"] / Ts))
    return np.array(out)


def test_simulink_block_formulation_equals_bp_step():
    files = sorted(glob.glob(str(ROOT / "results" / "replay" / "*.csv")))
    assert files
    for f in files:
        M = np.loadtxt(f, delimiter=",", skiprows=1)
        E = block_formulation(M)
        p = bp_default_params("energy", M[0, 5]); p["capacity_factor0"] = M[0, 6]
        s = bp_init(p, M[0, 7], M[0, 3]); ref = []
        for r in M:
            s, o = bp_step(p, s, r[1], r[2], r[3]); ref.append((o["P_kW"], s["soc"], s["T_C"]))
        assert np.abs(E - np.array(ref)).max() < 1e-9, f
