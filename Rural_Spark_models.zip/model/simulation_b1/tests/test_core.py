"""Test suite (spec section 10, gate 6).  Runs under pytest, or without it:
    python tests/run_tests.py
"""
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from battery import bp_default_params, bp_init, bp_step, bp_limits   # noqa: E402
from controllers.base import Hysteresis                               # noqa: E402
import run                                                            # noqa: E402
import pv as pvm                                                      # noqa: E402

S3 = None


def _s3():
    global S3
    if S3 is None:
        from sitedata import build_site
        w = run.find_windows(build_site(pvm.PVConfig(), 5))
        S3 = run.run_case({"window": {"kind": "window", "start_day": w["S3"], "n_days": 7, "warmup_days": 7}},
                          keep_sims=True)
    return S3


# ---------------------------------------------------------------- battery
def test_battery_conservation_and_soc_bounds():
    rng = np.random.default_rng(0)
    for mode in ("energy", "ecm"):
        p = bp_default_params(mode)
        p["update_capacity"] = 1
        s = bp_init(p, 0.5, 30)
        for _ in range(5000):
            P = rng.normal(0, 8)
            dt = rng.choice([5 / 60, 15 / 60, 1 / 60])
            s, o = bp_step(p, s, P, dt, rng.uniform(15, 50))
            assert abs(-o["P_kW"] * dt - o["dE_kWh"] - o["loss_kWh"]) < 1e-9
            assert o["loss_kWh"] >= -1e-12
            assert p["soc_min"] - 1e-12 <= s["soc"] <= p["soc_max"] + 1e-12


def test_battery_respects_limits_and_derate():
    p = bp_default_params("energy")
    s = bp_init(p, 0.5, 46.0)                     # hot pack -> charge derate active
    lim = bp_limits(p, s, 5 / 60)
    assert lim["derated"] == 1.0
    assert abs(lim["P_ch_max_kW"] - 0.5 * 0.5 * 20) < 1e-9
    s2, o = bp_step(p, s, -50.0, 5 / 60, 46.0)
    assert -o["P_kW"] <= lim["P_ch_max_kW"] + 1e-12 and o["limited"] == 1.0
    s3, o = bp_step(p, bp_init(p, 0.5, 25), 50.0, 5 / 60, 25)
    assert o["P_kW"] <= 10.0 + 1e-12            # 0.5C ceiling


def test_spec_round_trip_efficiency():
    p = bp_default_params("energy")
    s = bp_init(p, 0.6, 25)
    s, a = bp_step(p, s, -5, 1, 25)
    s, b = bp_step(p, s, 5 * 0.97 * 0.97, 1, 25)
    assert abs(s["soc"] - 0.6) < 1e-12           # 0.97 x 0.97 round trip


def test_python_twin_matches_golden_file():
    """The golden CSVs are what MATLAB is checked against; the twin must still reproduce them."""
    import tests_golden_helper as g
    for mode in ("energy", "ecm"):
        ref = np.loadtxt(ROOT / "tests" / "golden" / f"battery_golden_{mode}.csv", delimiter=",", skiprows=1)
        now = g.run(mode)
        d = np.abs(np.nan_to_num(now) - np.nan_to_num(ref))
        assert d.max() < 1e-12, (mode, d.max())


# ---------------------------------------------------------------- controller pieces
def test_hysteresis_no_chatter():
    h = Hysteresis(0.55, 0.68, 15, 5)
    rng = np.random.default_rng(1)
    soc = 0.55 + rng.normal(0, 0.02, 2000)       # noise straddling the cut threshold
    states = [h.update(i, s) for i, s in enumerate(soc)]
    changes = np.sum(np.diff(np.array(states, int)) != 0)
    assert changes <= 2                          # restore band is 0.13 above: no chatter


def test_hysteresis_respects_dwell():
    h = Hysteresis(0.5, 0.52, 15, 5)
    soc = np.tile([0.40, 0.60], 500)             # pathological square wave every step
    states = np.array([h.update(i, s) for i, s in enumerate(soc)], int)
    idx = np.where(np.diff(states) != 0)[0]
    assert np.all(np.diff(idx) >= 3)             # >= 15 min between relay moves


# ---------------------------------------------------------------- engine-level
def test_energy_balance_every_step():
    res, sims = _s3()
    for c, sim in sims.items():
        assert np.abs(sim.log["resid"]).max() < 1e-9, c


def test_tier1_never_opened_and_priority_never_inverted():
    res, sims = _s3()
    for c, sim in sims.items():
        L = sim.log
        up = L["lvd"] < 0.5
        t3_on = (L["s3b"] + L["s3c"]) > 0
        if c in ("static", "forecast_aware", "oracle"):
            assert not np.any(up & (L["r2"] < 0.5) & t3_on), f"{c}: Tier 3 served while Tier 2 curtailed"
        assert np.all(L["s1"][up] >= L["t1"][up] - 1e-12)       # Tier 1 fully served whenever the bus is up


def test_batch_gate_never_spoils():
    res, sims = _s3()
    for c in ("forecast_aware", "oracle"):
        assert res[c]["batches_spoiled"] == 0
    r = run.run_case({"dt_min": 15, "pv": {"derate_strings": 0.25}}, ["forecast_aware"])
    assert r["forecast_aware"]["batches_spoiled"] == 0


def test_gate4_reactive_fails_in_S3():
    res, _ = _s3()
    assert res["reactive"]["t1_availability_pct"] < 100.0


def test_gate5_oracle_ge_fa_ge_static_tier1():
    res, _ = _s3()
    o, f, s = (res[c]["t1_availability_pct"] for c in ("oracle", "forecast_aware", "static"))
    assert o >= f - 1e-9 and f >= s - 1e-9


def test_relay_transitions_reasonable():
    res, _ = _s3()
    for c in ("static", "forecast_aware", "oracle"):
        assert res[c]["relay_transitions_max_day"] <= 20


def test_pv_yield_within_5pct_of_pvgis():
    rep = pvm.validation_report()
    assert rep["gate_yield_within_5pct"], rep["tilts"][16]
