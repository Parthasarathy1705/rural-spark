function [voc, R0, e, f, a, Reff] = bp_ecm_terms(p, s, dt_h)
%BP_ECM_TERMS  Step-averaged equivalent-circuit terms for a constant cell current.
%   Over a step of dt seconds the polarisation voltage relaxes exponentially towards R1*I:
%       v_rc(t) = R1*I + (v0 - R1*I)*exp(-t/tau)
%   so its step mean is  v_avg = R1*I + (v0 - R1*I)*f,  f = tau/dt*(1 - exp(-dt/tau)).
%   The step-mean terminal voltage is then  v = a - I*Reff  with
%       a    = Voc - v0*f
%       Reff = R0 + R1*(1 - f)
%   Using the step mean (not the start value) keeps terminal power, stored energy and heat
%   exactly consistent, so heat is never negative when the current reverses.
voc = bp_ocv(p, s.soc);
R0 = p.R0_ohm * (1 + p.R0_temp_coeff * max(25 - s.T_C, 0));
dt_s = dt_h * 3600;
e = exp(-dt_s / p.tau1_s);
f = p.tau1_s / dt_s * (1 - e);
a = voc - s.v_rc * f;
Reff = R0 + p.R1_ohm * (1 - f);
end
