function v = bp_ocv(p, soc)
%BP_OCV  Cell open-circuit voltage from the look-up table (linear, clamped).
soc = min(max(soc, 0), 1);
v = interp1(p.ocv_soc, p.ocv_V, soc, 'linear');
end
