function R = bp_testbench(E_nom_kWh)
%BP_TESTBENCH  Characterise the battery pack model and save figures.
%   R = bp_testbench()          20 kWh spec pack
%   R = bp_testbench(40.96)     R1 design pack
%
%   1. Constant-power discharge 100% -> 20% at 0.1C, 0.25C, 0.5C (ECM): voltage curves
%   2. Round-trip efficiency vs C-rate: energy mode (fixed 0.94) vs ECM (emerges from R0, R1)
%   3. Thermal: 0.5C charge on a 40 degC afternoon -> when the 45 degC derate engages
%   4. Life: replacement year vs equivalent full cycles per year (spec fade model)
%   Figures are written to ../results/matlab/.

if nargin < 1, E_nom_kWh = 20; end
here = fileparts(mfilename('fullpath'));
outdir = fullfile(here, '..', 'results', 'matlab');
if ~exist(outdir, 'dir'), mkdir(outdir); end
R = struct();
dt = 1/60;    % 1-minute steps for characterisation

% ---- 1 & 2: discharge curves and round-trip efficiency --------------------------
pe = bp_default_params('ecm', E_nom_kWh);
pn = bp_default_params('energy', E_nom_kWh);
crates = [0.1 0.25 0.5];
f1 = figure('Visible', 'off'); hold on;
rte = zeros(numel(crates), 2);
for c = 1:numel(crates)
    P = crates(c) * pe.E_nom_kWh;
    s = bp_init(pe, 1.0, 25); e_out = 0; V = []; soc = [];
    while true
        [s, o] = bp_step(pe, s, P, dt, 25);
        e_out = e_out + o.P_kW * dt; V(end+1) = o.V_pack; soc(end+1) = s.soc; %#ok<AGROW>
        if o.P_kW < 1e-6, break; end
    end
    e_in = 0;
    while true
        [s, o] = bp_step(pe, s, -P, dt, 25);
        e_in = e_in - o.P_kW * dt;
        if -o.P_kW < 1e-6, break; end
    end
    rte(c, 1) = e_out / e_in;
    plot(1 - soc, V, 'LineWidth', 1.5, 'DisplayName', sprintf('%.2gC', crates(c)));
    % energy mode for the same cycle
    s = bp_init(pn, 1.0, 25); eo = 0; ei = 0;
    while true, [s, o] = bp_step(pn, s, P, dt, 25); eo = eo + o.P_kW*dt; if o.P_kW < 1e-6, break; end, end
    while true, [s, o] = bp_step(pn, s, -P, dt, 25); ei = ei - o.P_kW*dt; if -o.P_kW < 1e-6, break; end, end
    rte(c, 2) = eo / ei;
end
xlabel('Depth of discharge'); ylabel('Pack terminal voltage (V)'); legend('Location', 'southwest');
title(sprintf('ECM pack %.2f kWh: constant-power discharge, 25 degC', pe.E_nom_kWh)); grid on;
saveas(f1, fullfile(outdir, 'bp_discharge_curves.png')); close(f1);
R.crates = crates; R.rte_ecm = rte(:, 1)'; R.rte_energy = rte(:, 2)';

% ---- 3: thermal derate ----------------------------------------------------------
p = bp_default_params('energy', E_nom_kWh);
s = bp_init(p, 0.20, 40); n = 6*60; T = zeros(n,1); Pc = zeros(n,1);
for k = 1:n
    [s, o] = bp_step(p, s, -p.c_rate*p.E_nom_kWh, dt, 40);
    T(k) = s.T_C; Pc(k) = -o.P_kW;
end
f3 = figure('Visible', 'off');
yyaxis left; plot((1:n)/60, T, 'LineWidth', 1.5); ylabel('Cell temperature (degC)');
yyaxis right; plot((1:n)/60, Pc, 'LineWidth', 1.5); ylabel('Accepted charge power (kW)');
xlabel('Hours from start of 0.5C charge, 40 degC outdoor'); grid on;
title('Charge derate above 45 degC (spec section 4)');
saveas(f3, fullfile(outdir, 'bp_thermal_derate.png')); close(f3);
idx = find(T > p.T_derate_C, 1);
if isempty(idx), R.derate_onset_h = NaN; else, R.derate_onset_h = idx/60; end

% ---- 4: life --------------------------------------------------------------------
efc = 0:10:400; yr = zeros(size(efc));
for i = 1:numel(efc), r = bp_life_projection(p, efc(i)); yr(i) = r.replacement_year; end
f4 = figure('Visible', 'off'); plot(efc, yr, 'LineWidth', 1.5); grid on; hold on;
yline(11, '--'); yline(12, '--');
xlabel('Equivalent full cycles per year'); ylabel('Year capacity reaches 80%');
title('Replacement year, spec fade model (1.5%/yr calendar + 5e-5 per EFC)');
saveas(f4, fullfile(outdir, 'bp_life.png')); close(f4);
R.life_efc = efc; R.life_year = yr;
fprintf('Round-trip efficiency at %s C: ECM %s | energy mode %s\n', mat2str(crates), mat2str(R.rte_ecm, 4), mat2str(R.rte_energy, 4));
fprintf('Charge derate engages after %.2f h of 0.5C charge at 40 degC outdoor\n', R.derate_onset_h);
end
