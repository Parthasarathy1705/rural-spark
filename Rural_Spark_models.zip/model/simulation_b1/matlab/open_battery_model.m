function open_battery_model()
%OPEN_BATTERY_MODEL  Open RuralSpark_BatteryPack.slx from THIS folder, closing any copy of the
%   same model that is open from a different folder, and make this folder the active one.
here = fileparts(mfilename('fullpath'));
mdl = 'RuralSpark_BatteryPack';
if bdIsLoaded(mdl), close_system(mdl, 0); end
% remove other copies of this project from the path so the right files are used
p = strsplit(path, pathsep);
other = p(contains(p, 'rs-sim') & ~strcmpi(p, here));
if ~isempty(other), rmpath(other{:}); end
cd(here); addpath(here);
open_system(fullfile(here, [mdl '.slx']));
fprintf('Opened %s\nPress Run in the Simulink window (InitFcn loads the S3 profile; set rs_case to change it).\n', ...
        fullfile(here, [mdl '.slx']));
end
