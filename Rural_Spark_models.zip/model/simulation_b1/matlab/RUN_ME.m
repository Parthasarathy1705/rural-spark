%% RURAL SPARK - Workstream B1: battery pack model + simulation results in MATLAB
%  Open this file in MATLAB and press "Run" (or run one section at a time with
%  Ctrl+Enter).  Works from wherever the rs-sim folder is unzipped.
%  Needs MATLAB R2019b or newer.  No toolboxes needed.
%
%  What it does
%    1. Checks this MATLAB battery pack model against the Python twin used to run
%       the simulations (golden vectors, 864 steps, both model modes)
%    2. Replays the S3 (three overcast days) battery requests of every controller
%       through the MATLAB model and compares the SoC trajectories
%    3. Characterises the pack: discharge curves, round-trip efficiency, thermal
%       derate, replacement year
%    4. Plots the S3 headline figure from the simulation data
%    5. Shows the results table (Tier 1 availability and Tier 3 energy, side by side)
%       and the battery replacement year for each controller

clear; clc; close all;
bdclose('all');                       % close any Simulink model left open (e.g. from another copy of this folder)
% ---- find the rs-sim\matlab folder (works with Run, Run Section, or a copy opened elsewhere)
cands = {};
try, cands{end+1} = fileparts(mfilename('fullpath')); catch, end
try, cands{end+1} = fileparts(matlab.desktop.editor.getActiveFilename); catch, end
cands{end+1} = pwd;
cands{end+1} = fullfile(pwd, 'matlab');
cands{end+1} = fullfile(pwd, 'rs-sim', 'matlab');
cands{end+1} = 'P:\Schnider\Simulation_B1\rs-sim\matlab';
here = '';
for k = 1:numel(cands)
    if ~isempty(cands{k}) && exist(fullfile(cands{k}, 'bp_step.m'), 'file')
        here = cands{k}; break;
    end
end
if isempty(here)
    here = uigetdir(pwd, 'Select the rs-sim\matlab folder (it contains bp_step.m)');
    if isequal(here, 0) || ~exist(fullfile(here, 'bp_step.m'), 'file')
        error('Could not find the battery model files. Open RUN_ME.m from inside the rs-sim\matlab folder.');
    end
end
cd(here);
addpath(here);
root = fullfile(here, '..');
logdir = fullfile(root, 'results', 'matlab');
if ~exist(logdir, 'dir'), mkdir(logdir); end
logfile = fullfile(logdir, 'RUN_ME_command_window_log.txt');
if exist(logfile, 'file'), delete(logfile); end
diary(logfile);                       % everything printed below is also saved to this file
fprintf('RUN_ME started %s on MATLAB %s\n', datestr(now), version);
fprintf('Rural Spark B1 simulation folder: %s\n\n', root);

%% 1. Verify the MATLAB battery pack model against the Python twin
fprintf('--- 1. MATLAB vs Python battery model ---\n');
ok = bp_verify_against_python();
if ~ok
    warning('Battery model mismatch: send this output to the team before using the results.');
end

%% 2. Replay S3 battery requests through the MATLAB model
fprintf('\n--- 2. Replay of S3 (three overcast days) through the MATLAB pack ---\n');
ctrls = {'reactive', 'static', 'forecast_aware', 'oracle'};
for k = 1:numel(ctrls)
    f = fullfile(root, 'results', 'replay', ['S3_' ctrls{k} '.csv']);
    if exist(f, 'file')
        bp_replay(f);
    else
        fprintf('missing %s (run python src/experiments.py)\n', f);
    end
end

%% 3. Battery pack characterisation (figures also saved to results/matlab/)
fprintf('\n--- 3. Battery pack characterisation, 20 kWh ---\n');
R = bp_testbench(20);
figure('Name', 'Battery pack characterisation', 'Color', 'w', 'Position', [60 60 1300 380]);
pics = {'bp_discharge_curves.png', 'bp_thermal_derate.png', 'bp_life.png'};
for k = 1:3
    subplot(1, 3, k);
    img = imread(fullfile(root, 'results', 'matlab', pics{k}));
    image(img); axis image off;
end

%% 4. S3 headline figure: who keeps Tier 1 on through three overcast days?
fprintf('\n--- 4. S3 headline figure ---\n');
names = {'Reactive (incumbent)', 'Static thresholds', 'Forecast-aware (ours)', 'Oracle (perfect foresight)'};
cols  = [0.106 0.686 0.478; 0.922 0.408 0.204; 0.165 0.471 0.839; 0.541 0.537 0.518];
D = cell(1, 4);
for k = 1:4
    D{k} = readmatrix(fullfile(root, 'results', 'matlab_data', ['S3_' ctrls{k} '.csv']), 'NumHeaderLines', 1);
end
% columns: 1 t_day, 2 pv_kw, 3 forecast_kw, 4 soc, 5 blackout, 6 relay_t2, 7 relay_t3,
%          8 t1_kw, 9 t2_demand_kw, 10 t2_served_kw, 11 t3_served_kw, 12 cold_box_c, 13 t1_lost_cum_kwh
t = D{3}(:, 1);
fig = figure('Name', 'S3 headline', 'Color', 'w', 'Position', [80 40 1100 900]);
tl = tiledlayout(fig, 4, 1, 'TileSpacing', 'compact', 'Padding', 'compact');
title(tl, 'S3 - three consecutive overcast days: who keeps the health sub-centre and lights on?', 'FontWeight', 'bold');

ax1 = nexttile(tl);
plot(ax1, t, D{3}(:, 2), 'k', 'LineWidth', 1.3); hold(ax1, 'on');
plot(ax1, t, D{3}(:, 3), '--', 'Color', cols(3, :), 'LineWidth', 1.3);
xline(ax1, 2, ':'); xline(ax1, 5, ':');
ylabel(ax1, 'kW'); title(ax1, '(a) Generation: day-ahead forecast vs actual (shaded days 2-5 = worst 3 days)');
legend(ax1, {'Actual PV', 'Forecast used by our controller'}, 'Location', 'northeast'); grid(ax1, 'on');

ax2 = nexttile(tl);
hold(ax2, 'on');
for k = 1:3
    plot(ax2, t, 100 * D{k}(:, 4), 'Color', cols(k, :), 'LineWidth', 1.8);
end
plot(ax2, t, 100 * D{4}(:, 4), ':', 'Color', cols(4, :), 'LineWidth', 1.3);
yline(ax2, 20, ':', 'SoC floor 20%');
ylim(ax2, [0 105]); ylabel(ax2, 'SoC, %'); title(ax2, '(b) Battery state of charge');
legend(ax2, names, 'Location', 'north', 'NumColumns', 4); grid(ax2, 'on');

ax3 = nexttile(tl);
hold(ax3, 'on');
lab = {};
row = 0;
for k = 3:-1:1
    up = D{k}(:, 5) < 0.5;
    states = {up, up & D{k}(:, 6) > 0.5, up & D{k}(:, 7) > 0.5};
    tiers = {'T1', 'T2', 'T3'};
    for q = 1:3
        row = row + 1;
        s = double(states{q});                 % 1 energised, 0 off
        s(~up) = -1;                           % blackout
        c = zeros(numel(s), 3);
        c(s == 1, :)  = repmat([0.81 0.89 0.96], sum(s == 1), 1);
        c(s == 0, :)  = repmat([0.85 0.85 0.83], sum(s == 0), 1);
        c(s == -1, :) = repmat([0.89 0.29 0.28], sum(s == -1), 1);
        scatter(ax3, t, row * ones(size(t)), 12, c, 's', 'filled');
        lab{end + 1} = sprintf('%s %s', strtok(names{k}, ' '), tiers{q}); %#ok<SAGROW>
    end
end
yticks(ax3, 1:row); yticklabels(ax3, lab); ylim(ax3, [0.5 row + 0.5]);
title(ax3, '(c) Tier status: blue = energised, grey = shed by controller, red = blackout');

ax4 = nexttile(tl);
hold(ax4, 'on');
for k = 1:3
    plot(ax4, t, D{k}(:, 13), 'Color', cols(k, :), 'LineWidth', 1.8);
end
plot(ax4, t, D{4}(:, 13), ':', 'Color', cols(4, :), 'LineWidth', 1.3);
ylabel(ax4, 'kWh'); xlabel(ax4, 'Day of the 7-day S3 window (TMY, 5-min step)');
title(ax4, '(d) Cumulative Tier 1 energy lost (lights, phones, health sub-centre)');
legend(ax4, names, 'Location', 'northwest'); grid(ax4, 'on');
linkaxes([ax1 ax2 ax3 ax4], 'x'); xlim(ax1, [0 t(end)]);
fprintf('Tier 1 energy lost in S3: reactive %.1f kWh | static %.1f | ours %.1f | oracle %.1f\n', ...
        D{1}(end, 13), D{2}(end, 13), D{3}(end, 13), D{4}(end, 13));

%% 5. Results table and battery life
fprintf('\n--- 5. Results: Tier 1 availability and Tier 3 energy, every scenario ---\n');
T = readtable(fullfile(root, 'results', 'results_table.csv'), 'TextType', 'string');
show = T(:, {'scenario', 'controller', 'tier1_availability_pct', 'tier3_useful_kwh', 'tier1_unserved_kwh', ...
             'tier2_served_pct', 'batches_spoiled', 'cold_chain_excursion_h', 'efc_per_year'});
disp(show);

p = bp_default_params('energy', 20);
annual = T(T.scenario == "S4", :);
fprintf('\nBattery replacement year (capacity reaches 80%%), full-year run:\n');
for k = 1:height(annual)
    r = bp_life_projection(p, annual.efc_per_year(k));
    fprintf('  %-16s %5.0f EFC/yr  ->  year %.1f\n', annual.controller(k), annual.efc_per_year(k), r.replacement_year);
end
fprintf('\nDone. Figures: results/matlab/ and the open figure windows.\n');

%% 6. Simulink battery pack model (block level): build, open, verify on every replay profile
%  Builds matlab/RuralSpark_BatteryPack.slx, then runs it on all 16 replay profiles (S1-S3 weeks
%  at 5 min, S4 full years at 15 min, 4 controllers each) and checks it against bp_step.m and the
%  Python simulation.  Expect 'ALL 16 cases PASS'.
build_battery_simulink('S3_forecast_aware', false);
verify_battery_simulink();
open_system('RuralSpark_BatteryPack');
fprintf('\nRUN_ME finished %s. Log: %s\n', datestr(now), logfile);
diary off;
