function r = bp_life_projection(p, efc_per_year)
%BP_LIFE_PROJECTION  Year at which capacity_factor crosses the end-of-life threshold.
%   capacity_factor(y) = 1 - cal_fade*y - cyc_fade*EFC_per_year*y        (spec section 4)
%   r.replacement_year   year when capacity_factor = eol_capacity (0.80)
%   r.fade_per_year      total fade per year
%   r.calendar_share     fraction of the fade that is calendar ageing
fade = p.cal_fade_per_year + p.cyc_fade_per_efc * efc_per_year;
r = struct();
r.efc_per_year = efc_per_year;
r.fade_per_year = fade;
r.replacement_year = (1 - p.eol_capacity) / fade;
r.calendar_share = p.cal_fade_per_year / fade;
% EFC/year the spec's 11-12 year target would allow
r.efc_per_year_for_11y = max(((1 - p.eol_capacity) / 11 - p.cal_fade_per_year) / p.cyc_fade_per_efc, 0);
r.efc_per_year_for_12y = max(((1 - p.eol_capacity) / 12 - p.cal_fade_per_year) / p.cyc_fade_per_efc, 0);
end
