function s = bp_init(p, soc0, T0_C)
%BP_INIT  Initial state of the battery pack.
%   s = bp_init(p, soc0, T0_C)
if nargin < 3, T0_C = 25; end
s = struct();
s.soc = soc0;                    % state of charge, 0..1 of CURRENT capacity
s.T_C = T0_C;                    % lumped pack (cell) temperature
s.v_rc = 0;                      % ECM polarisation voltage per cell (V)
s.efc = 0;                       % equivalent full cycles = cumulative discharge kWh / E_nom
s.throughput_dis_kWh = 0;        % cumulative discharge at the terminals
s.throughput_ch_kWh = 0;         % cumulative charge at the terminals
s.loss_kWh = 0;                  % cumulative conversion loss inside the pack
s.age_years = 0;
s.cap = p.capacity_factor0;      % capacity factor (1 = new)
if s.soc < p.soc_min - 1e-12 || s.soc > p.soc_max + 1e-12
    error('bp_init:soc', 'initial SoC %.4f outside [%.2f, %.2f]', s.soc, p.soc_min, p.soc_max);
end
end
