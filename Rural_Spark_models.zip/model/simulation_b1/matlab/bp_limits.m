function lim = bp_limits(p, s, dt_h)
%BP_LIMITS  Largest discharge and charge power (kW, both >= 0, pack terminals)
%   that bp_step would accept over the next step of dt_h hours.
%   The dispatch engine calls this BEFORE deciding whether loads can be served,
%   then calls bp_step exactly once.
%
%   lim.P_dis_max_kW, lim.P_ch_max_kW, lim.derated (1 if the thermal charge derate is active)

lim = struct();
derated = s.T_C > p.T_derate_C;
lim.derated = double(derated);
E_eff = p.E_nom_kWh * s.cap;

if strcmp(p.mode, 'energy')
    P_rate = p.c_rate * p.E_nom_kWh;
    P_dis_soc = max(s.soc - p.soc_min, 0) * E_eff * p.eta_d / dt_h;
    P_ch_soc  = max(p.soc_max - s.soc, 0) * E_eff / (p.eta_c * dt_h);
    P_ch_rate = P_rate;
    if derated, P_ch_rate = P_rate * p.derate_charge; end
    lim.P_dis_max_kW = max(min(P_rate, P_dis_soc), 0);
    lim.P_ch_max_kW  = max(min(P_ch_rate, P_ch_soc), 0);
else
    [~, ~, ~, ~, a, Reff] = bp_ecm_terms(p, s, dt_h);
    Q = p.Q_Ah * s.cap;
    I_rate = p.c_rate * p.Q_Ah;
    I_dis_soc = max(s.soc - p.soc_min, 0) * Q / dt_h;
    I_ch_soc  = max(p.soc_max - s.soc, 0) * Q / dt_h;
    I_dis_v = max((a - p.V_min) / Reff, 0);
    I_ch_v  = max((p.V_max - a) / Reff, 0);
    I_ch_rate = I_rate;
    if derated, I_ch_rate = I_rate * p.derate_charge; end
    I_dis = min([I_rate, I_dis_soc, I_dis_v]);
    I_ch  = min([I_ch_rate, I_ch_soc, I_ch_v]);
    lim.P_dis_max_kW = max(p.Ns * p.Np * I_dis * (a - I_dis * Reff) / 1000, 0);
    lim.P_ch_max_kW  = max(p.Ns * p.Np * I_ch  * (a + I_ch  * Reff) / 1000, 0);
end
end
