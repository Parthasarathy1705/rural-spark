function ok = bp_verify_against_python()
%BP_VERIFY_AGAINST_PYTHON  Cross-check this MATLAB battery pack model against the
%   golden vectors written by the Python twin (tests/make_golden.py).
%
%   Run from the repo root or from this folder:
%       >> cd matlab; ok = bp_verify_against_python
%
%   Passes when every state and output matches to 1e-9 (absolute) for both the
%   'energy' and 'ecm' modes, across 864 steps that hit the power ceiling, the SoC
%   floor and ceiling, and the >45 degC charge derate.

here = fileparts(mfilename('fullpath'));
gold = fullfile(here, '..', 'tests', 'golden');
modes = {'energy', 'ecm'};
cols = {'P_kW','dE_kWh','loss_kWh','limited','derated','soc','T_C','v_rc','efc','cap','V_pack','I_pack','P_dis_max_kW','P_ch_max_kW'};
ok = true;
for m = 1:numel(modes)
    mode = modes{m};
    M = readmatrix(fullfile(gold, ['battery_golden_' mode '.csv']), 'NumHeaderLines', 1);
    p = bp_default_params(mode);
    p.update_capacity = 1;
    s = bp_init(p, 0.6, 30.0);
    n = size(M, 1);
    got = nan(n, numel(cols));
    for i = 1:n
        P_req = M(i, 2); dt = M(i, 3); T = M(i, 4);
        lim = bp_limits(p, s, dt);
        [s, out] = bp_step(p, s, P_req, dt, T);
        got(i, :) = [out.P_kW, out.dE_kWh, out.loss_kWh, out.limited, out.derated, s.soc, s.T_C, s.v_rc, ...
                     s.efc, s.cap, out.V_pack, out.I_pack, lim.P_dis_max_kW, lim.P_ch_max_kW];
    end
    ref = M(:, 5:end);
    d = abs(got - ref);
    d(isnan(got) & isnan(ref)) = 0;
    [worst, j] = max(d(:));
    [~, c] = ind2sub(size(d), j);
    pass = worst < 1e-9;
    ok = ok && pass;
    % energy balance inside the pack, every step: -P*dt = dE + loss
    bal = max(abs(-got(:,1) .* M(:,3) - got(:,2) - got(:,3)));
    fprintf('%-7s  %d steps  max |MATLAB - Python| = %.3g  (worst column: %s)  energy-balance residual %.3g  -> %s\n', ...
            mode, n, worst, cols{c}, bal, ternary(pass, 'PASS', 'FAIL'));
end
if ok
    fprintf('Battery pack model: MATLAB and Python twin agree. Simulation results apply to this MATLAB model.\n');
end
end

function r = ternary(c, a, b)
if c, r = a; else, r = b; end
end
