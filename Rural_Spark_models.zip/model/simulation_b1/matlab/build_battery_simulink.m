function mdl = build_battery_simulink(caseName, doRun)
%BUILD_BATTERY_SIMULINK  Build the block-level Simulink model of the Rural Spark LFP battery pack.
%
%   build_battery_simulink                      % build, save, run S3 (our controller)
%   build_battery_simulink('S4_forecast_aware') % any file in results/replay/
%   build_battery_simulink('S3_reactive', false)% build only
%
%   Creates matlab/RuralSpark_BatteryPack.slx.  After the first build just open the .slx and
%   press Run: its InitFcn (rs_battery_data.m) loads parameters and the input profile.
%
%   Every equation of the battery pack (spec section 4, energy mode of bp_step.m) is a
%   Simulink block - no MATLAB Function blocks, no hidden code:
%
%     LFP Battery Pack
%       Ageing ............ EFC integrator, calendar + cycle fade -> capacity factor, E_eff
%       Power limits ...... 0.5C ceiling, SoC-window headroom, >45 degC charge derate (Switch)
%       Power clamp ....... Saturation Dynamic [-P_ch_max, +P_dis_max], 'limited' flag
%       Efficiency/losses . eta_c, eta_d split by direction -> dE (stored), loss (heat)
%       SoC integrator .... Discrete-Time Integrator, limits [soc_min, soc_max]
%       Thermal model ..... lumped C_th/UA, exact exponential update, losses heat the pack
%       Electrical view ... OCV(SoC) look-up table -> indicative pack voltage and current
%
%   All parameters come from the struct  bp = bp_default_params('energy', E_nom)  in the base
%   workspace, so the Simulink model, bp_step.m and the Python twin share one parameter set.

if nargin < 1 || isempty(caseName), caseName = 'S3_forecast_aware'; end
if nargin < 2, doRun = true; end
here = local_find_project();             % works even if this file was copied/opened elsewhere
cd(here); addpath(here);
assignin('base', 'rs_case', caseName);
evalin('base', 'rs_battery_data');

mdl = 'RuralSpark_BatteryPack';
if bdIsLoaded(mdl), close_system(mdl, 0); end
f = fullfile(here, [mdl '.slx']);
if exist(f, 'file'), delete(f); end
new_system(mdl);
set_param(mdl, 'Solver', 'FixedStepDiscrete', 'FixedStep', 'Ts', 'StopTime', 'Tstop', ...
    'InitFcn', 'addpath(fileparts(get_param(bdroot, ''FileName''))); rs_battery_data', ...
    'ReturnWorkspaceOutputs', 'on', 'SaveOutput', 'off', 'SaveTime', 'off', 'SaveState', 'off');

% ============================================================== top level
B(mdl, 'P_req', 'simulink/Sources/From Workspace', [40 80 150 110], ...
  'VariableName', 'Preq_in', 'SampleTime', 'Ts', 'Interpolate', 'off', 'OutputAfterFinalValue', 'Holding final value');
B(mdl, 'T_amb', 'simulink/Sources/From Workspace', [40 160 150 190], ...
  'VariableName', 'Tamb_in', 'SampleTime', 'Ts', 'Interpolate', 'off', 'OutputAfterFinalValue', 'Holding final value');
B(mdl, 'SoC_python', 'simulink/Sources/From Workspace', [40 420 150 450], ...
  'VariableName', 'socpy_in', 'SampleTime', 'Ts', 'Interpolate', 'off', 'OutputAfterFinalValue', 'Holding final value');

pk = [mdl '/LFP Battery Pack'];
add_block('built-in/Subsystem', pk, 'Position', [260 60 460 360]);
buildPack(pk);

outs = {'P_kW', 'SoC', 'T_cell_C', 'Loss_kWh', 'EFC', 'Limited', 'Derated', 'Capacity_factor', 'V_pack', 'I_pack'};
B(mdl, 'Mux SoC', 'simulink/Signal Routing/Mux', [560 400 565 460], 'Inputs', '2');
B(mdl, 'SoC: Simulink vs Python', 'simulink/Sinks/Scope', [620 410 660 450]);
B(mdl, 'Mux P', 'simulink/Signal Routing/Mux', [560 40 565 100], 'Inputs', '2');
B(mdl, 'Power: requested vs delivered (kW)', 'simulink/Sinks/Scope', [620 50 660 90]);
B(mdl, 'Mux T', 'simulink/Signal Routing/Mux', [560 130 565 190], 'Inputs', '2');
B(mdl, 'Cell vs outdoor temperature (degC)', 'simulink/Sinks/Scope', [620 140 660 180]);
B(mdl, 'Flags: limited, derated', 'simulink/Sinks/Scope', [620 220 660 260], 'NumInputPorts', '2');
B(mdl, 'Electrical: V_pack, I_pack', 'simulink/Sinks/Scope', [620 300 660 340], 'NumInputPorts', '2');
ws = {'P_sl', 'soc_sl', 'T_sl', 'loss_sl', 'efc_sl', 'limited_sl', 'derated_sl', 'cap_sl', 'V_sl', 'I_sl'};
for k = 1:numel(outs)
    B(mdl, ['to_' ws{k}], 'simulink/Sinks/To Workspace', [760 30 + 45 * k 840 50 + 45 * k], ...
      'VariableName', ws{k}, 'SaveFormat', 'Array', 'SampleTime', '-1');
    L(mdl, ['LFP Battery Pack/' num2str(k)], ['to_' ws{k} '/1']);
end
L(mdl, 'P_req/1', 'LFP Battery Pack/1');
L(mdl, 'T_amb/1', 'LFP Battery Pack/2');
L(mdl, 'P_req/1', 'Mux P/1');            L(mdl, 'LFP Battery Pack/1', 'Mux P/2');
L(mdl, 'Mux P/1', 'Power: requested vs delivered (kW)/1');
L(mdl, 'LFP Battery Pack/3', 'Mux T/1'); L(mdl, 'T_amb/1', 'Mux T/2');
L(mdl, 'Mux T/1', 'Cell vs outdoor temperature (degC)/1');
L(mdl, 'LFP Battery Pack/2', 'Mux SoC/1'); L(mdl, 'SoC_python/1', 'Mux SoC/2');
L(mdl, 'Mux SoC/1', 'SoC: Simulink vs Python/1');
L(mdl, 'LFP Battery Pack/6', 'Flags: limited, derated/1');
L(mdl, 'LFP Battery Pack/7', 'Flags: limited, derated/2');
L(mdl, 'LFP Battery Pack/9', 'Electrical: V_pack, I_pack/1');
L(mdl, 'LFP Battery Pack/10', 'Electrical: V_pack, I_pack/2');

try
add_block('built-in/Note', [mdl '/note'], 'Position', [40 520], 'Text', sprintf([ ...
  'Rural Spark - LFP battery pack, spec section 4 (energy model of bp_step.m)\n' ...
  'Input: P_req > 0 discharge, < 0 charge (kW at pack terminals), outdoor temperature.\n' ...
  'Input profile: battery requests of the Python dispatch simulation (results/replay/%s.csv).\n' ...
  'Parameters: struct bp in the base workspace (bp_default_params.m). Ts = 5 or 15 min.'], 'case'));
catch
end
tidy(mdl);
save_system(mdl, f);
fprintf('Saved %s\n', f);
% diagrams as images for reports
od = fullfile(here, '..', 'results', 'matlab');
if ~exist(od, 'dir'), mkdir(od); end
subs = [{mdl}; find_system(mdl, 'BlockType', 'SubSystem')];
for k = 1:numel(subs)
    try
        nm = regexprep(strrep(subs{k}, [mdl '/'], ''), '[^A-Za-z0-9]+', '_');
        if strcmp(subs{k}, mdl), nm = 'top_level'; end
        print(['-s' subs{k}], '-dpng', '-r150', fullfile(od, ['simulink_' nm '.png']));
    catch
    end
end
if doRun
    verify_battery_simulink({caseName});
end
open_system(mdl);
end

% ====================================================================== the pack
function buildPack(pk)
IN(pk, 'P_req_kW', 1, [20 100 50 114]);
IN(pk, 'T_amb_C', 2, [20 420 50 434]);
names = {'P_kW', 'SoC', 'T_cell_C', 'Loss_kWh', 'EFC', 'Limited', 'Derated', 'Capacity_factor', 'V_pack', 'I_pack'};
for k = 1:numel(names), OUT(pk, names{k}, k, [1180 20 + 50 * k 1210 34 + 50 * k]); end

% ---------------- state integrators (Forward Euler: output = state at the START of the step)
B(pk, 'SoC integrator', 'simulink/Discrete/Discrete-Time Integrator', [700 220 760 270], ...
  'IntegratorMethod', 'Integration: Forward Euler', 'gainval', '1.0', 'InitialCondition', 'soc0', ...
  'LimitOutput', 'on', 'UpperSaturationLimit', 'bp.soc_max', 'LowerSaturationLimit', 'bp.soc_min', 'SampleTime', 'Ts');
B(pk, 'Cell temperature integrator', 'simulink/Discrete/Discrete-Time Integrator', [700 400 760 450], ...
  'IntegratorMethod', 'Integration: Forward Euler', 'gainval', '1.0', 'InitialCondition', 'T0', 'SampleTime', 'Ts');
B(pk, 'EFC integrator', 'simulink/Discrete/Discrete-Time Integrator', [700 560 760 610], ...
  'IntegratorMethod', 'Integration: Forward Euler', 'gainval', '1.0', 'InitialCondition', '0', 'SampleTime', 'Ts');

% ---------------- sub-blocks
ag = [pk '/Ageing'];            add_block('built-in/Subsystem', ag, 'Position', [140 560 260 620]); buildAgeing(ag);
pl = [pk '/Power limits'];      add_block('built-in/Subsystem', pl, 'Position', [300 160 420 260]); buildLimits(pl);
pc = [pk '/Power clamp'];       add_block('built-in/Subsystem', pc, 'Position', [460 90 580 170]);  buildClamp(pc);
el = [pk '/Efficiency and losses']; add_block('built-in/Subsystem', el, 'Position', [620 90 740 170]); buildLosses(el);
sc = [pk '/SoC update'];        add_block('built-in/Subsystem', sc, 'Position', [820 200 940 280]); buildSoc(sc);
th = [pk '/Thermal model'];     add_block('built-in/Subsystem', th, 'Position', [820 380 940 460]); buildThermal(th);
ev = [pk '/Electrical view'];   add_block('built-in/Subsystem', ev, 'Position', [980 500 1100 560]); buildElectrical(ev);
B(pk, 'EFC increment', 'simulink/Math Operations/Gain', [600 570 660 600], 'Gain', 'dt_h/bp.E_nom_kWh/Ts');

% Ageing: in 1 EFC  -> out 1 capacity factor, out 2 E_eff (kWh)
L(pk, 'EFC integrator/1', 'Ageing/1');
% Power limits: in 1 SoC, 2 T_cell, 3 E_eff -> out 1 P_dis_max, 2 P_ch_max, 3 derated
L(pk, 'SoC integrator/1', 'Power limits/1');
L(pk, 'Cell temperature integrator/1', 'Power limits/2');
L(pk, 'Ageing/2', 'Power limits/3');
% Power clamp: in 1 P_req, 2 P_dis_max, 3 P_ch_max -> out 1 P, 2 limited
L(pk, 'P_req_kW/1', 'Power clamp/1');
L(pk, 'Power limits/1', 'Power clamp/2');
L(pk, 'Power limits/2', 'Power clamp/3');
% Efficiency and losses: in 1 P -> out 1 dE (kWh), 2 loss (kWh), 3 discharge kWh this step
L(pk, 'Power clamp/1', 'Efficiency and losses/1');
% SoC update: in 1 SoC(k), 2 dE, 3 E_eff -> out 1 SoC(k+1), 2 integrator input
L(pk, 'SoC integrator/1', 'SoC update/1');
L(pk, 'Efficiency and losses/1', 'SoC update/2');
L(pk, 'Ageing/2', 'SoC update/3');
L(pk, 'SoC update/2', 'SoC integrator/1');
% Thermal: in 1 T(k), 2 loss, 3 T_amb -> out 1 T(k+1), 2 integrator input
L(pk, 'Cell temperature integrator/1', 'Thermal model/1');
L(pk, 'Efficiency and losses/2', 'Thermal model/2');
L(pk, 'T_amb_C/1', 'Thermal model/3');
L(pk, 'Thermal model/2', 'Cell temperature integrator/1');
% EFC
L(pk, 'Efficiency and losses/3', 'EFC increment/1');
L(pk, 'EFC increment/1', 'EFC integrator/1');
% Electrical view: in 1 SoC(k), 2 P -> out 1 V_pack, 2 I_pack
L(pk, 'SoC integrator/1', 'Electrical view/1');
L(pk, 'Power clamp/1', 'Electrical view/2');
% outputs
L(pk, 'Power clamp/1', 'P_kW/1');
L(pk, 'SoC update/1', 'SoC/1');
L(pk, 'Thermal model/1', 'T_cell_C/1');
L(pk, 'Efficiency and losses/2', 'Loss_kWh/1');
L(pk, 'EFC integrator/1', 'EFC/1');
L(pk, 'Power clamp/2', 'Limited/1');
L(pk, 'Power limits/3', 'Derated/1');
L(pk, 'Ageing/1', 'Capacity_factor/1');
L(pk, 'Electrical view/1', 'V_pack/1');
L(pk, 'Electrical view/2', 'I_pack/1');
tidy(pk);
end

function buildAgeing(s)
% capacity factor = cap0 - cal_fade*age - cyc_fade*EFC   (if bp.update_capacity), else cap0
IN(s, 'EFC', 1, [20 120 50 134]);
OUT(s, 'Capacity_factor', 1, [700 80 730 94]);
OUT(s, 'E_eff_kWh', 2, [700 180 730 194]);
B(s, 'Clock (s)', 'simulink/Sources/Digital Clock', [20 30 80 60], 'SampleTime', 'Ts');
B(s, 'Age (years)', 'simulink/Math Operations/Gain', [120 30 180 60], 'Gain', '1/(3600*8760)');
B(s, 'Calendar fade', 'simulink/Math Operations/Gain', [220 30 290 60], 'Gain', 'bp.cal_fade_per_year');
B(s, 'Cycle fade', 'simulink/Math Operations/Gain', [220 110 290 140], 'Gain', 'bp.cyc_fade_per_efc');
B(s, 'cap0', 'simulink/Sources/Constant', [220 180 290 210], 'Value', 'bp.capacity_factor0');
B(s, 'Faded capacity', 'simulink/Math Operations/Sum', [350 60 380 160], 'Inputs', '+--');
B(s, 'update_capacity', 'simulink/Sources/Constant', [350 190 420 220], 'Value', 'bp.update_capacity');
B(s, 'Fade on-off', 'simulink/Signal Routing/Switch', [480 70 530 180], 'Criteria', 'u2 ~= 0');
B(s, 'E_nom', 'simulink/Math Operations/Gain', [580 170 640 200], 'Gain', 'bp.E_nom_kWh');
L(s, 'Clock (s)/1', 'Age (years)/1');
L(s, 'Age (years)/1', 'Calendar fade/1');
L(s, 'EFC/1', 'Cycle fade/1');
L(s, 'cap0/1', 'Faded capacity/1');
L(s, 'Calendar fade/1', 'Faded capacity/2');
L(s, 'Cycle fade/1', 'Faded capacity/3');
L(s, 'Faded capacity/1', 'Fade on-off/1');
L(s, 'update_capacity/1', 'Fade on-off/2');
L(s, 'cap0/1', 'Fade on-off/3');
L(s, 'Fade on-off/1', 'Capacity_factor/1');
L(s, 'Fade on-off/1', 'E_nom/1');
L(s, 'E_nom/1', 'E_eff_kWh/1');
tidy(s);
end

function buildLimits(s)
% P_dis_max = max(min(c_rate*E, (SoC - soc_min)^+ * E_eff * eta_d / dt), 0)
% P_ch_max  = max(min(P_ch_rate, (soc_max - SoC)^+ * E_eff / (eta_c * dt)), 0)
% P_ch_rate = c_rate*E * derate_charge  if T_cell > T_derate, else c_rate*E
IN(s, 'SoC', 1, [20 60 50 74]);
IN(s, 'T_cell', 2, [20 300 50 314]);
IN(s, 'E_eff', 3, [20 180 50 194]);
OUT(s, 'P_dis_max', 1, [900 80 930 94]);
OUT(s, 'P_ch_max', 2, [900 220 930 234]);
OUT(s, 'Derated', 3, [900 320 930 334]);
B(s, 'soc_min', 'simulink/Sources/Constant', [80 20 140 40], 'Value', 'bp.soc_min');
B(s, 'soc_max', 'simulink/Sources/Constant', [80 120 140 140], 'Value', 'bp.soc_max');
B(s, 'SoC above floor', 'simulink/Math Operations/Sum', [180 30 200 70], 'Inputs', '+-');
B(s, 'SoC below ceiling', 'simulink/Math Operations/Sum', [180 110 200 150], 'Inputs', '+-');
B(s, 'pos1', 'simulink/Discontinuities/Saturation', [230 35 270 65], 'UpperLimit', 'inf', 'LowerLimit', '0');
B(s, 'pos2', 'simulink/Discontinuities/Saturation', [230 115 270 145], 'UpperLimit', 'inf', 'LowerLimit', '0');
B(s, 'kWh above floor', 'simulink/Math Operations/Product', [300 40 330 90], 'Inputs', '**');
B(s, 'kWh headroom', 'simulink/Math Operations/Product', [300 120 330 170], 'Inputs', '**');
B(s, 'x eta_d over dt', 'simulink/Math Operations/Gain', [370 45 440 75], 'Gain', 'bp.eta_d/dt_h');
B(s, 'div eta_c dt', 'simulink/Math Operations/Gain', [370 125 440 155], 'Gain', '1/(bp.eta_c*dt_h)');
B(s, 'P_rate (0.5C)', 'simulink/Sources/Constant', [370 240 460 260], 'Value', 'bp.c_rate*bp.E_nom_kWh');
B(s, 'T_derate', 'simulink/Sources/Constant', [80 340 140 360], 'Value', 'bp.T_derate_C');
B(s, 'T > 45 C', 'simulink/Logic and Bit Operations/Relational Operator', [180 300 220 340], 'Operator', '>');
B(s, 'to double', 'simulink/Signal Attributes/Data Type Conversion', [260 305 310 335], 'OutDataTypeStr', 'double');
B(s, 'x derate_charge', 'simulink/Math Operations/Gain', [500 200 560 230], 'Gain', 'bp.derate_charge');
B(s, 'Charge derate', 'simulink/Signal Routing/Switch', [600 200 640 300], 'Criteria', 'u2 ~= 0');
B(s, 'min dis', 'simulink/Math Operations/MinMax', [600 50 640 100], 'Function', 'min', 'Inputs', '2');
B(s, 'min ch', 'simulink/Math Operations/MinMax', [700 130 740 180], 'Function', 'min', 'Inputs', '2');
B(s, 'pos3', 'simulink/Discontinuities/Saturation', [780 60 820 100], 'UpperLimit', 'inf', 'LowerLimit', '0');
B(s, 'pos4', 'simulink/Discontinuities/Saturation', [780 200 820 240], 'UpperLimit', 'inf', 'LowerLimit', '0');
L(s, 'SoC/1', 'SoC above floor/1');      L(s, 'soc_min/1', 'SoC above floor/2');
L(s, 'soc_max/1', 'SoC below ceiling/1'); L(s, 'SoC/1', 'SoC below ceiling/2');
L(s, 'SoC above floor/1', 'pos1/1');     L(s, 'SoC below ceiling/1', 'pos2/1');
L(s, 'pos1/1', 'kWh above floor/1');     L(s, 'E_eff/1', 'kWh above floor/2');
L(s, 'pos2/1', 'kWh headroom/1');        L(s, 'E_eff/1', 'kWh headroom/2');
L(s, 'kWh above floor/1', 'x eta_d over dt/1');
L(s, 'kWh headroom/1', 'div eta_c dt/1');
L(s, 'P_rate (0.5C)/1', 'min dis/1');    L(s, 'x eta_d over dt/1', 'min dis/2');
L(s, 'T_cell/1', 'T > 45 C/1');          L(s, 'T_derate/1', 'T > 45 C/2');
L(s, 'T > 45 C/1', 'to double/1');
L(s, 'P_rate (0.5C)/1', 'x derate_charge/1');
L(s, 'x derate_charge/1', 'Charge derate/1');
L(s, 'to double/1', 'Charge derate/2');
L(s, 'P_rate (0.5C)/1', 'Charge derate/3');
L(s, 'Charge derate/1', 'min ch/1');     L(s, 'div eta_c dt/1', 'min ch/2');
L(s, 'min dis/1', 'pos3/1');             L(s, 'min ch/1', 'pos4/1');
L(s, 'pos3/1', 'P_dis_max/1');           L(s, 'pos4/1', 'P_ch_max/1');
L(s, 'to double/1', 'Derated/1');
tidy(s);
end

function buildClamp(s)
% P = min(max(P_req, -P_ch_max), P_dis_max);  limited = |P - P_req| > 1e-9
IN(s, 'P_req', 1, [20 100 50 114]);
IN(s, 'P_dis_max', 2, [20 40 50 54]);
IN(s, 'P_ch_max', 3, [20 170 50 184]);
OUT(s, 'P', 1, [520 100 550 114]);
OUT(s, 'Limited', 2, [520 220 550 234]);
B(s, 'negate', 'simulink/Math Operations/Gain', [90 160 130 190], 'Gain', '-1');
B(s, 'Clamp to pack limits', 'simulink/Discontinuities/Saturation Dynamic', [200 60 260 180]);
B(s, 'P - P_req', 'simulink/Math Operations/Sum', [320 200 340 240], 'Inputs', '+-');
B(s, '|.|', 'simulink/Math Operations/Abs', [370 205 400 235]);
B(s, 'tol', 'simulink/Sources/Constant', [370 250 400 270], 'Value', '1e-9');
B(s, '> tol', 'simulink/Logic and Bit Operations/Relational Operator', [430 205 460 245], 'Operator', '>');
B(s, 'to double', 'simulink/Signal Attributes/Data Type Conversion', [480 210 500 240], 'OutDataTypeStr', 'double');
L(s, 'P_ch_max/1', 'negate/1');
L(s, 'P_dis_max/1', 'Clamp to pack limits/1');
L(s, 'P_req/1', 'Clamp to pack limits/2');
L(s, 'negate/1', 'Clamp to pack limits/3');
L(s, 'Clamp to pack limits/1', 'P/1');
L(s, 'Clamp to pack limits/1', 'P - P_req/1'); L(s, 'P_req/1', 'P - P_req/2');
L(s, 'P - P_req/1', '|.|/1'); L(s, '|.|/1', '> tol/1'); L(s, 'tol/1', '> tol/2');
L(s, '> tol/1', 'to double/1'); L(s, 'to double/1', 'Limited/1');
tidy(s);
end

function buildLosses(s)
% discharge (P>0): dE = -P dt / eta_d,  loss = P dt (1/eta_d - 1)
% charge    (P<0): dE = -P eta_c dt,    loss = -P dt (1 - eta_c)
IN(s, 'P', 1, [20 100 50 114]);
OUT(s, 'dE_kWh', 1, [560 60 590 74]);
OUT(s, 'Loss_kWh', 2, [560 180 590 194]);
OUT(s, 'Discharge_kWh', 3, [560 260 590 274]);
B(s, 'Discharge part', 'simulink/Discontinuities/Saturation', [100 60 150 90], 'UpperLimit', 'inf', 'LowerLimit', '0');
B(s, 'Charge part', 'simulink/Discontinuities/Saturation', [100 140 150 170], 'UpperLimit', '0', 'LowerLimit', '-inf');
B(s, 'minus dt over eta_d', 'simulink/Math Operations/Gain', [220 30 300 60], 'Gain', '-dt_h/bp.eta_d');
B(s, '-eta_c dt', 'simulink/Math Operations/Gain', [220 90 300 120], 'Gain', '-bp.eta_c*dt_h');
B(s, 'dt (1 over eta_d - 1)', 'simulink/Math Operations/Gain', [220 150 300 180], 'Gain', 'dt_h*(1/bp.eta_d-1)');
B(s, '-dt (1 - eta_c)', 'simulink/Math Operations/Gain', [220 210 300 240], 'Gain', '-dt_h*(1-bp.eta_c)');
B(s, 'x dt', 'simulink/Math Operations/Gain', [220 260 300 290], 'Gain', 'dt_h');
B(s, 'dE', 'simulink/Math Operations/Sum', [380 40 400 110], 'Inputs', '++');
B(s, 'loss', 'simulink/Math Operations/Sum', [380 160 400 230], 'Inputs', '++');
L(s, 'P/1', 'Discharge part/1'); L(s, 'P/1', 'Charge part/1');
L(s, 'Discharge part/1', 'minus dt over eta_d/1'); L(s, 'Charge part/1', '-eta_c dt/1');
L(s, 'Discharge part/1', 'dt (1 over eta_d - 1)/1'); L(s, 'Charge part/1', '-dt (1 - eta_c)/1');
L(s, 'Discharge part/1', 'x dt/1');
L(s, 'minus dt over eta_d/1', 'dE/1'); L(s, '-eta_c dt/1', 'dE/2');
L(s, 'dt (1 over eta_d - 1)/1', 'loss/1'); L(s, '-dt (1 - eta_c)/1', 'loss/2');
L(s, 'dE/1', 'dE_kWh/1'); L(s, 'loss/1', 'Loss_kWh/1'); L(s, 'x dt/1', 'Discharge_kWh/1');
tidy(s);
end

function buildSoc(s)
% dSoC = dE / E_eff;  SoC(k+1) = sat(SoC(k) + dSoC);  integrator input = dSoC / Ts
IN(s, 'SoC_k', 1, [20 40 50 54]);
IN(s, 'dE', 2, [20 100 50 114]);
IN(s, 'E_eff', 3, [20 160 50 174]);
OUT(s, 'SoC_next', 1, [500 60 530 74]);
OUT(s, 'dSoC_rate', 2, [500 160 530 174]);
B(s, 'dE over E_eff', 'simulink/Math Operations/Product', [110 100 140 150], 'Inputs', '*/');
B(s, 'SoC + dSoC', 'simulink/Math Operations/Sum', [220 40 240 90], 'Inputs', '++');
B(s, 'SoC window', 'simulink/Discontinuities/Saturation', [300 50 350 80], 'UpperLimit', 'bp.soc_max', 'LowerLimit', 'bp.soc_min');
B(s, 'div Ts', 'simulink/Math Operations/Gain', [300 150 350 180], 'Gain', '1/Ts');
L(s, 'dE/1', 'dE over E_eff/1'); L(s, 'E_eff/1', 'dE over E_eff/2');
L(s, 'SoC_k/1', 'SoC + dSoC/1'); L(s, 'dE over E_eff/1', 'SoC + dSoC/2');
L(s, 'SoC + dSoC/1', 'SoC window/1'); L(s, 'SoC window/1', 'SoC_next/1');
L(s, 'dE over E_eff/1', 'div Ts/1'); L(s, 'div Ts/1', 'dSoC_rate/1');
tidy(s);
end

function buildThermal(s)
% Q = loss/dt * 1000 (W);  T_inf = T_amb + T_offset + Q/UA;
% T(k+1) = T(k) + (T_inf - T(k)) * (1 - exp(-dt*UA/C_th))      (exact for a first-order lump)
IN(s, 'T_k', 1, [20 40 50 54]);
IN(s, 'Loss_kWh', 2, [20 120 50 134]);
IN(s, 'T_amb', 3, [20 200 50 214]);
OUT(s, 'T_next', 1, [640 60 670 74]);
OUT(s, 'dT_rate', 2, [640 160 670 174]);
B(s, 'Heat (W)', 'simulink/Math Operations/Gain', [100 115 160 145], 'Gain', '1000/dt_h');
B(s, 'div UA', 'simulink/Math Operations/Gain', [190 115 250 145], 'Gain', '1/(bp.UA_W_per_K_per_kWh*bp.E_nom_kWh)');
B(s, 'Shed offset', 'simulink/Sources/Constant', [100 240 160 260], 'Value', 'bp.T_enclosure_offset_C');
B(s, 'T_inf', 'simulink/Math Operations/Sum', [300 120 320 220], 'Inputs', '+++');
B(s, 'T_inf - T', 'simulink/Math Operations/Sum', [370 90 390 150], 'Inputs', '+-');
B(s, 'x (1 - exp(-dt UA over C))', 'simulink/Math Operations/Gain', [430 105 520 135], 'Gain', ...
  '1-exp(-dt_h*3600*bp.UA_W_per_K_per_kWh/bp.C_th_J_per_K_per_kWh)');
B(s, 'T + dT', 'simulink/Math Operations/Sum', [560 40 580 100], 'Inputs', '++');
B(s, 'div Ts', 'simulink/Math Operations/Gain', [560 150 600 180], 'Gain', '1/Ts');
L(s, 'Loss_kWh/1', 'Heat (W)/1'); L(s, 'Heat (W)/1', 'div UA/1');
L(s, 'T_amb/1', 'T_inf/1'); L(s, 'Shed offset/1', 'T_inf/2'); L(s, 'div UA/1', 'T_inf/3');
L(s, 'T_inf/1', 'T_inf - T/1'); L(s, 'T_k/1', 'T_inf - T/2');
L(s, 'T_inf - T/1', 'x (1 - exp(-dt UA over C))/1');
L(s, 'T_k/1', 'T + dT/1'); L(s, 'x (1 - exp(-dt UA over C))/1', 'T + dT/2');
L(s, 'T + dT/1', 'T_next/1');
L(s, 'x (1 - exp(-dt UA over C))/1', 'div Ts/1'); L(s, 'div Ts/1', 'dT_rate/1');
tidy(s);
end

function buildElectrical(s)
% Indicative electrical view: pack OCV = Ns * OCV_cell(SoC);  I = P*1000 / V
% (the energy model has no internal resistance; the full ECM is in bp_step.m 'ecm' mode)
IN(s, 'SoC', 1, [20 40 50 54]);
IN(s, 'P_kW', 2, [20 140 50 154]);
OUT(s, 'V_pack', 1, [460 40 490 54]);
OUT(s, 'I_pack', 2, [460 140 490 154]);
B(s, 'OCV(SoC) cell', 'simulink/Lookup Tables/1-D Lookup Table', [100 30 170 70], ...
  'Table', 'bp.ocv_V', 'BreakpointsForDimension1', 'bp.ocv_soc', 'ExtrapMethod', 'Clip');
B(s, 'x Ns', 'simulink/Math Operations/Gain', [210 35 260 65], 'Gain', 'bp.Ns');
B(s, 'kW -> W', 'simulink/Math Operations/Gain', [100 135 160 165], 'Gain', '1000');
B(s, 'I = P over V', 'simulink/Math Operations/Product', [320 120 350 170], 'Inputs', '*/');
L(s, 'SoC/1', 'OCV(SoC) cell/1'); L(s, 'OCV(SoC) cell/1', 'x Ns/1'); L(s, 'x Ns/1', 'V_pack/1');
L(s, 'P_kW/1', 'kW -> W/1'); L(s, 'kW -> W/1', 'I = P over V/1'); L(s, 'x Ns/1', 'I = P over V/2');
L(s, 'I = P over V/1', 'I_pack/1');
tidy(s);
end

% ====================================================================== helpers
function B(sys, name, lib, pos, varargin)
add_block(lib, [sys '/' name], 'Position', pos, varargin{:});
end

function IN(sys, name, port, pos)
add_block('built-in/Inport', [sys '/' name], 'Port', num2str(port), 'Position', pos);
end

function OUT(sys, name, port, pos)
add_block('built-in/Outport', [sys '/' name], 'Port', num2str(port), 'Position', pos);
end

function L(sys, a, b)
add_line(sys, a, b, 'autorouting', 'smart');
end

function tidy(sys)
try
    Simulink.BlockDiagram.arrangeSystem(sys);
catch
end
end

function here = local_find_project()
%RS_FIND_PROJECT  Locate the rs-sim\matlab folder (the one containing rs_battery_data.m and bp_step.m).
%   Checks this file's folder, the current folder and its sub-folders, the usual install location,
%   and finally asks with a folder picker.
cands = {};
try, cands{end+1} = fileparts(mfilename('fullpath')); catch, end
try, cands{end+1} = fileparts(matlab.desktop.editor.getActiveFilename); catch, end
cands{end+1} = pwd;
cands{end+1} = fullfile(pwd, 'matlab');
cands{end+1} = fullfile(pwd, 'rs-sim', 'matlab');
cands{end+1} = 'P:\Schnider\Simulation_B1\rs-sim\matlab';
w = which('rs_battery_data');
if ~isempty(w), cands{end+1} = fileparts(w); end
here = '';
for k = 1:numel(cands)
    c = cands{k};
    if ~isempty(c) && exist(fullfile(c, 'rs_battery_data.m'), 'file') && exist(fullfile(c, 'bp_step.m'), 'file')
        here = c; return;
    end
end
here = uigetdir(pwd, 'Select the rs-sim\matlab folder (contains bp_step.m)');
if isequal(here, 0) || ~exist(fullfile(here, 'bp_step.m'), 'file')
    error('Could not find the rs-sim\\matlab folder. Unzip Rural_Spark_B1_FINAL.zip and run RUN_ME.m from rs-sim\\matlab.');
end
end
