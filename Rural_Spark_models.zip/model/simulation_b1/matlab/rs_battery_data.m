%RS_BATTERY_DATA  Load parameters and the input profile for RuralSpark_BatteryPack.slx.
%   Runs automatically as the model's InitFcn.  To replay another case, set for example
%       rs_case = 'S3_reactive';      (any file name in results/replay/, without .csv)
%   in the Command Window before pressing Run.
if ~exist('rs_case', 'var'), rs_case = 'S3_forecast_aware'; end
rs_dir = fileparts(which('rs_battery_data'));
rs_file = fullfile(rs_dir, '..', 'results', 'replay', [rs_case '.csv']);
if ~exist(rs_file, 'file')
    error('Replay file not found: %s', rs_file);
end
rs_M = readmatrix(rs_file, 'NumHeaderLines', 1);
% columns: t_h, P_req_kW, dt_h, T_amb_C, soc_python, E_nom_kWh, capacity_factor0, soc0
dt_h  = rs_M(1, 3);
Ts    = dt_h * 3600;                         % sample time, seconds
rs_n  = size(rs_M, 1);
rs_t  = (0:rs_n - 1)' * Ts;
Preq_in  = [rs_t, rs_M(:, 2)];
Tamb_in  = [rs_t, rs_M(:, 4)];
socpy_in = [rs_t, rs_M(:, 5)];
bp = bp_default_params('energy', rs_M(1, 6));   % one parameter set for Simulink, bp_step.m and Python
bp.capacity_factor0 = rs_M(1, 7);
soc0  = rs_M(1, 8);
T0    = rs_M(1, 4);
Tstop = (rs_n - 1) * Ts;
fprintf('Loaded %s: %d steps of %.0f min (%.1f days), pack %.2f kWh, SoC0 %.2f\n', ...
        rs_case, rs_n, dt_h * 60, rs_n * dt_h / 24, bp.E_nom_kWh, soc0);
