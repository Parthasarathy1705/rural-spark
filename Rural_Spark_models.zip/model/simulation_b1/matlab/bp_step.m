function [s, out] = bp_step(p, s, P_req_kW, dt_h, T_amb_C)
%BP_STEP  Advance the battery pack by one time step.
%
%   [s, out] = bp_step(p, s, P_req_kW, dt_h, T_amb_C)
%
%   P_req_kW  requested power at the pack terminals: > 0 discharge, < 0 charge
%   dt_h      step length in hours (5 min = 5/60)
%   T_amb_C   outdoor air temperature
%
%   out.P_kW      power actually exchanged at the terminals (same sign convention)
%   out.dE_kWh    change of stored (chemical) energy; negative when discharging
%   out.loss_kWh  energy lost inside the pack this step (>= 0)
%                 energy balance: -out.P_kW*dt_h = out.dE_kWh + out.loss_kWh
%   out.limited   1 if the request was clipped by a power, SoC, voltage or thermal limit
%   out.V_pack, out.I_pack  terminal voltage and current (ECM mode; NaN in energy mode)
%
%   Hard invariant (spec section 4): soc_min <= SoC <= soc_max after every step.

lim = bp_limits(p, s, dt_h);
P = min(max(P_req_kW, -lim.P_ch_max_kW), lim.P_dis_max_kW);
out = struct();
out.limited = double(abs(P - P_req_kW) > 1e-9);
out.derated = lim.derated;
E_eff = p.E_nom_kWh * s.cap;

if strcmp(p.mode, 'energy')
    if P >= 0
        dE = -P * dt_h / p.eta_d;
        loss = P * dt_h * (1 / p.eta_d - 1);
    else
        dE = -P * p.eta_c * dt_h;
        loss = -P * dt_h * (1 - p.eta_c);
    end
    s.soc = s.soc + dE / E_eff;
    out.V_pack = NaN;
    out.I_pack = NaN;
else
    [voc, ~, e, ~, a, Reff] = bp_ecm_terms(p, s, dt_h);
    cells = p.Ns * p.Np;
    P_cell_W = P * 1000 / cells;
    if abs(P_cell_W) < 1e-12
        I = 0;
    else
        I = (a - sqrt(a * a - 4 * Reff * P_cell_W)) / (2 * Reff);   % >0 discharge, <0 charge
    end
    v_term = a - I * Reff;                                    % step-mean terminal voltage
    C1 = p.tau1_s / p.R1_ohm;
    v0 = s.v_rc;
    v1 = v0 * e + p.R1_ohm * (1 - e) * I;
    dE_cap = 0.5 * C1 * (v1 * v1 - v0 * v0) * cells / 3.6e6; % polarisation energy, kWh
    dE = -cells * voc * I * dt_h / 1000 + dE_cap;             % chemical + polarisation store
    loss = -dE - P * dt_h;                                    % heat in R0 and R1 (>= 0)
    Q = p.Q_Ah * s.cap;
    s.soc = s.soc - I * dt_h / Q;
    s.v_rc = v1;
    out.V_pack = p.Ns * v_term;
    out.I_pack = p.Np * I;
end

% numerical guard: limits were computed so this only removes round-off
if s.soc < p.soc_min - 1e-9 || s.soc > p.soc_max + 1e-9
    error('bp_step:soc', 'SoC invariant violated: %.6f', s.soc);
end
s.soc = min(max(s.soc, p.soc_min), p.soc_max);

% lumped thermal model: pack losses heat the pack, cabinet exchanges with shed air
C_th = p.C_th_J_per_K_per_kWh * p.E_nom_kWh;
UA = p.UA_W_per_K_per_kWh * p.E_nom_kWh;
Q_heat_W = loss / dt_h * 1000;
T_air = T_amb_C + p.T_enclosure_offset_C;
T_inf = T_air + Q_heat_W / UA;
s.T_C = T_inf + (s.T_C - T_inf) * exp(-dt_h * 3600 * UA / C_th);

% bookkeeping and degradation
if P > 0
    s.throughput_dis_kWh = s.throughput_dis_kWh + P * dt_h;
    s.efc = s.efc + P * dt_h / p.E_nom_kWh;
else
    s.throughput_ch_kWh = s.throughput_ch_kWh - P * dt_h;
end
s.loss_kWh = s.loss_kWh + loss;
s.age_years = s.age_years + dt_h / 8760;
if p.update_capacity
    s.cap = p.capacity_factor0 - p.cal_fade_per_year * s.age_years - p.cyc_fade_per_efc * s.efc;
end

out.P_kW = P;
out.dE_kWh = dE;
out.loss_kWh = loss;
end
