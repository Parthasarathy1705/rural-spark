function T = verify_battery_simulink(cases)
%VERIFY_BATTERY_SIMULINK  Run RuralSpark_BatteryPack.slx on replay profiles and compare with
%   (a) the Python simulation's SoC and (b) the MATLAB function model bp_step.m.
%
%   T = verify_battery_simulink                 % every file in results/replay/
%   T = verify_battery_simulink({'S3_reactive'})
%
%   Pass criterion: max |SoC difference| < 1e-8 (the replay CSVs store 10 significant digits).
here = local_find_project();
cd(here); addpath(here);
mdl = 'RuralSpark_BatteryPack';
target = fullfile(here, [mdl '.slx']);
if bdIsLoaded(mdl) && ~strcmpi(get_param(mdl, 'FileName'), target)
    close_system(mdl, 0);            % a copy from another folder is open: close it
end
if ~bdIsLoaded(mdl), load_system(target); end
if nargin < 1 || isempty(cases)
    d = dir(fullfile(here, '..', 'results', 'replay', '*.csv'));
    cases = erase({d.name}, '.csv');
end
rows = {};
for k = 1:numel(cases)
    assignin('base', 'rs_case', cases{k});
    out = sim(mdl);
    soc_sl = out.get('soc_sl');
    P_sl = out.get('P_sl');
    T_sl = out.get('T_sl');
    socpy = evalin('base', 'socpy_in(:,2)');
    % same profile through the MATLAB function model
    M = evalin('base', 'rs_M');
    p = evalin('base', 'bp');
    s = bp_init(p, M(1, 8), M(1, 4));
    soc_m = zeros(size(M, 1), 1); P_m = soc_m; T_m = soc_m;
    for i = 1:size(M, 1)
        [s, o] = bp_step(p, s, M(i, 2), M(i, 3), M(i, 4));
        soc_m(i) = s.soc; P_m(i) = o.P_kW; T_m(i) = s.T_C;
    end
    n = min([numel(soc_sl), numel(socpy), numel(soc_m)]);
    d_py = max(abs(soc_sl(1:n) - socpy(1:n)));
    d_m  = max(abs(soc_sl(1:n) - soc_m(1:n)));
    d_P  = max(abs(P_sl(1:n) - P_m(1:n)));
    d_T  = max(abs(T_sl(1:n) - T_m(1:n)));
    pass = d_py < 1e-8 && d_m < 1e-9 && d_P < 1e-9 && d_T < 1e-9;
    rows(end + 1, :) = {cases{k}, n, d_py, d_m, d_P, d_T, pass}; %#ok<AGROW>
    fprintf('%-22s %6d steps  |SoC SL-Python| %.2e  |SoC SL-bp_step| %.2e  |P| %.2e  |T| %.2e  %s\n', ...
            cases{k}, n, d_py, d_m, d_P, d_T, tern(pass));
end
T = cell2table(rows, 'VariableNames', {'case', 'steps', 'soc_vs_python', 'soc_vs_bp_step', 'P_vs_bp_step', ...
                                        'Tcell_vs_bp_step', 'pass'});
if all(T.pass)
    fprintf('Simulink battery pack model: ALL %d cases PASS\n', height(T));
end
od = fullfile(here, '..', 'results', 'matlab');
if ~exist(od, 'dir'), mkdir(od); end
writetable(T, fullfile(od, 'simulink_verification.csv'));
end

function s = tern(c)
if c, s = 'PASS'; else, s = 'FAIL'; end
end

function here = local_find_project()
%RS_FIND_PROJECT  Locate the rs-sim\matlab folder (the one containing rs_battery_data.m and bp_step.m).
%   Checks this file's folder, the current folder and its sub-folders, the usual install location,
%   and finally asks with a folder picker.
cands = {};
try, cands{end+1} = fileparts(mfilename('fullpath')); catch, end
try, cands{end+1} = fileparts(matlab.desktop.editor.getActiveFilename); catch, end
cands{end+1} = pwd;
cands{end+1} = fullfile(pwd, 'matlab');
cands{end+1} = fullfile(pwd, 'rs-sim', 'matlab');
cands{end+1} = 'P:\Schnider\Simulation_B1\rs-sim\matlab';
w = which('rs_battery_data');
if ~isempty(w), cands{end+1} = fileparts(w); end
here = '';
for k = 1:numel(cands)
    c = cands{k};
    if ~isempty(c) && exist(fullfile(c, 'rs_battery_data.m'), 'file') && exist(fullfile(c, 'bp_step.m'), 'file')
        here = c; return;
    end
end
here = uigetdir(pwd, 'Select the rs-sim\matlab folder (contains bp_step.m)');
if isequal(here, 0) || ~exist(fullfile(here, 'bp_step.m'), 'file')
    error('Could not find the rs-sim\\matlab folder. Unzip Rural_Spark_B1_FINAL.zip and run RUN_ME.m from rs-sim\\matlab.');
end
end
