function p = bp_default_params(mode, E_nom_kWh)
%BP_DEFAULT_PARAMS  Parameter set for the Rural Spark LFP battery pack model.
%
%   p = bp_default_params()                 energy-mode pack, 20 kWh (spec section 4)
%   p = bp_default_params('ecm')            cell-level equivalent-circuit pack, 16S4P x 100 Ah
%   p = bp_default_params('energy', 40.96)  energy-mode pack of a different size
%
%   Two fidelity levels share one interface (bp_init / bp_limits / bp_step):
%
%   'energy'  Spec section 4 exactly: SoC += eta_c*P*dt/E (charge), SoC -= P*dt/(eta_d*E)
%             (discharge), SoC window 0.20-1.00, 0.5C power ceiling, 50% charge derate
%             above 45 degC cell temperature, linear calendar + cycle fade.
%   'ecm'     Physics view of the same pack: Ns x Np LFP cells, OCV(SoC) look-up,
%             series resistance R0 plus one RC pair, current and voltage limits, the same
%             thermal model and derate.  Round-trip efficiency is an OUTPUT of this mode.
%
%   Every value marked ASSUMED is a generic LFP figure chosen by the team, not a
%   datasheet value.  Replace with the selected cell's datasheet before quoting.
%
%   Units: kWh, kW, V, A, ohm, s, degC.

if nargin < 1 || isempty(mode), mode = 'energy'; end
if nargin < 2, E_nom_kWh = []; end

p = struct();
p.mode = mode;

% ---- spec section 4 (energy-mode core) ---------------------------------------
p.E_nom_kWh   = 20.0;    % spec
p.eta_c       = 0.97;    % spec, charge efficiency
p.eta_d       = 0.97;    % spec, discharge efficiency (round trip ~0.94)
p.soc_min     = 0.20;    % spec, floor (80% usable DoD)
p.soc_max     = 1.00;    % spec
p.c_rate      = 0.5;     % spec, 0.5C charge and discharge ceiling
p.T_derate_C  = 45.0;    % spec, cell temperature above which charge is derated
p.derate_charge = 0.5;   % spec, charge current reduced by 50%

% ---- degradation (spec section 4) --------------------------------------------
p.cal_fade_per_year = 0.015;   % spec
p.cyc_fade_per_efc  = 5e-5;    % spec: 20% fade over 4000 EFC
p.eol_capacity      = 0.80;    % spec: replacement threshold
p.capacity_factor0  = 1.0;     % starting capacity factor (S9 sets 0.80)
p.update_capacity   = 0;       % 0 = hold capacity fixed during a run (scenario studies)
                               % 1 = fade capacity step by step (life studies)

% ---- thermal (both modes) - ASSUMED -------------------------------------------
p.C_th_J_per_K_per_kWh = 7000;   % ASSUMED: ~7 kg/kWh pack mass x ~1000 J/(kg K)
p.UA_W_per_K_per_kWh   = 1.0;    % ASSUMED: naturally ventilated cabinet, 20 W/K at 20 kWh
p.T_enclosure_offset_C = 2.0;    % ASSUMED: shed air runs 2 K above outdoor air

% ---- ECM (cell level) - ASSUMED generic 100 Ah prismatic LFP --------------------
p.Ns      = 16;          % series cells (51.2 V nominal)
p.Np      = 4;           % parallel strings -> 16S4P x 100 Ah = 20.48 kWh
p.Q_Ah    = 100;         % cell capacity
p.V_nom   = 3.2;         % cell nominal voltage
p.V_min   = 2.50;        % cell discharge cut-off
p.V_max   = 3.65;        % cell charge cut-off
p.R0_ohm  = 0.0008;      % ASSUMED cell ohmic resistance at 25 degC (DC, 10 s)
p.R1_ohm  = 0.0004;      % ASSUMED polarisation resistance
p.tau1_s  = 60;          % ASSUMED polarisation time constant
p.R0_temp_coeff = 0.01;  % ASSUMED: R0 rises 1%/K below 25 degC
% generic LFP open-circuit voltage curve (ILLUSTRATIVE - replace with cell datasheet)
p.ocv_soc = [0.00 0.05 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 0.95 1.00];
p.ocv_V   = [2.50 3.10 3.20 3.25 3.28 3.29 3.30 3.31 3.32 3.33 3.35 3.40 3.55];

if strcmp(mode, 'ecm')
    p.E_nom_kWh = p.Ns * p.Np * p.Q_Ah * p.V_nom / 1000;
end
if ~isempty(E_nom_kWh)
    if strcmp(mode, 'ecm')
        % scale parallel strings continuously so the pack energy matches
        p.Np = E_nom_kWh * 1000 / (p.Ns * p.Q_Ah * p.V_nom);
    end
    p.E_nom_kWh = E_nom_kWh;
end
end
