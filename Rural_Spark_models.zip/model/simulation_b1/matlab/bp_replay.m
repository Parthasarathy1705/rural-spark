function T = bp_replay(csvfile, mode)
%BP_REPLAY  Re-run the battery side of a simulation in MATLAB.
%
%   T = bp_replay('../results/replay/S3_forecast_aware.csv')
%
%   The Python engine writes, for every step, the power it REQUESTED from the pack, the step
%   length, outdoor temperature, and the SoC the pack reported.  Because the pack model is
%   deterministic, feeding the same requests through this MATLAB model must reproduce the
%   SoC trajectory exactly; this is how the MATLAB model is shown to be the one behind the
%   results.  Prints the largest SoC difference and returns a table with both trajectories.
if nargin < 2, mode = 'energy'; end
M = readmatrix(csvfile, 'NumHeaderLines', 1);
% columns: t_h, P_req_kW, dt_h, T_amb_C, soc_python, E_nom_kWh, capacity_factor0, soc0
p = bp_default_params(mode, M(1, 6));
p.capacity_factor0 = M(1, 7);
s = bp_init(p, M(1, 8), M(1, 4));
n = size(M, 1); soc = zeros(n, 1);
for i = 1:n
    [s, ~] = bp_step(p, s, M(i, 2), M(i, 3), M(i, 4));
    soc(i) = s.soc;
end
d = max(abs(soc - M(:, 5)));
fprintf('%s: %d steps, max |SoC_MATLAB - SoC_Python| = %.3g\n', csvfile, n, d);
T = table(M(:,1), soc, M(:,5), 'VariableNames', {'t_h', 'soc_matlab', 'soc_python'});
end
