"""Rural Spark R1 — reconciled capex and 15-year cash-flow / asset-renewal model.
All money in INR, nominal. Every input is labelled in ASSUMPTIONS with its type.
Run: python3 finance.py  -> writes CSV/JSON to ./out
"""
import json, csv, os, copy

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
os.makedirs(OUT, exist_ok=True)

# ---------------- CAPEX (R1: 34 x 540 Wp = 18.36 kWp; 40.96 kWh HV LFP; 15 kW 3-ph hybrid PCS) -------------
PV_W = 34 * 540
BATT_KWH = 40.96
CAPEX_LINES = [
    # key, label, base, opt, pess, basis/type
    ("pv", "PV modules 34 x 540 Wp (18.36 kWp)", PV_W * 26, PV_W * 22, PV_W * 32, "published range Rs22-28/Wp module-only (Powermore 2026); +DCR premium in pess; supplier-quote needed"),
    ("mount", "HDG ground-mount structure, foundations, array fence", PV_W * 6.5, PV_W * 5.5, PV_W * 8, "estimate (application used Rs6/Wp)"),
    ("pcs", "15 kW 3-phase hybrid PCS, island/grid-forming, HV battery", 260000, 220000, 350000, "online listing Deye 15 kW 3-ph hybrid Rs2.6 lakh (IndiaMART); certified island-capable model may cost more"),
    ("batt", "40.96 kWh HV LFP battery with BMS, rack, switchgear", BATT_KWH * 20000, BATT_KWH * 16000, BATT_KWH * 26000, "published C&I range Rs16-26k/kWh (lithiuminverter.in, May 2026); supplier-quote needed"),
    ("ctrl", "EMS controller, gateway/GSM, HMI, sensors; 30 smart meters; 25 household essential/flexible branch controls", 210000, 170000, 260000, "estimate: meters ~Rs3,500 x30; branch control ~Rs1,800 x25; controller/gateway Rs60k"),
    ("dist", "LT 415/240 V ABC network (~800 m), poles, service drops, DBs, protection, SPD, earthing", 420000, 300000, 550000, "estimate pending GPS route survey"),
    ("room", "Battery/PCS enclosure, fire & lightning protection, signage", 140000, 110000, 180000, "estimate"),
    ("install", "Transport (~150 km incl. forest road), installation, testing, commissioning, design review", 180000, 140000, 240000, "estimate"),
    ("community", "Baseline survey, co-design workshops, operator training", 80000, 60000, 100000, "estimate"),
]
CONTINGENCY = {"base": 0.10, "opt": 0.07, "pess": 0.15}

def capex(case="base"):
    idx = {"base": 2, "opt": 3, "pess": 4}[case]
    lines = [(l[0], l[1], round(l[idx])) for l in CAPEX_LINES]
    sub = sum(l[2] for l in lines)
    cont = round(sub * CONTINGENCY[case])
    return lines, sub, cont, sub + cont

# ---------------- FUNDING (conditional — none sanctioned) -----------------------------------------------
FUNDING = [
    ("PM-JANMAN New Solar Power Scheme: mini-grid CFA Rs50,000 x 25 un-electrified PVTG households", 1250000, "MNRE guidelines 18 Oct 2024 para 2.1.4; household component FY23-24 to FY25-26 - continuation must be confirmed"),
    ("PM-JANMAN: Multi-Purpose Centre solarisation (Rs1 lakh per MPC)", 100000, "guidelines para 2.2.2; only if an MPC is sanctioned at this habitation"),
    ("PM JUGA public-institution solarisation Rs1 lakh/kW (school, anganwadi, health sub-centre; 1 kW each)", 300000, "guidelines para 2.3.2 (FY24-25 to FY28-29); eligibility of mini-grid-served institutions to be confirmed"),
]

# ---------------- ENERGY (from 16-yr PVGIS simulation, R1 budget controller) ------------------------------
SERVED_KWH_Y1 = 13866          # simulated, customer side
PV_DEG = 0.005                 # /yr, assumption (typical module warranty ~0.4-0.55 %/yr)

# ---------------- OPERATING MODEL ----------------------------------------------------------------------
BASE = dict(
    name="Base",
    # monthly revenue streams (INR/month, year-1)
    hh_tariff=3000,         # 20 HH x Rs100 + 5 HH x Rs200 (application) — willingness-to-pay NOT yet measured
    parity=3750,            # ITDA/State energy-service parity payment Rs150/HH/month x 25 (proposal; not agreed)
    institutions=2000,      # school+anganwadi+health SC+MPC ~146 kWh/month (~Rs13.7/kWh) ITDA/line-dept contract (proposal)
    water=1000,             # Gram Panchayat / RWS (proposal)
    ntfp=3500,              # village-organisation processing unit ~225 kWh/month (~Rs15.6/kWh, below diesel genset cost) (proposal)
    shops=600,
    collection=0.92,        # share of billed revenue collected
    parity_collection=1.0,  # paid by agency
    tariff_growth=0.04,     # /yr nominal
    # opex (INR/yr, year-1 prices)
    operator=36000, cleaning=6000, insurance=15000, comms=3000, spares=12000,
    amc_after_cmc=35000,    # repairs/technical support once the 5-yr vendor CMC ends (scheme requires 5-yr CMC)
    cmc_years=5,
    opex_inflation=0.05,
    # renewals (INR nominal at time of event)
    batt_year=13, batt_cost=BATT_KWH * 20000,   # replace at ~70-75% SOH: sim shows Tier-1 99.9% at 70% SOH
    pcs_year=12, pcs_cost=260000,
    ctrl_year=8, ctrl_cost=90000,
    interest=0.06,          # reserve-fund deposit rate
    opening_reserve=0,
    years=15,
)

def scenario(**kw):
    s = copy.deepcopy(BASE); s.update(kw); return s

SCENARIOS = {
    "Tariff-only (application tariffs, no parity payment)": scenario(name="Tariff-only", parity=0, institutions=1500),
    "Application timing (battery yr 12, no parity)": scenario(name="App-timing", parity=0, institutions=1500, batt_year=12),
    "Base": scenario(),
    "Optimistic": scenario(name="Optimistic", collection=0.97, tariff_growth=0.05, opex_inflation=0.045,
                           batt_year=14, batt_cost=BATT_KWH * 14000, pcs_cost=220000, ntfp=4500),
    "Pessimistic": scenario(name="Pessimistic", collection=0.80, tariff_growth=0.03, opex_inflation=0.06,
                            batt_year=10, batt_cost=BATT_KWH * 26000, pcs_year=10, pcs_cost=350000, ntfp=1750,
                            parity_collection=0.9),
}

def run(s):
    reserve = s["opening_reserve"]; rows = []
    for y in range(1, s["years"] + 1):
        g = (1 + s["tariff_growth"]) ** (y - 1)
        billed = 12 * g * (s["hh_tariff"] + s["institutions"] + s["water"] + s["ntfp"] + s["shops"])
        parity = 12 * g * s["parity"]
        collected = billed * s["collection"] + parity * s["parity_collection"]
        inf = (1 + s["opex_inflation"]) ** (y - 1)
        opex = inf * (s["operator"] + s["cleaning"] + s["insurance"] + s["comms"] + s["spares"]
                      + (s["amc_after_cmc"] if y > s["cmc_years"] else 0))
        renew = 0; ev = []
        if y == s["batt_year"]: renew += s["batt_cost"]; ev.append("battery")
        if y == s["pcs_year"]: renew += s["pcs_cost"]; ev.append("PCS")
        if y == s["ctrl_year"]: renew += s["ctrl_cost"]; ev.append("controls/meters")
        interest = max(0, reserve) * s["interest"]
        surplus = collected - opex
        reserve = reserve + interest + surplus - renew
        served = SERVED_KWH_Y1 * (1 - PV_DEG) ** (y - 1)
        rows.append(dict(year=y, billed=round(billed), parity=round(parity), collected=round(collected), opex=round(opex),
                         operating_surplus=round(surplus), interest=round(interest), renewals=round(renew),
                         event="+".join(ev), closing_reserve=round(reserve), served_kwh=round(served),
                         opex_cover=round(collected / opex, 2)))
    return rows

def summary(rows, s):
    m = min(rows, key=lambda r: r["closing_reserve"])
    first_neg = next((r["year"] for r in rows if r["closing_reserve"] < 0), None)
    return dict(min_reserve=m["closing_reserve"], min_year=m["year"], first_negative_year=first_neg,
                y15_reserve=rows[-1]["closing_reserve"], y1_collected=rows[0]["collected"], y1_opex=rows[0]["opex"],
                y1_opex_cover=rows[0]["opex_cover"], total_renewals=sum(r["renewals"] for r in rows))

def npv(rate, flows):
    return sum(f / (1 + rate) ** t for t, f in enumerate(flows))

def lcoe(case="base", rate=0.08, s=None):
    s = s or BASE
    _, _, _, cap = capex(case)
    rows = run(s)
    costs = [cap] + [r["opex"] + r["renewals"] for r in rows]
    energy = [0] + [r["served_kwh"] for r in rows]
    return npv(rate, costs) / npv(rate, energy)

def tornado():
    base_min = summary(run(BASE), BASE)["min_reserve"]
    tests = [
        ("Collection 92% -> 80%", dict(collection=0.80)),
        ("No parity payment", dict(parity=0)),
        ("Parity Rs150 -> Rs100/HH", dict(parity=2500)),
        ("NTFP revenue halved", dict(ntfp=1750)),
        ("Battery Rs20k -> Rs26k/kWh", dict(batt_cost=BATT_KWH * 26000)),
        ("Battery replaced yr 13 -> yr 10", dict(batt_year=10, pcs_year=10)),
        ("Opex inflation 5% -> 7%", dict(opex_inflation=0.07)),
        ("Tariff growth 4% -> 2%", dict(tariff_growth=0.02)),
        ("Battery Rs20k -> Rs14k/kWh", dict(batt_cost=BATT_KWH * 14000)),
        ("Household tariff +50%", dict(hh_tariff=4500)),
    ]
    out = []
    for lab, kw in tests:
        s = scenario(**kw); out.append((lab, summary(run(s), s)["min_reserve"] - base_min, summary(run(s), s)["min_reserve"]))
    return base_min, out

if __name__ == "__main__":
    res = {"capex": {}, "scenarios": {}, "funding": FUNDING}
    for c in ["base", "opt", "pess"]:
        lines, sub, cont, tot = capex(c)
        res["capex"][c] = dict(lines=lines, subtotal=sub, contingency=cont, total=tot, per_connection=round(tot / 30),
                               per_household=round(tot / 25), per_kwp=round(tot / 18.36))
    fund = sum(f[1] for f in FUNDING)
    res["funding_total"] = fund
    res["funding_gap_base"] = res["capex"]["base"]["total"] - fund
    allrows = []
    for k, s in SCENARIOS.items():
        rows = run(s); res["scenarios"][k] = dict(summary=summary(rows, s), rows=rows)
        for r in rows: allrows.append({"scenario": k, **r})
    with open(os.path.join(OUT, "cashflow_15yr.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(allrows[0])); w.writeheader(); w.writerows(allrows)
    res["lcoe_rs_per_kwh"] = {c: round(lcoe(c), 2) for c in ["base", "opt", "pess"]}
    # Project-level investor view on full capex (honest: not investable without capital grant)
    cap = res["capex"]["base"]["total"]; rows = run(BASE)
    flows = [-cap] + [r["collected"] - r["opex"] - r["renewals"] for r in rows]
    res["project_npv_8pct_full_capex"] = round(npv(0.08, flows))
    res["simple_payback_years_full_capex"] = round(cap / max(1, rows[0]["collected"] - rows[0]["opex"]), 1)
    # Grant-funded view: community/operator cash NPV (capex = 0)
    res["operator_npv_8pct_grant_capex"] = round(npv(0.08, [0] + flows[1:]))
    b, t = tornado(); res["tornado_base_min_reserve"] = b; res["tornado"] = t
    # Counterfactual: 25 standalone 0.3 kW SHS
    res["shs_counterfactual"] = dict(capex=25 * 50000, kwp=25 * 0.3, note="Rs50,000/HH CFA cap; 5-yr CMC; no institutional/productive supply; no billing relationship")
    json.dump(res, open(os.path.join(OUT, "finance_results.json"), "w"), indent=1)
    print(json.dumps({k: v for k, v in res.items() if k not in ("scenarios",)}, indent=1)[:4000])
    for k, v in res["scenarios"].items(): print(k, v["summary"])
