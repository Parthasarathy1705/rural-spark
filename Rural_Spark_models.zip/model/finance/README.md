# Finance model

`python3 finance.py` writes `out/finance_results.json` and CSVs: capital cost (base, optimistic, pessimistic), funding stack, 15-year cash flow and renewal reserve for each scenario, LCOE, NPV and a single-shock sensitivity table. Every input is labelled in the script by type (published price, estimate, proposal).
