function RSrun(H){
 const out={};
 // climate stats (IST-aligned days)
 const N=H.length-24, nd=Math.floor(N/24), dy=[];
 for(let d=0;d<nd;d++){let s=0;for(let h=0;h<24;h++){const j=d*24+h-6;if(j>=0)s+=H[j].P/1000;}dy.push(s);}
 const mon=Array.from({length:12},()=>[]); const yrs={};
 for(let d=1;d<nd;d++){const t=H[d*24].time;const m=+t.slice(4,6)-1;mon[m].push(dy[d]);const y=t.slice(0,4);yrs[y]=(yrs[y]||0)+dy[d];}
 const q=(a,p)=>{const b=[...a].sort((x,y)=>x-y);return b[Math.floor(p*(b.length-1))];};
 out.monthly=mon.map((a,i)=>({m:i+1,mean:+(a.reduce((x,y)=>x+y,0)/a.length).toFixed(3),p10:+q(a,.1).toFixed(2),p50:+q(a,.5).toFixed(2),min:+Math.min(...a).toFixed(2)}));
 out.annual=Object.fromEntries(Object.entries(yrs).map(([k,v])=>[k,+(v).toFixed(0)]));
 const run=n=>{let w=1e9,wi=0;for(let d=1;d+n<nd;d++){let s=0;for(let k=0;k<n;k++)s+=dy[d+k];if(s<w){w=s;wi=d;}}return {kWhPerKWp:+w.toFixed(2),avgPerDay:+(w/n).toFixed(2),start:H[wi*24].time.slice(0,8)};};
 out.worst={d1:run(1),d3:run(3),d5:run(5),d7:run(7)};
 out.daysBelow={lt1:dy.filter(x=>x<1).length,lt2:dy.filter(x=>x<2).length,lt3:dy.filter(x=>x<3).length,n:nd};
 // longest run of days below 50% of mean daily need proxy (2.0 kWh/kWp)
 const R=(o)=>{const r=RSsim(H,o);delete r.trace;return r;};
 const D0={pv:9.72,batt:20,kva:10,chargeKW:8,dischargeKW:8};
 const D1={pv:14.04,batt:40.96};
 out.controllers={};
 for(const [dn,D] of [['D0',D0],['D1',D1]]){
  out.controllers[dn]={
   none:R({...D,controller:'none'}),
   e1_rule:R({...D,controller:'rule'}),
   e1_forecast_persist:R({...D,controller:'forecast',forecast:'persistence'}),
   e1_forecast_perfect:R({...D,controller:'forecast',forecast:'perfect'}),
   reserve_noforecast:R({...D,controller:'reserve',forecast:'none'}),
   reserve_persist:R({...D,controller:'reserve',forecast:'persistence'}),
   reserve_noisy:R({...D,controller:'reserve',forecast:'noisy'}),
   reserve_perfect:R({...D,controller:'reserve',forecast:'perfect'})};
 }
 out.sweep=[];
 for(const n of [18,24,26,30,34,40]) for(const b of [20.48,30.72,40.96,51.2,61.44]){
  const r=R({pv:n*.54,batt:b,controller:'reserve',forecast:'persistence'});
  out.sweep.push({mods:n,pv:+(n*.54).toFixed(2),batt:b,svc:r.serviceRatio,t1:r.t1Ratio,t2:r.t2Ratio,t3:r.t3Ratio,ilr:r.ilrRatio,t1FailDays:r.t1FailDaysPerYr,t1FailH:r.t1FailHperYr,eve:r.eveningLightOKpct,cyc:r.cyclesPerYr,spill:r.spillPct,unmet:r.unmetKWhPerYr,served:r.servedKWhPerYr});
 }
 return out;
}
