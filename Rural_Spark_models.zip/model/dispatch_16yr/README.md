# Model A: 16-year hourly dispatch

`sim.js` runs the R1 plant (PV, battery, inverter, tiered loads) hour by hour on PVGIS-ERA5 hourly PV output for 2005–2020 at 16.37°N, 78.83°E and compares control rules (no priority, fixed SoC floors, energy budget with offline or weather forecast). `runner.js` runs the scenarios and summary statistics. `sim_results.json` holds the outputs used in the deck (for example `R1_34mod_40.96` for the four controllers on the final design).
