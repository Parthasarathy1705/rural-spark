// Rural Spark R1 — hourly multi-year dispatch on measured-climate (PVGIS ERA5) PV series.
// Port of E1 model.js logic to 1-hour steps. Input: H = array of {P (W per kWp, 14% losses), T2m}, UTC hourly.
// Returns summaries only. Deterministic.
function RSsim(H, opt) {
  const o = Object.assign({
    pv: 14.04, batt: 40.96, soh: 1, kva: 15, pf: 0.9, chargeKW: 12, dischargeKW: 12,
    etaInv: 0.94, etaDist: 0.97, etaC: 0.96, etaD: 0.96, minSOC: 0.2, maxSOC: 0.95, initSOC: 0.75,
    aux: 0.04, demand: 1, hh: 25, controller: 'forecast', forecast: 'persistence', seed: 7,
    loads: null, pvScale: 1, holdoverILR: 0, bufferDays: 1, startHour: 0, nHours: null, trace: false
  }, opt || {});
  const loads = o.loads || RSloads();
  // Hourly demand per load (kWh in hour h, IST)
  const prof = loads.map(l => {
    const a = new Array(24).fill(0);
    for (let h = 0; h < 24; h++) for (const w of l.windows) a[h] += Math.max(0, Math.min(h + 1, w[1]) - Math.max(h, w[0]));
    return a.map(x => x * l.qty * l.kw * (l.house ? o.hh / 25 : 1) * o.demand);
  });
  const dailyDemand = prof.reduce((s, a) => s + a.reduce((x, y) => x + y, 0), 0);
  const dcDaily = dailyDemand / (o.etaInv * o.etaDist) + 24 * o.aux;
  const N = o.nHours || H.length - 24;
  // IST alignment: UTC sample at hh:30 ~ IST (hh+6):00 boundary. Shift +6h.
  const pvAt = i => { const j = i - 6; return j < 0 ? 0 : (H[j].P / 1000) * o.pv * o.pvScale; };
  const nDays = Math.floor(N / 24);
  const dayPV = new Float64Array(nDays + 2);
  for (let d = 0; d < nDays + 1; d++) { let s = 0; for (let h = 0; h < 24; h++) { const i = d * 24 + h; if (i < H.length + 6) s += pvAt(i); } dayPV[d] = s; }
  // RNG for noisy forecast
  let rs = o.seed; const rnd = () => { rs = (rs * 1103515245 + 12345) % 2147483648; return rs / 2147483648; };
  const gauss = () => { let u = 0, v = 0; while (u === 0) u = rnd(); v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
  // Remaining DC energy per tier from hour h until next 08:00 (incl. aux in T1)
  const tierDC = [1,2,3].map(t => { const a = new Array(24).fill(0); loads.forEach((l,k)=>{ if(l.tier===t) for(let h=0;h<24;h++) a[h]+=prof[k][h]/(o.etaInv*o.etaDist)/o.etaD; }); if(t===1) for(let h=0;h<24;h++) a[h]+=o.aux/o.etaD; return a; });
  const needR = tierDC.map(a => { const r = new Array(24).fill(0); for (let h = 0; h < 24; h++) { let s = 0; let k = h; while (k !== 8) { s += a[k]; k = (k + 1) % 24; } r[h] = s; } return r; });
  const t1Day = tierDC[0].reduce((x,y)=>x+y,0), t2Day = tierDC[1].reduce((x,y)=>x+y,0);
  const cap = o.batt * o.soh, emin = cap * o.minSOC, emax = cap * o.maxSOC;
  let e = cap * o.initSOC, state = 'NORMAL'; let shortV=0; const shp=[]; for(let x=0;x<24;x++) shp.push(Math.max(0,Math.sin(Math.PI*((x+.5)-6)/12))); const ss=shp.reduce((p,q)=>p+q,0); const remFrac=new Array(25).fill(0); for(let x=23;x>=0;x--) remFrac[x]=remFrac[x+1]+shp[x]/ss; const dayRem=new Array(25).fill(0); for(let x=17;x>=0;x--) dayRem[x]=dayRem[x+1]+(x>=6? tierDC[0][x]+tierDC[1][x] : 0);
  const MO = Array.from({length:12},()=>({d:[0,0,0],s:[0,0,0],pv:0,days:0})); const T = { pv: 0, dem: 0, srv: 0, spill: 0, t: [[0, 0], [0, 0], [0, 0]], ilrD: 0, ilrS: 0, thr: 0, t1FailH: 0, t1FailDays: 0, allOkH: 0, nightLightOkDays: 0, waterD: 0, waterS: 0, states: {}, minSOC: 1, ilrOutH: 0, maxILRrun: 0 };
  let ilrRun = 0, holdLeft = o.holdoverILR; // hours of thermal holdover for vaccine fridge
  const tiers = loads.map(l => l.tier);
  const trace = [];
  let dayT1fail = false, dayLightOK = true;
  for (let i = 0; i < N; i++) {
    const d = Math.floor(i / 24), h = i % 24;
    if (h === 0) {
      if (i > 0) { if (dayT1fail) T.t1FailDays++; if (dayLightOK) T.nightLightOkDays++; }
      dayT1fail = false; dayLightOK = true;
    }
    // Forecast of today's PV, made at start of day
    let fc;
    if (o.forecast === 'perfect') fc = dayPV[d];
    else if (o.forecast === 'persistence') fc = d > 0 ? dayPV[d - 1] : dayPV[d];
    else if (o.forecast === 'noisy') fc = dayPV[d] * Math.exp(0.35 * gauss() - 0.06);
    else fc = dayPV[d];
    const ratio = fc * 0.85 / dcDaily;
    const soc = e / cap;
    let floors;
    if (o.controller === 'none') { state = 'NONE'; floors = [o.minSOC, o.minSOC, o.minSOC]; }
    else if (o.controller === 'rule') {
      if (soc < 0.28 || (state === 'CRITICAL_RESERVE' && soc < 0.33)) state = 'CRITICAL_RESERVE'; else if (soc < 0.4) state = 'CONSERVATION'; else state = 'NORMAL';
      floors = state === 'NORMAL' ? [.2, .3, .45] : [.2, .55, .85];
    } else if (o.controller === 'reserve') {
      // Energy-reserve dispatch: protect DC energy for Tier1 (and Tier2 for T3) until next 08:00,
      // plus a forecast-scaled buffer for tomorrow. Forecast of the next solar day:
      let fn;
      const nd = h >= 12 ? d + 1 : d;
      if (o.forecast === 'perfect') fn = dayPV[nd];
      else if (o.forecast === 'persistence') fn = h >= 19 ? dayPV[d] : (d > 0 ? dayPV[d - 1] : dayPV[d]);
      else if (o.forecast === 'noisy') fn = dayPV[nd] * Math.exp(0.35 * gauss() - 0.06);
      else if (o.forecast === 'none') fn = dcDaily / 0.85; // assume adequate sun: no forecast buffer
      else fn = dayPV[nd];
      const short = Math.max(0, Math.min(1, 1 - fn * 0.85 / dcDaily)); shortV = short;
      const R1 = needR[0][h] + short * o.bufferDays * t1Day, R2 = needR[1][h] + short * 0.5 * t2Day;
      state = short > 0.4 ? 'CONSERVATION' : short > 0.15 ? 'FORECAST_WARNING' : 'NORMAL';
      if (soc < 0.28) state = 'CRITICAL_RESERVE';
      floors = [o.minSOC, Math.min(o.maxSOC, (emin + R1) / cap), Math.min(o.maxSOC, (emin + R1 + R2) / cap)];
    } else {
      if (soc < 0.28 || (state === 'CRITICAL_RESERVE' && soc < 0.33)) state = 'CRITICAL_RESERVE';
      else if (soc < 0.4 || ratio < 0.6) state = 'CONSERVATION';
      else if (ratio < 0.85) state = 'FORECAST_WARNING';
      else state = 'NORMAL';
      floors = state === 'NORMAL' ? [.2, .3, .45] : state === 'FORECAST_WARNING' ? [.2, .4, .65] : [.2, .55, .85];
    }
    T.states[state] = (T.states[state] || 0) + 1;
    const pv = pvAt(i);
    let avail = pv, invRoom = o.kva * o.pf, disRoom = o.dischargeKW, bOut = 0;
    // aux
    let a = Math.min(avail, o.aux); avail -= a;
    let fromB = Math.min(o.aux - a, disRoom, Math.max(0, e - emin) * o.etaD); e -= fromB / o.etaD; disRoom -= fromB; bOut += fromB;
    const want = prof.map(p => p[h]), srv = want.map(() => 0); const pend=[]; const isDay = h>=6 && h<18; let fcT; if(o.forecast==='perfect') fcT=dayPV[d]; else if(o.forecast==='persistence') fcT=(d>0?dayPV[d-1]:dayPV[d]); else if(o.forecast==='noisy') fcT=dayPV[d]*Math.exp(0.35*gauss()-0.06); else fcT=dcDaily/0.85; let usedDC=0;
    for (let tier = 1; tier <= 3; tier++) for (let k = 0; k < loads.length; k++) {
      if (tiers[k] !== tier || want[k] <= 0) continue;
      const need = Math.min(want[k] / (o.etaInv * o.etaDist), invRoom / o.etaInv);
      let blocked=false; if(o.chargeFirst && tier>1){ if(isDay){ const rem=fcT*remFrac[h+1]*0.85; const proj=e-emin+rem*o.etaC-dayRem[h+1]-usedDC; const req = tier===2 ? needR[0][18]+shortV*o.bufferDays*t1Day : needR[0][18]+needR[1][18]+shortV*(o.bufferDays*t1Day+0.5*t2Day); blocked = proj - need < req; } else blocked = e < cap*floors[tier-1]; } const dir = blocked?0:Math.min(avail, need); avail -= dir; if(blocked) pend.push(k); else if(tier>1) usedDC+=need;
      const dis = Math.min(need - dir, disRoom, Math.max(0, e - cap * floors[tier - 1]) * o.etaD);
      e -= dis / o.etaD; disRoom -= dis; bOut += dis;
      const bus = dir + dis; invRoom -= bus * o.etaInv; srv[k] = bus * o.etaInv * o.etaDist;
    }
    let chg = 0;
    if (bOut < 1e-9) { chg = Math.min(avail, o.chargeKW, Math.max(0, emax - e) / o.etaC); e += chg * o.etaC; avail -= chg; }
    for (const k of pend){ const nd3=Math.min((want[k]-srv[k])/(o.etaInv*o.etaDist), invRoom/o.etaInv); const dd=Math.min(avail,nd3); avail-=dd; invRoom-=dd*o.etaInv; srv[k]+=dd*o.etaInv*o.etaDist; } T.thr += bOut / o.etaD;
    T.pv += pv; T.spill += avail;
    let t1d = 0, t1s = 0, dem = 0, sv = 0;
    for (let k = 0; k < loads.length; k++) {
      dem += want[k]; sv += srv[k]; T.t[tiers[k] - 1][0] += want[k]; T.t[tiers[k] - 1][1] += srv[k];
      if (tiers[k] === 1) { t1d += want[k]; t1s += srv[k]; }
    }
    T.dem += dem; T.srv += sv;
    const ilr = loads.findIndex(l => l.id === 'ilr');
    if (ilr >= 0) {
      T.ilrD += want[ilr]; T.ilrS += srv[ilr];
      if (srv[ilr] < want[ilr] - 1e-9) { ilrRun++; if (ilrRun > holdLeft) T.ilrOutH++; T.maxILRrun = Math.max(T.maxILRrun, ilrRun); }
      else ilrRun = 0;
    }
    const wi = loads.findIndex(l => l.id === 'water'); if (wi >= 0) { T.waterD += want[wi]; T.waterS += srv[wi]; }
    if (t1s < t1d - 1e-6) { T.t1FailH++; dayT1fail = true; if (h >= 18 && h <= 22) dayLightOK = false; }
    if (sv >= dem - 1e-6) T.allOkH++; { const jj=i-6>=0?i-6:0; const mm=H[jj].time? +H[jj].time.slice(4,6)-1 : 0; const M=MO[mm]; for (let k = 0; k < loads.length; k++){ M.d[tiers[k]-1]+=want[k]; M.s[tiers[k]-1]+=srv[k]; } M.pv+=pv; if(h===0){M.days++;} }
    T.minSOC = Math.min(T.minSOC, e / cap);
    if (o.trace && i >= o.startHour && i < o.startHour + (o.traceLen || 168)) trace.push([i, +pv.toFixed(2), +(dem).toFixed(2), +(sv).toFixed(2), +(t1d).toFixed(2), +(t1s).toFixed(2), +(e / cap).toFixed(3), state]);
  }
  const days = Math.floor(N / 24), years = N / 8766;
  return {
    pv: o.pv, batt: o.batt, years: +years.toFixed(2), dailyDemand: +dailyDemand.toFixed(2), dcDaily: +dcDaily.toFixed(2),
    yieldDC: +(T.pv / years / o.pv / 365.25).toFixed(3),
    serviceRatio: +(T.srv / T.dem).toFixed(4), t1Ratio: +(T.t[0][1] / T.t[0][0]).toFixed(5), t2Ratio: +(T.t[1][1] / T.t[1][0]).toFixed(4), t3Ratio: +(T.t[2][1] / T.t[2][0]).toFixed(4),
    ilrRatio: +(T.ilrS / T.ilrD).toFixed(5), ilrOutHperYr: +(T.ilrOutH / years).toFixed(1), maxILRrun: T.maxILRrun, waterRatio: +(T.waterS / T.waterD).toFixed(4),
    t1FailHperYr: +(T.t1FailH / years).toFixed(1), t1FailDaysPerYr: +(T.t1FailDays / years).toFixed(1), eveningLightOKpct: +(100 * T.nightLightOkDays / (days - 1)).toFixed(2),
    fullServicePct: +(100 * T.allOkH / N).toFixed(2), cyclesPerYr: +(T.thr / years / (cap * (o.maxSOC - o.minSOC))).toFixed(1), spillPct: +(100 * T.spill / T.pv).toFixed(1),
    servedKWhPerYr: +(T.srv / years).toFixed(0), unmetKWhPerYr: +((T.dem - T.srv) / years).toFixed(0), states: Object.fromEntries(Object.entries(T.states).map(([k, v]) => [k, +(100 * v / N).toFixed(1)])),
    minSOC: +T.minSOC.toFixed(3), monthly: MO.map(M=>({t1:+(M.s[0]/M.d[0]).toFixed(4),t2:+(M.s[1]/M.d[1]).toFixed(4),t3:+(M.s[2]/M.d[2]).toFixed(4),pvPerDay:+(M.pv/Math.max(1,M.days)).toFixed(1)})), trace: o.trace ? trace : undefined
  };
}
function RSloads() {
  return [
    { id: 'lighting', qty: 75, kw: .009, windows: [[18, 23]], tier: 1, house: true },
    { id: 'fans', qty: 25, kw: .035, windows: [[0, 6], [12, 15], [19, 22]], tier: 2, house: true },
    { id: 'phones', qty: 25, kw: .010, windows: [[18, 21]], tier: 1, house: true },
    { id: 'tv', qty: 25, kw: .050, windows: [[17, 23.3]], tier: 2, house: true },
    { id: 'ilr', qty: 1, kw: .050, windows: [[0, 24]], tier: 1 },
    { id: 'health', qty: 1, kw: .100, windows: [[8, 14]], tier: 1 },
    { id: 'school', qty: 1, kw: .400, windows: [[9, 15]], tier: 2 },
    { id: 'anganwadi', qty: 1, kw: .200, windows: [[9, 15]], tier: 2 },
    { id: 'mpc', qty: 1, kw: .100, windows: [[10, 16]], tier: 2 },
    { id: 'water', qty: 1, kw: 1, windows: [[10, 14]], tier: 1 },
    { id: 'honey', qty: 1, kw: 1, windows: [[10, 12]], tier: 3 },
    { id: 'tamarind', qty: 1, kw: .750, windows: [[12, 14]], tier: 3 },
    { id: 'leaf', qty: 1, kw: .500, windows: [[14, 16]], tier: 3 },
    { id: 'cold', qty: 1, kw: .125, windows: [[0, 24]], tier: 2 },
    { id: 'street', qty: 10, kw: .009, windows: [[0, 6], [18, 24]], tier: 1 }
  ];
}
if (typeof module !== 'undefined') module.exports = { RSsim, RSloads };
